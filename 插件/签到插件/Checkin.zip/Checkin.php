<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 签到插件
// +----------------------------------------------------------------------
namespace addons\checkin;

use app\addons\util\Addon;

class Checkin extends Addon
{

    //插件信息
    public $info = [
        'name' => 'checkin',
        'title' => '签到插件',
        'description' => '签到插件',
        'status' => 1,
        'author' => '御宅男',
        'version' => '1.0.0',
    ];

    //后台菜单
    public $admin_list = array(

    );

    //安装
    public function install()
    {
        return true;
    }

    //卸载
    public function uninstall()
    {
        return true;
    }

    public function checkIn($param)
    {

    }

}
