<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方登录管理
// +----------------------------------------------------------------------
namespace addons\synclogin\Controller;

use addons\synclogin\ThinkSDK\Oauth;
use app\addons\util\AddonsBase;

class Index extends AddonsBase
{
    //登陆地址
    public function login()
    {
        $type = $this->request->param('type');
        empty($type) && $this->error('参数错误');
        //加载ThinkOauth类并实例化一个对象
        $sns = Oauth::getInstance($type);
        //跳转到授权页面
        if ($this->request->isMobile() && ($type == 'weixin')) {
            /*$config = model('Weixin/WeixinConfig')->getWeixinConfig();
        $redirect = urlencode(url('Weixin/Index/callback', '', true, true));
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$config['APP_ID']}&redirect_uri={$redirect}&response_type=code&scope=snsapi_userinfo&state=opensns#wechat_redirect";
        redirect($url);
        exit;*/
        } else {
            $this->redirect($sns->getRequestCodeURL());
        }
    }

    //授权回调地址
    public function callback($type = null, $code = null)
    {
        if ($type == null || $code == null) {
            $this->error('参数错误');
        }
        $sns = Oauth::getInstance($type);
        // 获取TOKEN
        $token = $sns->getAccessToken($code);
        //获取当前第三方登录用户信息
        if (is_array($token)) {
            /*$user_info = addons\synclogin\ThinkSDK\GetInfo::getInstance($type, $token);
        dump($user_info); // 获取第三方用户资料
        $sns->openid(); //统一使用$sns->openid()获取openid*/

        } else {
            echo "获取第三方用户的基本信息失败";
        }
    }

    //绑定账号
    public function bind()
    {

    }

    //绑定新账号
    public function newAccount()
    {

    }

    //绑定已有账号
    public function existLogin()
    {

    }

    //跳过绑定 自动新增账号
    public function unBind()
    {

    }

}
