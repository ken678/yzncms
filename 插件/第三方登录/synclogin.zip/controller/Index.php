<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方登录管理
// +----------------------------------------------------------------------
namespace addons\synclogin\Controller;

use addons\synclogin\ThinkSDK\Oauth;
use app\addons\util\AddonsBase;

class Index extends AddonsBase
{
    //登陆地址
    public function login()
    {
        $type = $this->request->param('type');
        empty($type) && $this->error('参数错误');
        //加载ThinkOauth类并实例化一个对象
        $sns = Oauth::getInstance($type);
        //跳转到授权页面
        if ($this->request->isMobile() && ($type == 'weixin')) {
            /*$config = D('Weixin/WeixinConfig')->getWeixinConfig();
        $redirect = urlencode(U('Weixin/Index/callback', '', true, true));
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$config['APP_ID']}&redirect_uri={$redirect}&response_type=code&scope=snsapi_userinfo&state=opensns#wechat_redirect";
        redirect($url);
        exit;*/
        } else {
            $this->redirect($sns->getRequestCodeURL());
        }
    }

}
