<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方插件
// +----------------------------------------------------------------------
namespace addons\synclogin;

use app\addons\util\Addon;

/**
 * 返回顶部插件
 */
class Synclogin extends Addon
{

    //插件信息
    public $info = [
        'name' => 'synclogin',
        'title' => '第三方登录',
        'description' => 'QQ，微信和新浪等第三方登录',
        'status' => 1,
        'author' => '御宅男',
        'version' => '1.0.0',
        'has_adminlist' => 1,
    ];

    //后台菜单
    public $admin_list = array(

    );

    //安装
    public function install()
    {
        return true;
    }

    //卸载
    public function uninstall()
    {
        return true;
    }

}
