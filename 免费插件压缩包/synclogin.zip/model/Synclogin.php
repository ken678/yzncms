<?php

namespace addons\synclogin\model;

use think\Model;

class Synclogin extends Model
{
    protected $autoWriteTimestamp = true;

    //关联会员
    public function user()
    {
        return $this->belongsTo('\app\common\model\User', 'user_id', 'id', [], 'LEFT');
    }
}
