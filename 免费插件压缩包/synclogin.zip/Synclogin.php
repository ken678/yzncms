<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方登录插件
// +----------------------------------------------------------------------
namespace addons\synclogin;

use app\common\library\Auth;
use think\Addons;

class Synclogin extends Addons
{
    //安装
    public function install()
    {
        return true;
    }

    //卸载
    public function uninstall()
    {
        return true;
    }

    public function syncLogin($param)
    {
        $this->assign($param);
        $config = $this->getAddonConfig();
        $this->assign('config', $config);
        return $this->fetch('login');
    }

    public function userConfig($param)
    {
        $this->assign($param);
        $config = $this->getAddonConfig();
        $this->assign('config', $config);
        $arr  = [];
        $type = explode(',', $config['type']);

        $platform = \addons\synclogin\model\Synclogin::where('user_id', Auth::instance()->id)->column('platform');

        $this->assign('platform', $platform);
        $this->assign('type', $type);
        return $this->fetch('syncbind');
    }
}
