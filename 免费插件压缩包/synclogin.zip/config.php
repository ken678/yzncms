<?php
return [
    [
        'name'    => 'type',
        'title'   => '开启同步登陆：',
        'type'    => 'checkbox',
        'options' => [
            'qq'     => 'qq',
            'sina'   => 'sina',
            'weixin' => 'weixin',
        ],
        'value'   => '',
    ],
    [
        'name'    => 'bind',
        'title'   => '是否开启帐号绑定：',
        'type'    => 'radio',
        'options' => [
            '1' => '是',
            '0' => '否',
        ],
        'value'   => '0',
        'tip'     => '不开启则跳过与本地帐号绑定过程，建议审核时关闭绑定。',
    ],
    [
        'name'  => 'qq',
        'title' => 'QQ互联',
        'type'  => 'array',
        'value' => [
            'app_id'     => '',
            'app_secret' => '',
        ],
        'tip'   => '申请地址：http://connect.qq.com',
    ],
    [
        'name'  => 'sina',
        'title' => '新浪',
        'type'  => 'array',
        'value' => [
            'app_id'     => '',
            'app_secret' => '',
        ],
        'tip'   => '申请地址：http://open.weibo.com/',
    ],
    [
        'name'  => 'weixin',
        'title' => '微信',
        'type'  => 'array',
        'value' => [
            'app_id'     => '',
            'app_secret' => '',
        ],
        'tip'   => '电脑扫码申请地址：https://open.weixin.qq.com/<br>公众号申请地址：https://mp.weixin.qq.com/',
    ],
];
