<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方服务类
// +----------------------------------------------------------------------
namespace addons\synclogin\library;

use addons\synclogin\model\Synclogin as SyncloginModel;
use app\common\model\User as UserModel;
use think\Exception;
use think\facade\Db;

class Service
{
    /**
     * 第三方登录
     * @param string $platform 平台
     * @param array  $params   参数
     * @param array  $extend   会员扩展信息
     * @param int    $keeptime 有效时长
     * @return boolean
     *
     */
    public static function connect($platform, $params = [], $extend = [], $keeptime = 0)
    {
        $time       = time();
        $nickname   = $params['nickname'] ?? ($params['userinfo']['nickname'] ?? '');
        $avatar     = $params['avatar'] ?? ($params['userinfo']['avatar'] ?? '');
        $expires_in = $params['expires_in'] ?? 0;
        $openid     = isset($params['openid']) && !empty($params['openid']) ? $params['openid'] : '';
        $unionid    = isset($params['unionid']) && !empty($params['unionid']) ? $params['unionid'] : '';

        $values = [
            'openid'        => $openid,
            'access_token'  => $params['access_token'] ?? '',
            'refresh_token' => $params['refresh_token'] ?? '',
            'expires_in'    => $expires_in,
            'openname'      => $nickname,
            'platform'      => $platform,
            'login_time'    => $time,
            'expire_time'   => $time + $expires_in,
            'unionid'       => $params['unionid'] ?? '',
        ];
        $data = array_merge($values, $params);

        $auth = \app\common\library\Auth::instance();
        $auth->keeptime($keeptime);

        $third = null;
        //存在openid则先判断是否存在对应账号
        if ($openid) {
            $third = SyncloginModel::where(['platform' => $platform, 'openid' => $openid])->with('user')->find();
        }

        //存在unionid就需要判断是否需要生成新记录
        if (!$third && $unionid) {
            $third = SyncloginModel::where(['platform' => $platform, 'unionid' => $unionid])->with('user')->find();
        }

        if ($third) {
            if (!$third->user) {
                //删除不存在会员记录
                $third->delete();
                $third = null;
            } else {
                //优化头像存储
                $update = [
                    'nickname' => !$third->user->nickname || $third->user->nickname == '微信用户' ? ($nickname ?: ''): '',
                    'avatar'   => !$third->user->avatar ? ($avatar ?: ''): '',
                ];
                $data = array_filter($update);
                $third->user->save($data);
                // 写入登录Cookies和Token
                return $auth->direct($third->user_id);
            }
        }

        if ($auth->id) {
            if (!$third) {
                $data['user_id'] = $auth->id;
                SyncloginModel::create($data);
            }
            $user = $auth->getUser();
        } else {
            //先随机一个用户名,随后再变更为u+数字id
            $username = genRandomString(10);
            $password = genRandomString(6);
            $domain   = request()->host();
            Db::startTrans();
            try {
                $uid = $auth->register($username, $password, $username . '@' . $domain, '', $extend);
                if (!$uid) {
                    throw new Exception($auth->getError());
                }
                $user = $auth->getUser();

                $username = 'u' . $user->id;
                $email    = $username . '@' . $domain;
                $fields   = [];

                //判断用户名和邮箱是否已存在
                $exist = UserModel::where('username', $username)->find();
                if (!$exist) {
                    $fields['username'] = $username;
                }
                $exist = UserModel::where('email', $email)->find();
                if (!$exist) {
                    $fields['email'] = $email;
                }

                //如果昵称为空或为微信用户则修改
                if (!$user['nickname'] || $user['nickname'] == '微信用户') {
                    $fields['nickname'] = $nickname = $fields['username'];
                }

                if ($nickname) {
                    $fields['nickname'] = xss_clean(strip_tags($nickname));
                }
                if ($avatar) {
                    $fields['avatar'] = xss_clean(strip_tags($avatar));
                }

                // 更新会员资料
                $user = UserModel::find($user->id);
                $user->save($fields);
                // 记录数据到synclogin表中
                if (!$third) {
                    $data['user_id'] = $user->id;
                    SyncloginModel::create($data);
                }
                Db::commit();
            } catch (\Exception $e) {
                Db::rollback();
                \think\facade\Log::record($e->getMessage());
                $auth->logout();
                return false;
            }
        }
        // 写入登录Cookies和Token
        return $auth->direct($user->id);
    }

    /**
     * 是否绑定第三方
     */
    public static function isBindThird($platform, $openid, $apptype = '', $unionid = '')
    {
        $conddtions = [
            'platform' => $platform,
            'openid'   => $openid,
        ];
        if ($apptype) {
            $conddtions['apptype'] = $apptype;
        }
        $third = SyncloginModel::where($conddtions)->with('user')->find();
        //第三方存在
        if ($third) {
            //用户失效
            if (!$third->user) {
                $third->delete();
                return false;
            }
            return true;
        }
        if ($unionid) {
            $third = SyncloginModel::where(['platform' => $platform, 'unionid' => $unionid])->with('user')->find();
            if ($third) {
                //
                if (!$third->user) {
                    $third->delete();
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * 判断是否在微信内
     * @return bool
     */
    public static function isWechat()
    {
        return strpos(request()->server('HTTP_USER_AGENT'), 'MicroMessenger') !== false;
    }

    /**
     * 获取平台类型
     * @return string
     */
    public static function getApptype()
    {
        //如果是公众号则为mp,网页为web,小程序为miniapp，单独判断
        return self::isWechat() ? 'mp' : 'web';
    }
}
