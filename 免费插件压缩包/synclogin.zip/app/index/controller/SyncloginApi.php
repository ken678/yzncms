<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方登录管理
// +----------------------------------------------------------------------
namespace app\index\controller;

use addons\synclogin\library\Oauth;
use addons\synclogin\library\Service;
use app\common\controller\Api;

class SyncloginApi extends Api
{
    protected $noNeedLogin = ['getAuthUrl', 'callback'];
    protected $noNeedRight = [];

    /**
     * H5获取授权链接
     */
    public function getAuthUrl()
    {
        $url      = $this->request->param('url');
        $platform = $this->request->param('type/s');

        if (!$url || !$platform) {
            $this->error('参数错误');
        }
        $config['callback'] = $url;
        //加载ThinkOauth类并实例化一个对象
        $sns = Oauth::getInstance($platform, $config);
        $this->success('', $sns->getRequestCodeURL());
    }

    /**
     * 公众号授权回调的请求
     */
    public function callback()
    {
        $platform = $this->request->param('type/s');
        $code     = $this->request->param('code/s');
        $apptype  = $this->request->param('apptype');
        $bind     = $this->request->param('bind', 0); //默认要求绑定账号
        if ($platform == null || $code == null) {
            $this->error('参数错误');
        }
        $sns = Oauth::getInstance($platform);
        // 获取TOKEN
        $token = $sns->getAccessToken($code);
        // 获取第三方获取信息
        $userinfo = $sns->getUserInfo();
        $openid   = !empty($token['unionid']) ? $token['unionid'] : $token['openid'];
        if (empty($token)) {
            $this->error('参数错误');
        }
        $userinfo['platform'] = $platform;
        $userinfo['apptype']  = $apptype ?: Service::getApptype();

        $user = null;
        if (!$bind || $this->auth->isLogin() || Service::isBindThird($userinfo['platform'], $userinfo['openid'], $userinfo['apptype'], $userinfo['unionid'])) {
            $result = Service::connect($userinfo['platform'], $userinfo);
            if (!$result) {
                $this->error('授权登录失败');
            }
            $user = $this->auth->getUserinfo();
        } else {
            $user = false;
            Session::set('third-userinfo', $userinfo);
        }
        $this->success("授权成功！", ['user' => $user, 'openid' => $userinfo['openid']]);
    }

}
