<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 第三方登录管理
// +----------------------------------------------------------------------
namespace app\index\controller;

use addons\synclogin\library\Oauth;
use addons\synclogin\library\Service;
use addons\synclogin\model\Synclogin as SyncloginModel;
use app\common\controller\Frontend;
use think\exception\ValidateException;
use think\facade\Cookie;
use think\facade\Event;

class Synclogin extends Frontend
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = [];
    private $access_token  = '';
    private $openid        = '';
    private $platform      = '';
    private $token         = [];

    public function initialize()
    {
        parent::initialize();
        $auth = $this->auth;
        //监听注册登录退出的事件
        Event::listen('user_login_successed', function ($user) use ($auth) {
            $expire = $this->request->post('keeplogin') ? 30 * 86400 : 0;
            Cookie::set('uid', $user->id, $expire);
            Cookie::set('token', $auth->getToken(), $expire);
        });
        Event::listen('user_register_successed', function ($user) use ($auth) {
            Cookie::set('uid', $user->id);
            Cookie::set('token', $auth->getToken());
        });
        Event::listen('user_delete_successed', function ($user) use ($auth) {
            Cookie::delete('uid');
            Cookie::delete('token');
        });
        Event::listen('user_logout_successed', function ($user) use ($auth) {
            Cookie::delete('uid');
            Cookie::delete('token');
        });
        $this->getSession();
    }

    private function getSession()
    {
        $session            = session('SYNCLOGIN');
        $this->token        = $session['TOKEN'] ?? '';
        $this->platform     = $session['PLATFORM'] ?? '';
        $this->openid       = $session['OPENID'] ?? '';
        $this->access_token = $session['ACCESS_TOKEN'] ?? '';
        $this->openname     = $session['OPENNAME'] ?? '';
    }

    //登陆地址
    public function login()
    {
        $platform = $this->request->param('type');
        empty($platform) && $this->error('参数错误');
        //加载ThinkOauth类并实例化一个对象
        $sns = Oauth::getInstance($platform);
        //跳转到授权页面
        $this->redirect($sns->getRequestCodeURL());

    }

    //授权回调地址
    public function callback()
    {
        $platform = $this->request->param('type/s');
        $code     = $this->request->param('code/s');
        $is_login = $this->auth->isLogin();
        if ($platform == null || $code == null) {
            $this->error('参数错误');
        }
        $sns = Oauth::getInstance($platform);
        // 获取TOKEN
        $token = $sns->getAccessToken($code);
        // 获取第三方获取信息
        $userinfo = $sns->getUserInfo();

        if (empty($token)) {
            $this->error('参数错误');
        }
        $userinfo['platform'] = $platform;
        $userinfo['apptype']  = $userinfo['apptype'] ?? '';
        $userinfo['unionid']  = $userinfo['unionid'] ?? '';

        $session = ['TOKEN' => $token, 'PLATFORM' => $platform, 'OPENID' => $token['openid'], 'ACCESS_TOKEN' => $token['access_token'], 'OPENNAME' => $userinfo['nickname']];
        session('SYNCLOGIN', $session);
        $this->getSession(); // 重新获取session
        //获取当前第三方登录用户信息
        if (is_array($token)) {
            if ($is_login) {
                $this->dealIsLogin($this->auth->id);
            } else {
                $check        = Service::isBindThird($platform, $token['openid'], $userinfo['apptype'], $userinfo['unionid']);
                $addon_config = get_addon_config('synclogin');
                if ($addon_config['bind'] && !$check) {
                    $this->redirect(url('index/synclogin/bind'));
                } else {
                    //$this->prepare();
                    $loginret = Service::connect($platform, $userinfo);
                    if ($loginret) {
                        $this->success('登陆成功！', url('index/user/index'));
                    }
                }
            }
        } else {
            echo "获取第三方用户的基本信息失败";
        }
    }

    //绑定账号
    public function bind()
    {
        if (!$this->token) {
            $this->error('无效的token');
        }
        $tip               = $this->request->param('tip/s');
        $tip == '' && $tip = 'new';
        $this->assign('tip', $tip);
        $this->assign('title', '账号绑定');
        return $this->fetch('bind');
    }

    //解绑账号
    public function unBind()
    {
        $platform = $this->request->param('type/s');
        if (empty($platform)) {
            $this->error('参数错误');
        }
        if (!$this->auth->isLogin()) {
            $this->error('请登录！');
        }
        $third = SyncloginModel::where('user_id', $this->auth->id)->where('platform', $platform)->find();
        if (!$third) {
            $this->error("未找到指定的账号绑定信息");
        }
        $third->delete();
        $this->success('取消绑定成功', url('index/user/profile'));
    }

    //绑定新账号
    public function newAccount()
    {
        $post = $this->request->post('');
        $rule = [
            'username|用户名' => 'unique:user|require|alphaDash|length:3,20',
            'nickname|昵称'  => 'unique:user|length:3,20',
            'mobile|手机'    => 'require|unique:user|mobile',
            'password|密码'  => 'require|length:3,20',
            'email|邮箱'     => 'unique:user|require|email',
        ];
        try {
            $this->validate($post, $rule);
        } catch (ValidateException $e) {
            // 验证失败 输出错误信息
            $this->error($e->getError());
        }

        $extend = [];
        $userid = $this->auth->register($post['username'], $post['password'], $post['email'], $post['mobile'], $extend);
        if ($userid > 0) {
            $this->addSyncLoginData($userid);
            $this->success('账号绑定成功！', url('index/user/index'));
        } else {
            $this->error('账号绑定失败，请重试！');
        }

    }

    //绑定已有账号
    public function bindAccount()
    {
        $account  = $this->request->param('account');
        $password = $this->request->param('password');
        $userInfo = $this->auth->login($account, $password);
        if ($userInfo) {
            $this->addSyncLoginData($this->auth->id);
            $this->success('账号绑定成功！', url('index/user/index'));
        } else {
            $this->error('账号绑定失败，请重试！');
        }
    }

    /**
     * 增加synclogin表中数据
     */
    private function addSyncLoginData($user_id)
    {
        $data['user_id']      = $user_id;
        $data['openid']       = $this->openid;
        $data['access_token'] = $this->access_token;
        $data['platform']     = $this->platform;
        $data['openname']     = $this->openname;
        $data['login_time']   = time();
        return SyncloginModel::create($data);
    }

    protected function dealIsLogin($user_id = 0)
    {
        $session  = session('SYNCLOGIN');
        $openid   = $session['OPENID'];
        $platform = $session['PLATFORM'];
        if (Service::isBindThird($platform, $openid)) {
            $this->error('该帐号已经被绑定！');
        }
        $this->addSyncLoginData($user_id);
        $this->success('绑定成功！', url('index/user/profile'));
    }
}
