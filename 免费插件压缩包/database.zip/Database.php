<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 数据库插件
// +----------------------------------------------------------------------
namespace addons\database;

use app\common\library\Menu;
use think\Addons;

class Database extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                "name"    => "database",
                "title"   => "数据库备份",
                "icon"    => "iconfont icon-save-line",
                "sublist" => [
                    ["name" => "database/index", "title" => "查看"],
                    ["name" => "database/restore", "title" => "备份还原"],
                    ["name" => "database/del", "title" => "删除备份"],
                    ["name" => "database/repair", "title" => "修复表"],
                    ["name" => "database/optimize", "title" => "优化表"],
                    ["name" => "database/import", "title" => "还原表"],
                    ["name" => "database/export", "title" => "备份数据"],
                    ["name" => "database/download", "title" => "备份下载"],
                ],
            ],
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("database");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("database");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("database");
        return true;
    }

}
