define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                restore_url: "database/restore",
                optimize_url: "database/optimize",
                repair_url: "database/repair",
                export_url: "database/export",
            };

            Table.render({
                init: Table.init,
                search: false,
                toolbar: ['refresh', [{
                    text: '数据库还原',
                    url: Table.init.restore_url,
                    auth: 'restore',
                    class: 'layui-btn layui-btn-sm layui-btn-danger btn-dialog',
                    icon: "iconfont icon-history-line",
                    extend: '',
                }, {
                    text: '立即备份',
                    url: '',
                    auth: 'export',
                    class: 'layui-btn layui-btn-sm layui-btn-disabled btn-disabled',
                    icon: "iconfont icon-save-line",
                    extend: 'id="export"',
                }, {
                    text: '优化表',
                    url: Table.init.optimize_url,
                    auth: 'optimize',
                    class: 'layui-btn layui-btn-sm layui-btn-disabled btn-disabled',
                    icon: "iconfont icon-reactjs-line",
                    extend: "id='optimize'",
                }, {
                    text: '修复表',
                    url: Table.init.repair_url,
                    auth: 'repair',
                    class: 'layui-btn layui-btn-sm layui-btn-disabled btn-disabled',
                    icon: "iconfont icon-tools-line",
                    extend: "id='repair'",
                }]],
                url: 'database/index',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'name', width: 200, title: '表名' },
                        { field: 'rows', width: 120, title: '数据量' },
                        { field: 'data_length', width: 120, title: '数据大小', templet: '#size' },
                        { field: 'create_time', width: 200, title: '创建时间' },
                        { field: 'comment', title: '说明' },
                        { field: 'info', width: 200, title: '备份状态', templet: '<div>未备份</div>' },
                    ]
                ],
            });

            Table.api.bindevent();

            //优化or修复
            $(document).on('click', '#optimize,#repair', function() {
                var that = this,
                    checkStatus = layui.table.checkStatus('currentTable');
                if (checkStatus.data.length <= 0) {
                    Layer.msg("请选择需要操作的数据", { icon: 2 });
                    return false;
                }
                var a = [];
                $(checkStatus.data).each(function(i, o) {
                    a.push(o.name);
                });

                Yzn.api.ajax({
                    url: $(that).attr('href'),
                    data: { tables: a }
                }, function(data, res) {
                    if (res.code) {
                        Layer.msg(res.msg, { icon: 1 });
                    } else {
                        Layer.msg(res.msg, { icon: 5 });
                    }
                    return false;
                });

                return false;
            });

            var $export = $("#export");
            //提交备份
            $(document).on('click', '#export', function() {
                var checkStatus = layui.table.checkStatus('currentTable');
                if (checkStatus.data.length <= 0) {
                    Layer.msg("请选择需要备份的数据", { icon: 2 });
                    return false;
                }
                var a = [];
                $(checkStatus.data).each(function(i, o) {
                    a.push(o.name);
                });
                $export.parent().children().addClass("layui-btn-disabled");
                $export.html("<i class='icon iconfont icon-fasong'></i>正在发送备份请求...");


                Yzn.api.ajax({
                    url: Table.init.export_url,
                    data: { tables: a }
                }, function(data, res) {
                    if (res.code) {
                        tables = data.tables;
                        $export.html(res.msg + "开始备份，请不要关闭本页面！");
                        backup(data.tab);
                        window.onbeforeunload = function() { return "正在备份数据库，请不要关闭！" }
                    } else {
                        Layer.msg(res.msg, { icon: 5 });
                        $export.parent().children().removeClass("disabled");
                        $export.html("立即备份");
                    }
                    return false;
                });
                return false;
            });

            function backup(tab, code) {
                code && showmsg(tab.id, "开始备份...(0%)");

                Yzn.api.ajax({
                    url: Table.init.export_url,
                    data: tab,
                    type: 'get'
                }, function(data, res) {
                    if (res.code) {
                        showmsg(tab.id, res.msg);
                        if (!$.isPlainObject(data.tab)) {
                            $export.parent().children().removeClass("layui-btn-disabled");
                            $export.html("备份完成，点击重新备份");
                            window.onbeforeunload = function() { return null }
                            return;
                        }
                        backup(data.tab, tab.id != data.tab.id);
                    } else {
                        Layer.msg(res.msg, { icon: 5 });
                        $export.parent().children().removeClass("disabled");
                        $export.html("立即备份");
                    }
                    return false;
                });

            }

            function showmsg(id, msg) {
                $('.layui-table').find('tr:eq(' + id + ') td:eq(6)').find('div').html(msg);
            }
        },
        restore: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                import_url: 'database/import',
                index_url: 'database/index',
                delete_url: 'database/del',
            };

            Table.render({
                init: Table.init,
                pk: 'time',
                toolbar: ['refresh'],
                url: 'database/restore',
                search: false,
                cols: [
                    [
                        { field: 'title', width: 180, title: '备份名称' },
                        { field: 'date', width: 170, title: '备份时间' },
                        { field: 'size', width: 100, title: '备份大小' },
                        { field: 'part', width: 70, title: '卷数' },
                        { field: 'compress', title: '压缩' },
                        { fixed: 'right', width: 180, title: '操作', toolbar: '#barTool' }
                    ]
                ],
            });

            layui.table.on('tool', function(obj) {
                var layEvent = obj.event;
                if (layEvent === 'btn-dataImport') {
                    var code = ".",
                        data = obj.data,
                        self = this;
                    var url = Table.init.import_url + '?time=' + data.time;
                    Layer.confirm('确定导入此条数据库吗？', { icon: 3, title: '提示' }, function(index) {
                        Layer.close(index);
                        Yzn.api.ajax({
                            url: url,
                            type: 'get'
                        }, success);
                        window.onbeforeunload = function() { return "正在还原数据库，请不要关闭！" }
                        return false;
                    });

                    function success(data, res) {

                        if (data.gz) {
                            res.msg += code;
                            if (code.length === 5) {
                                code = ".";
                            } else {
                                code += ".";
                            }
                        }

                        if (res.data.part) {
                            Yzn.api.ajax({
                                url: url,
                                type: 'get',
                                data: { "part": data.part, "start": data.start }
                            }, success);
                        } else {
                            window.onbeforeunload = function() { return null; }
                        }

                    }
                }

            })

            Table.api.bindevent();
        }
    };
    return Controller;
});