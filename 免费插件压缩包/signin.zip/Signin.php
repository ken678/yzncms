<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 签到插件
// +----------------------------------------------------------------------
namespace addons\signin;

use app\common\library\Menu;
use think\Addons;

class Signin extends Addons
{
    //后台菜单
    protected $menu = [
        [
            "name"    => "signin",
            "title"   => "签到",
            "icon"    => "iconfont icon-calendar-check-line",
            "sublist" => [
                ["name" => "signin/index", "title" => "查看"],
                ["name" => "signin/add", "title" => "新增"],
                ["name" => "signin/edit", "title" => "编辑"],
                ["name" => "signin/del", "title" => "删除"],
                ["name" => "signin/multi", "title" => "批量更新"],
            ],
        ],
    ];

    //安装
    public function install()
    {
        Menu::create($this->menu);
        return true;
    }

    //卸载
    public function uninstall()
    {
        Menu::delete("signin");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("signin");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("signin");
        return true;
    }

    /**
     * 插件升级方法
     */
    public function upgrade()
    {
        Menu::upgrade('signin', $this->menu);
    }

    /**
     * 会员中心边栏后
     * @return mixed
     * @throws \Exception
     */
    public function userSidenavAfter()
    {
        return $this->fetch('user_sidenav_after');
    }

}
