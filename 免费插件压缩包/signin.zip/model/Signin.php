<?php

namespace addons\signin\model;

use think\Model;

class Signin extends Model
{

    public function user()
    {
        return $this->belongsTo('\app\common\model\User', "user_id", "id");
    }
}
