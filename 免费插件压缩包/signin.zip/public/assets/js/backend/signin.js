define(['jquery', 'table'], function($, Table) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "signin/add",
                edit_url: "signin/edit",
                delete_url: "signin/del",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'signin/index',
                lineStyle: 'height: 45px;',
                cols: [
                    [
                        { field: 'id', width: 100, title: 'ID' },
                        { field: 'user_id', width: 80, title: '用户ID' },
                        { field: 'user.avatar', width: 70, align: "center", title: '头像', search: false, templet: Table.formatter.image },
                        { field: 'user.username', title: '用户名', templet: '<div>{{#  if(d.user.vip==1){ }} <span class="text-danger">[VIP]</span> {{#  } }}{{ d.user.username }}</div>', searchOp: 'like' },
                        { field: 'user.nickname', title: '昵称', searchOp: 'like' },
                        { field: 'successions', width: 150, title: '连续签到次数' },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        }
    };
    return Controller;
});