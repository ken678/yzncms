define(['jquery', 'frontend', 'form'], function($, Frontend, Form) {

    var Controller = {
        index: function() {
            var isMobile = !!("ontouchstart" in window);
            $(document).on("click", ".btn-signin,.today", function() {
                Yzn.api.ajax("signin/dosign", function() {
                    Layer.msg("签到成功!", {
                        icon: 1,
                        time: 2500
                    }, function() {
                        location.reload();
                    });
                });
                return false;
            });

            $(document).on("click", ".btn-rank", function() {
                Yzn.api.ajax("signin/rank", function(data) {
                    Layer.open({
                        title: '签到排行榜',
                        type: 1,
                        zIndex: 88,
                        area: isMobile ? 'auto' : ["400px"],
                        content: layui.laytpl($("#ranktpl").html()).render({ list: data }),
                        btn: false
                    });
                    return false;
                })
                return false;
            });


            if (Config.isfillup) {
                $(document).on("click", ".expired[data-date]:not(.today):not(.signed)", function() {
                    var that = this;
                    Layer.confirm("确认进行补签日期：" + $(this).data("date") + "？<br>补签将消耗" + Config.fillupscore + " 积分", function() {
                        Yzn.api.ajax("signin/fillup?date=" + $(that).data("date"), function(data, ret) {
                            Layer.msg("补签成功!", {
                                icon: 1,
                                time: 1500
                            }, function() {
                                location.reload();
                            });
                            return false;
                        }, function(data, ret) {
                            Layer.alert(ret.msg);
                            return false;
                        });
                    });
                    return false;
                });
            }
        },
    };
    return Controller;
});