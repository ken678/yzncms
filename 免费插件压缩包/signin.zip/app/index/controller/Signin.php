<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 会员签到管理
// +----------------------------------------------------------------------
namespace app\index\controller;

use addons\signin\library\Service;
use addons\signin\model\Signin as SigninModel;
use app\common\controller\Frontend;
use app\common\model\User;
use util\Date;

class Signin extends Frontend
{
    // 签到首页
    public function index()
    {
        $date   = $this->request->request('date', date("Y-m-d"), "trim");
        $config = get_addon_config('signin');

        $lastSignin = SigninModel::where('user_id', $this->auth->id)->order('create_time', 'desc')->find();
        $signin     = SigninModel::where('user_id', $this->auth->id)->whereDay('create_time')->find();

        $calendar = new \addons\signin\library\Calendar();
        $calendar->addTableClasses(['layui-table']);
        $list = SigninModel::where('user_id', $this->auth->id)
            ->field('id,create_time')
            ->whereMonth('create_time', date("Y-m", strtotime($date)))
            ->select();

        foreach ($list as $index => $item) {
            $calendar->addEvent(date("Y-m-d", $item->create_time), date("Y-m-d", $item->create_time), "", false, "signed");
        }

        $successions = $lastSignin && $lastSignin['create_time'] > Date::unixtime('day', -1) ? $lastSignin['successions'] : 0;
        $this->assign([
            'calendar'    => $calendar,
            'date'        => $date,
            'successions' => $successions,
            'signconfig'  => $config,
        ]);

        $successions++;
        $signinScores = $config['signinscore'];
        $score        = $signinScores['s' . $successions] ?? $signinScores['sn'];

        $this->assign([
            'signin' => $signin,
            'score'  => $score,
        ]);

        $this->assignconfig('fillupscore', $config['fillupscore']);
        $this->assignconfig('isfillup', $config['isfillup']);
        $this->assign('title', '每日签到');
        return $this->fetch();
    }

    // 立即签到
    public function dosign()
    {
        if ($this->request->isPost()) {
            $config = get_addon_config('signin');

            $lastSignin = SigninModel::where('user_id', $this->auth->id)->order('create_time', 'desc')->find();
            if ($lastSignin && date('Ymd', $lastSignin->create_time) == date('Ymd')) {
                $this->error('今天已签到,请明天再来!');
            };

            $successions = $lastSignin && $lastSignin['create_time'] > Date::unixtime('day', -1) ? $lastSignin['successions'] : 0;
            $successions++;
            $signinScores = $config['signinscore'];
            $score        = $signinScores['s' . $successions] ?? $signinScores['sn'];

            try {
                SigninModel::create([
                    'user_id'     => $this->auth->id,
                    'successions' => $successions,
                    'create_time' => time(),
                ]);
                //增加积分
                User::point($score, $this->auth->id, "连续签到{$successions}天");
            } catch (Exception $e) {
                $this->error('签到失败,请稍后重试');
            }
            $this->success("签到成功" . ($successions > 1 ? "，连续签到{$successions}天" : '') . "，赠送{$score}积分");
        }
        $this->error("请求错误");
    }

    // 签到补签
    public function fillup()
    {
        $date   = $this->request->request('date');
        $time   = strtotime($date);
        $config = get_addon_config('signin');

        if (!$config['isfillup']) {
            $this->error('暂未开启签到补签');
        }

        if ($time > time()) {
            $this->error('无法补签未来的日期');
        }

        if ($config['fillupscore'] > $this->auth->point) {
            $this->error('你当前积分不足');
        }

        $days = Date::span(time(), $time, 'days');
        if ($config['fillupdays'] < $days) {
            $this->error("只允许补签{$config['fillupdays']}天的签到");
        }

        $count = SigninModel::where('user_id', $this->auth->id)
            ->where('type', 'fillup')
            ->whereMonth('create_time')
            ->count();
        if ($config['fillupnumsinmonth'] <= $count) {
            $this->error("每月只允许补签{$config['fillupnumsinmonth']}次");
        }

        $signin = SigninModel::where('user_id', $this->auth->id)
            ->where('type', 'fillup')
            ->whereDay('create_time', $date)
            ->count();
        if ($signin) {
            $this->error("该日期无需补签到");
        }

        $successions = 1;
        $prev        = $signin        = SigninModel::where('user_id', $this->auth->id)
            ->whereTimeInterval('create_time', date("Y-m-d", strtotime("-1 day", $time)), 'day')
            ->find();
        if ($prev) {
            $successions = $prev['successions'] + 1;
        }
        try {
            //扣除积分
            User::point(-$config['fillupscore'], $this->auth->id, '签到补签');
            //寻找日期之后的
            $nextList = SigninModel::where('user_id', $this->auth->id)
                ->where('create_time', '>=', strtotime("+1 day", $time))
                ->order('create_time', 'asc')
                ->select();
            foreach ($nextList as $index => $item) {
                //如果是阶段数据，则中止
                if ($index > 0 && $item->successions == 1) {
                    break;
                }
                $day = $index + 1;
                if (date("Y-m-d", $item->create_time) == date("Y-m-d", strtotime("+{$day} day", $time))) {
                    $item->successions = $successions + $day;
                    $item->save();
                }
            }
            SigninModel::create([
                'user_id'     => $this->auth->id,
                'type'        => 'fillup',
                'successions' => $successions,
                'create_time' => $time + 43200,
            ]);
        } catch (Exception $e) {
            $this->error('补签失败,请稍后重试');
        }
        $this->success('补签成功');
    }

    // 排行榜
    public function rank()
    {
        [$ranklist, $ranking, $successions] = Service::getRankInfo();
        $this->success("", "", [
            'ranklist'    => $ranklist->toArray(),
            'ranking'     => $ranking,
            'successions' => $successions,
        ]);
    }
}
