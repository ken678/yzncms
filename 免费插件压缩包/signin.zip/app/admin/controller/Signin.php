<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 签到管理
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\Signin as SigninModel;
use app\common\controller\Backend;

class Signin extends Backend
{

    protected $modelClass = null;

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new SigninModel;
    }

    /**
     * 查看
     */
    public function index()
    {
        $this->relationSearch = true;

        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            [$page, $limit, $where, $sort, $order] = $this->buildTableParames();
            $total                                 = $this->modelClass
                ->withJoin('user')
                ->where($where)
                ->count();

            $list = $this->modelClass
                ->withJoin('user')
                ->where($where)
                ->order($sort, $order)
                ->page($page, $limit)
                ->select();

            $result = ["code" => 0, "count" => $total, "data" => $list];

            return json($result);
        }
        return $this->view->fetch();
    }

}
