<?php

use think\facade\Config;

/**
 * 生成缩略图
 * @param type $imgurl    图片地址
 * @param type $width     缩略图宽度
 * @param type $height    缩略图高度
 * @param type $thumbType 缩略图生成方式
 * @param type $smallpic  图片不存在时显示默认图片
 * @return type
 */
function thumb($imgurl, $width = 100, $height = 100, $thumbType = 1, $smallpic = 'noimage.jpg')
{
    static $_thumb_cache = [];
    $cdnUrl              = Config::get('upload.cdnurl');
    $smallpic            = $cdnUrl . '/assets/img/' . $smallpic;
    if (empty($imgurl)) {
        return $smallpic;
    }
    //区分
    $key = md5($imgurl . $width . $height . $thumbType . $smallpic);
    if (isset($_thumb_cache[$key])) {
        return $_thumb_cache[$key];
    }
    if (!$width) {
        return $smallpic;
    }

    $uploadUrl   = $cdnUrl . '/uploads/';
    $public_path = public_path() . 'uploads' . DS;

    $relativeImagePath = str_replace($uploadUrl, '', $imgurl);
    $relativeImagePath = str_replace('/', DS, $relativeImagePath);

    // 新缩略图文件名
    $newimgname   = 'thumb_' . $width . '_' . $height . '_' . basename($relativeImagePath);
    $newImagePath = dirname($relativeImagePath) . DS . $newimgname;

    //检查生成的缩略图是否已经生成过
    if (is_file($public_path . $newImagePath)) {
        return $uploadUrl . $newImagePath;
    }

    //检查文件是否存在，如果是开启远程附件的，估计就通过不了，以后在考虑完善！
    $file = $public_path . $relativeImagePath;
    if (!is_file($file)) {
        return $imgurl;
    }

    //取得图片相关信息
    [$width_t, $height_t] = getimagesize($file);
    //如果高是0，自动计算高
    if ($height <= 0) {
        $height = round(($width / $width_t) * $height_t);
    }
    //判断生成的缩略图大小是否正常
    if ($width >= $width_t || $height >= $height_t) {
        return $imgurl;
    }

    $manager = \Intervention\Image\ImageManager::gd();
    $image   = $manager->read($file);
    switch ($thumbType) {
        case 1:
            //调整图像大小
            $image->resizeDown($width, $height);
            break;
        case 2:
            //按比例调整图像大小
            $image->scaleDown($width, $height);
            break;
        case 3:
            //裁剪和调整大小功能相结合
            $image->coverDown($width, $height);
            break;
        case 4:
            //调整大小和填充相结合
            $image->pad($width, $height);
            break;
        default:
            return $imgurl;
    }
    $filename = $public_path . dirname($relativeImagePath) . DS;
    if (!is_dir($filename)) {
        mkdir($filename, 0766, true);
    }
    $image->save($filename . $newimgname);
    $_thumb_cache[$key] = $uploadUrl . $newImagePath;
    return $_thumb_cache[$key];
}
