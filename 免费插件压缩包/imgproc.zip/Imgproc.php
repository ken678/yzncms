<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 图片处理插件
// +----------------------------------------------------------------------
namespace addons\imgproc;

use Composer\Autoload\ClassLoader;
use think\Addons;

class Imgproc extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        if (version_compare(PHP_VERSION, '8.1.0', '<')) {
            throw new \think\Exception("运行此插件需PHP8.1及以上版本");
        }
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        return true;
    }

    /**
     * 添加命名空间
     */
    public function appInit()
    {
        if (!class_exists('\Intervention\Image')) {
            $loader = new ClassLoader();
            $loader->addPsr4('Intervention\\Image\\', ADDON_PATH . 'imgproc' . DS . 'SDK' . DS . 'intervention' . DS . 'image' . DS . 'src', true);
            $loader->addPsr4('Intervention\\Gif\\', ADDON_PATH . 'imgproc' . DS . 'SDK' . DS . 'intervention' . DS . 'gif' . DS . 'src', true);
            $loader->register();
        }
        // 公共方法
        require_once __DIR__ . '/helper.php';
    }

    //上传成功
    public function uploadAfter($attachment)
    {
        $config = get_addon_config('imgproc');
        if ($attachment->driver == 'local' && $config['upload_thumb_water'] && $config['upload_thumb_water_pic'] != '') {
            $manager = \Intervention\Image\ImageManager::gd();
            $file    = public_path() . str_replace('/', DS, $attachment->path);

            $image           = $manager->read($file);
            $thumb_water_pic = realpath(public_path() . $config['upload_thumb_water_pic']);
            if (is_file($thumb_water_pic)) {

                $alpha = max(0, min(100, (int) ($config['upload_thumb_water_alpha'] ?? 100)));
                $quality = max(0, min(100, (int) ($config['upload_thumb_water_quality'] ?? 100)));

                $image->place(
                    $thumb_water_pic,
                    $config['upload_thumb_water_position'], 0, 0, $alpha
                );
                $image->save($file, progressive: true, quality: $quality);
                //重置图片信息
                $imgFile          = new \think\File($file);
                $attachment->md5  = $imgFile->md5();
                $attachment->sha1 = $imgFile->hash();
                $attachment->size = $imgFile->getSize();
                $attachment->save();
            }

        }
    }

}
