<?php

declare(strict_types=1);

namespace Intervention\Gif\Exceptions;

class FormatException extends \RuntimeException
{
}
