<?php

declare(strict_types=1);

namespace Intervention\Image\Drivers\Imagick\Modifiers;

class PadModifier extends ContainModifier
{
}
