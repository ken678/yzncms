<?php

return [
    [
        'name'    => 'upload_thumb_water',
        'title'   => '是否开启水印',
        'type'    => 'radio',
        'options' => [
            1 => '是',
            0 => '否',
        ],
        'value'   => 0,
    ],
    [
        'name'  => 'upload_thumb_water_pic',
        'title' => '水印图片',
        'type'  => 'image',
        'value' => '',
        'tip'   => '',
    ],
    [
        'name'    => 'upload_thumb_water_position',
        'title'   => '水印位置',
        'type'    => 'radio',
        'options' => [
            'top-left'     => '左上角',
            'top'          => '上居中',
            'top-right'    => '右上角',
            'left'         => '左居中',
            'center'       => '居中',
            'right'        => '右居中',
            'bottom-left'  => '左下角',
            'bottom'       => '下居中',
            'bottom-right' => '右下角',
        ],
        'value'   => 'top-left',
        'tip'     => '只有开启水印功能才生效',
    ],
    [
        'name'  => 'upload_thumb_water_alpha',
        'title' => '水印透明度',
        'type'  => 'number',
        'value' => '50',
        'tip'   => '请输入0~100之间的数字，数字越小，透明度越高',
    ],
    [
        'name'  => 'upload_thumb_water_quality',
        'title' => '图像保存质量',
        'type'  => 'number',
        'value' => '100',
        'tip'   => '请输入0~100之间的数字，数字越小，图像质量越差',
    ],
];
