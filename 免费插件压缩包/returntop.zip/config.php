<?php
return [
    [
        'name'    => 'random',
        'title'   => '是否开启随机:',
        'type'    => 'radio',
        'options' => [
            '1' => '开启',
            '0' => '关闭',
        ],
        'value'   => '0',
    ],
    [
        'name'  => 'current',
        'title' => '指定样式:',
        'type'  => 'radio',
        'value' => '1',
    ],
];
