<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 队列插件
// +----------------------------------------------------------------------
namespace addons\queue;

use Composer\Autoload\ClassLoader;
use think\Addons;

class Queue extends Addons
{
    //安装
    public function install()
    {
        return true;
    }

    //卸载
    public function uninstall()
    {
        return true;
    }

    /**
     * 添加命名空间
     */
    public function appInit()
    {
        if (!class_exists('\think\queue')) {
            $vendorDir = ADDON_PATH . 'queue' . DS . 'SDK' . DS;

            require $vendorDir . 'symfony' . DS . 'polyfill-php80' . DS . 'bootstrap.php';
            require $vendorDir . 'symfony' . DS . 'translation' . DS . 'Resources' . DS . 'functions.php';
            require $vendorDir . 'topthink' . DS . 'think-queue' . DS . 'src' . DS . 'common.php';

            $map = [
                'think\\'                           => [$vendorDir . 'topthink/think-queue/src'],
                'Symfony\\Polyfill\\Php80\\'        => [$vendorDir . 'symfony/polyfill-php80'],
                'Symfony\\Contracts\\Translation\\' => [$vendorDir . 'symfony/translation-contracts'],
                'Symfony\\Component\\Translation\\' => [$vendorDir . 'symfony/translation'],
                'Symfony\\Component\\Process\\'     => [$vendorDir . 'symfony/process'],
                'Psr\\Clock\\'                      => [$vendorDir . 'psr/clock/src'],
                'Carbon\\Doctrine\\'                => [$vendorDir . 'carbonphp/carbon-doctrine-types/src/Carbon/Doctrine'],
                'Carbon\\'                          => [$vendorDir . 'nesbot/carbon/src/Carbon'],
            ];
            $loader = new ClassLoader();
            foreach ($map as $namespace => $path) {
                $loader->setPsr4($namespace, $path);
            }
            $loader->register(true);
        }

    }

}
