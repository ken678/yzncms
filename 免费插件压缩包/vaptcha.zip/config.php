<?php
return [
    [
        'name'    => 'isOpen',
        'title'   => '是否开启',
        'type'    => 'radio',
        'options' => [
            1 => '是',
            0 => '否',
        ],
        'value'   => '0',
        'tip'     => '应用密钥如未填写，请勿开启，申请地址:<a href="https://www.vaptcha.com/" target="_blank">https://www.vaptcha.com/</a>',
    ],
    [
        'name'  => 'appvid',
        'title' => '应用VID',
        'type'  => 'text',
        'value' => '123456789',
    ],
    [
        'name'  => 'appkey',
        'title' => '应用KEY',
        'type'  => 'text',
        'value' => '123456789',
    ],
    [
        'name'    => 'type',
        'title'   => '显示类型',
        'type'    => 'select',
        'options' => [
            'click'     => '点击式',
            'invisible' => '隐藏式',
        ],
        'value'   => 'click',
    ],
];
