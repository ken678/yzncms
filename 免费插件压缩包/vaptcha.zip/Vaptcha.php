<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 智能人机验证插件
// +----------------------------------------------------------------------
namespace addons\vaptcha;

use addons\vaptcha\library\Vaptcha as VaptchaLib;
use think\Addons;
use think\exception\ValidateException;
use think\Validate;

class Vaptcha extends Addons
{
    //安装
    public function install()
    {
        return true;
    }

    //卸载
    public function uninstall()
    {
        return true;
    }

    /**
     * 自定义captcha验证事件
     */
    public function addonMiddleware($request)
    {
        $module = strtolower(app()->http->getName());
        //暂时只支持后台登录
        if (in_array($module, ['admin'])) {
            Validate::maker(function ($validate) {
                $validate->extend('captcha', function ($value) {
                    //return true;
                    $token = request()->post('vaptcha_token');
                    $scene = request()->post('scene/d', 1);
                    if (!$token) {
                        throw new ValidateException('请先完成验证！');
                    }
                    $config = $this->getAddonConfig();
                    if (!$config['appvid'] || !$config['appkey']) {
                        throw new ValidateException('请先在后台中配置vaptcha验证的参数信息');
                        return false;
                    }
                    $VaptchaLib = new VaptchaLib($config['appvid'], $config['appkey']);
                    $result     = $VaptchaLib->validate($token, $scene);
                    $result     = json_decode($result, true);
                    if ($result['success'] == 0) {
                        throw new ValidateException('请先完成验证！');
                        return false;
                    }
                    return true;
                });

            });
        }
    }

    /**
     * 脚本替换
     */
    public function AdminViewFilter($content)
    {
        $action = strtolower(request()->action());
        if ($action == 'login') {
            $content = preg_replace_callback('/<!--@CaptchaBegin-->([\s\S]*?)<!--@CaptchaEnd-->/i', function ($matches) {
                return '<!--@CaptchaBegin--><input type="hidden" name="verify"/><div class="layui-form-item"><div class="vaptcha-container" id="vaptchaContainer"><div class="vaptcha-init-main"><div class="vaptcha-init-loading"><a href="/" target="_blank"><img src="https://cdn.vaptcha.com/vaptcha-loading.gif" /></a><span class="vaptcha-text">Vaptcha启动中...</span></div></div></div></div><!--@CaptchaEnd-->';
            }, $content);
        }
        return $content;
    }

    public function adminLoginStyle()
    {
        return $this->fetch('vaptcha');
    }

    /**
     * 追加JS中配置
     * @param $params
     */
    public function configInit()
    {
        $config = $this->getAddonConfig();
        return ['vaptcha' => $config];
    }
}
