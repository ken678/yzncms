    require.config({
        paths: {
            'vaptcha': 'https://v-cn.vaptcha.com/v3'
        }
    });

    window.vaptcha = function(captcha) {
        require(['vaptcha'], function(Vaptcha) {
            vaptcha({
                vid: Config.vaptcha.appvid, //验证单元id
                mode: 'click', //显示类型 点击式
                container: '#vaptchaContainer',
                scene: 1, //场景值 不填默认为0
                area: 'auto' //验证节点区域,默认 auto,可选值 auto,sea,na,cn
            }).then(function(obj) {
                obj.renderTokenInput('.layui-form');
                obj.render();
                $('input[name="verify"]').val('ok');
                $('.layui-form').on("error.form", function(e, data) {
                    obj.reset();
                });
            });
        })

    }

    require(['form'], function(Form) {
        var _bindevent = Form.events.bindevent;
        Form.events.bindevent = function(form) {
            _bindevent.apply(this, [form]);
            var captchaObj = $("input[name=verify]", form);
            if (captchaObj.length > 0) {
                vaptcha(captchaObj);
            }
        }
    })