<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | phpcmsv9数据转换插件
// +----------------------------------------------------------------------
namespace addons\v9toyzn;

use app\common\library\Menu;
use think\Addons;

class V9toyzn extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                "name"    => "v9toyzn",
                "title"   => "PHPCMS数据转换",
                "sublist" => [
                    ["name" => "v9toyzn/init", "title" => "初始化"],
                    ["name" => "v9toyzn/start", "title" => "任务执行"],
                ],
            ],
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("v9toyzn");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("v9toyzn");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("v9toyzn");
        return true;
    }
}
