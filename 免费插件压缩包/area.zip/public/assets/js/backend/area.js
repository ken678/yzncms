define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: 'area/add',
                edit_url: 'area/edit',
                delete_url: 'area/del',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add', 'delete', [{
                    text: '更新地区数据',
                    auth: 'refresh',
                    class: 'layui-btn layui-btn-sm layui-btn-warm btn-refresh-area',
                    icon: 'iconfont icon-loop-left-line',
                    extend: '',
                }]],
                url: 'area/index?order=asc',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'id', width: 80, title: 'ID' },
                        { field: 'pid', width: 80, title: '父ID' },
                        { field: 'level', width: 60, title: '等级' },
                        { field: 'name', width: 200, title: '名称' },
                        { field: 'pinyin', title: '拼音' },
                        { field: 'first', width: 80, title: '首字母' },
                        { field: 'zip', width: 200, title: '邮编' },
                        { field: 'lng', title: '经度' },
                        { field: 'lat', title: '纬度' },
                        { width: 90, title: '操作', templet: Table.formatter.tool, operat: ['edit', 'delete'] }
                    ]
                ],
                page: {}
            });

            $(document).on("click", ".btn-refresh-area", function () {
                Layer.confirm("更新地区数据将导致现有的地区数据表重置，请谨慎操作<br>数据源采用高德地图行政区划数据<br>请在配置管理中配置高德地图”Web服务API”密钥（Key）<br>高德暂不支持台湾省的详细区划查询", {icon: 0}, function (index, layero) {
                    Yzn.api.ajax({
                        url: 'area/refresh'
                    }, function (data, ret) {
                        Layer.close(index);
                        $(".btn-refresh").trigger("click");
                    });
                });
                return false;
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});