<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 地区插件
// +----------------------------------------------------------------------
namespace addons\area;

use app\common\library\Menu;
use think\Addons;

class Area extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                "name"    => "area",
                "title"   => "地区管理",
                "sublist" => [
                    ["name" => "area/index", "title" => "查看"],
                    ["name" => "area/add", "title" => "新增"],
                    ["name" => "area/edit", "title" => "编辑"],
                    ["name" => "area/del", "title" => "删除"],
                    ["name" => "area/refresh", "title" => "刷新"],
                ],
            ],
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("area");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("area");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("area");
        return true;
    }

}
