<?php

return [
    [
        'name'  => 'amap_webapi_key',
        'title' => '高德地图的KEY',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ],
];
