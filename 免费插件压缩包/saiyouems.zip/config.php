<?php
return [
    [
        'name'  => 'from',
        'title' => '发件人地址',
        'type'  => 'text',
        'value' => '',
    ],
    [
        'name'  => 'appid',
        'title' => 'APPID名称',
        'type'  => 'text',
        'value' => '',
    ],
    [
        'name'  => 'appkey',
        'title' => 'APPKEY秘钥',
        'type'  => 'text',
        'value' => '',
    ],
];
