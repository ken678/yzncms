<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | API文档插件
// +----------------------------------------------------------------------
namespace addons\apidoc;

use Composer\Autoload\ClassLoader;
use think\Addons;

class Apidoc extends Addons
{
    //安装
    public function install()
    {
        //复制配置文件
        $route_file = ADDON_PATH . str_replace("/", DS, "apidoc/install/apidoc.php");
        copy($route_file, config_path() . 'apidoc.php');
        return true;
    }

    //卸载
    public function uninstall()
    {
        //删除配置文件
        if (file_exists(config_path() . 'apidoc.php')) {
            unlink(config_path() . 'apidoc.php');
        }
        return true;
    }

    /**
     * 添加命名空间
     */
    public function appInit()
    {
        if (!class_exists('\hg\apidoc')) {
            $vendorDir = ADDON_PATH . 'apidoc' . DS . 'SDK' . DS;
            $map       = [
                'hg\\apidoc\\'                    => [$vendorDir . '/hg/apidoc/src'],
                'Psr\\Cache\\'                    => [$vendorDir . '/psr/cache/src'],
                'Doctrine\\Deprecations\\'        => [$vendorDir . '/doctrine/deprecations/lib/Doctrine/Deprecations'],
                'Doctrine\\Common\\Lexer\\'       => [$vendorDir . '/doctrine/lexer/src'],
                'Doctrine\\Common\\Annotations\\' => [$vendorDir . '/doctrine/annotations/lib/Doctrine/Common/Annotations'],
            ];
            $loader = new ClassLoader();
            foreach ($map as $namespace => $path) {
                $loader->setPsr4($namespace, $path);
            }
            $loader->register(true);
        }
    }
}
