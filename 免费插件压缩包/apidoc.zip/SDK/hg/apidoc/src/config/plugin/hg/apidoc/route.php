<?php
// 注册Apidoc路由
hg\apidoc\providers\WebmanService::register();
