<?php

namespace app\api\controller\v2;

use app\common\controller\BaseController;
use app\Request;
use hg\apidoc\annotation as Apidoc;

/**
 * 基础示例2
 * @Apidoc\Group("user")
 * @Apidoc\Sort(1)
 */
class ApiDemo extends BaseController
{

    /**
     * @Apidoc\Title("基础的接口演示v2")
     * @Apidoc\Desc("一些基础的注解参数使用")
     * @Apidoc\Author("HG")
     * @Apidoc\Tag("基础,示例")
     * @Apidoc\Url ("api/v1.apidemo/index")
     * @Apidoc\Method ("GET")
     * @Apidoc\Query("abc",type="string",require=true,default="1",desc="abc标识")
     * @Apidoc\Query("qdatas",type="string",desc="qqq",mock="@cname")
     * @Apidoc\Param("name", type="string",require=true, desc="姓名",mock="@name")
     * @Apidoc\Param("phone", type="string",require=true, desc="手机号",mock="@phone")
     * @Apidoc\Param("sex", type="int",desc="性别" ,mock="@integer(0, 1)")
     * @Apidoc\Returned("id", type="int", desc="id")
     */
    public function index()
    {
        $res = $this->request->get();
        return $this->success("请求成功", "", $res);
    }

    /**
     * @Apidoc\Title ("路由带参")
     * @Apidoc\Url("api/v1.apidemo/routeParam/:name/<age>")
     * @Apidoc\Method("GET")
     * @Apidoc\Param("name",type="string",desc="姓名",mock="@cname")
     * @Apidoc\Param("age",type="string",desc="年龄",mock="@integer(10, 100)")
     * @Apidoc\Param("id",type="string",desc="id",mock="@integer(1, 100)")
     * @Apidoc\ParamType("route")
     *
     */
    public function routeParam($name, $age, $id)
    {
        $params = $this->request->param();
        return $this->success("请求成功", "", ['name' => $name, 'age' => $age, 'id' => $id, 'params' => $params]);
    }

    /**
     * @Apidoc\Title("文件上传")
     * @Apidoc\Desc("需 ParamType 为 formdata")
     * @Apidoc\Url ("api/v1.apidemo/upload")
     * @Apidoc\Author("HG")
     * @Apidoc\Method("POST")
     * @Apidoc\ParamType("formdata")
     * @Apidoc\Param("file",type="file", require=true,desc="附件")
     * @Apidoc\Returned("url", type="string",desc="文件地址")
     */
    public function upload()
    {
        return $this->success("请求成功", "", "xxx");
    }

    /**
     * @Apidoc\Title("多文件上传")
     * @Apidoc\Url ("api/v1.apidemo/uploads")
     * @Apidoc\Author("HG")
     * @Apidoc\Method("POST")
     * @Apidoc\ParamType("formdata")
     * @Apidoc\Param("files",type="files", require=true,desc="附件")
     * @Apidoc\Returned("url", type="string",desc="文件地址")
     */
    public function uploads()
    {
        return $this->success("请求成功", "", "xxx");
    }

    /**
     * @Apidoc\Title("指定请求ContentType")
     * @Apidoc\Url ("api/v1.apidemo/contentType")
     * @Apidoc\Method("POST")
     * @Apidoc\ContentType("application/json")
     * @Apidoc\Param("name", type="string",require=true, desc="姓名")
     * @Apidoc\Param("sex", type="int",default="1",desc="性别" )
     * @Apidoc\Returned("mssage", type="string", desc="消息",replaceGlobal=true)
     * @Apidoc\Returned("data", type="array", desc="返回数据",replaceGlobal=true,
     *     @Apidoc\Returned("id", type="int", desc="id"),
     * )
     */
    public function contentType(Request $request)
    {
        $params = $request->param();
        return $this->success("请求成功", "", $params);
    }

    /**
     * 多个请求类型
     * @Apidoc\Method("GET,POST,PUT,DELETE")
     * @Apidoc\Param("name",type="string",desc="姓名")
     * @Apidoc\Param("age",type="int",desc="年龄")
     *
     */
    public function multipleMethod(Request $request)
    {
        $params = $request->param();
        return $this->success("请求成功", "", $params);
    }

    /**
     * NotParse
     * @Apidoc\Param("name",type="string",desc="姓名")
     * @Apidoc\Param("age",type="string",desc="年龄")
     */
    public function notParseApi()
    {
        return $this->success("通过 notApi 标记该方法不解析");
    }

}
