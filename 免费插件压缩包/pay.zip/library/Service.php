<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 订单服务类
// +----------------------------------------------------------------------

namespace addons\pay\library;

use app\common\library\Auth;
use Exception;
use think\facade\Session;
use Yansongda\Pay\Pay;

class Service
{

    public static function submitOrder($amount, $orderid = null, $type = null, $title = null, $notifyurl = null, $returnurl = null, $method = null, $openid = '', $custom = [])
    {
        $request     = request();
        $addonConfig = get_addon_config('pay');
        if (!is_array($amount)) {
            $params = [
                'amount'    => $amount,
                'orderid'   => $orderid,
                'type'      => $type,
                'title'     => $title,
                'notifyurl' => $notifyurl,
                'returnurl' => $returnurl,
                'method'    => $method,
                'openid'    => $openid,
                'custom'    => $custom,
            ];
        } else {
            $params = $amount;
        }

        $type    = isset($params['type']) && in_array($params['type'], ['alipay', 'wechat']) ? $params['type'] : 'wechat';
        $method  = $params['method'] ?? 'web';
        $orderid = $params['orderid'] ?? date("YmdHis") . mt_rand(100000, 999999);
        $openid  = $params['openid'] ?? '';
        $title   = $params['title'] ?? "支付";
        $amount  = $params['amount'] ?? 1;

        $custom = $params['custom'] ?? [];

        //未定义则使用默认回调和跳转
        $notifyurl = !empty($params['notifyurl']) ? $params['notifyurl'] : $request->domain() . '/index/pay/epay/type/notify/paytype/' . $type;
        $returnurl = !empty($params['returnurl']) ? $params['returnurl'] : $request->domain() . '/index/pay/epay/type/return/paytype/' . $type . '/out_trade_no/' . $orderid;

        $config = Service::getConfig($type, array_merge($custom, ['notify_url' => $notifyurl, 'return_url' => $returnurl]));

        //判断是否移动端或微信内浏览器
        $isMobile = $request->isMobile();
        $isWechat = strpos($request->server('HTTP_USER_AGENT'), 'MicroMessenger') !== false;

        $result = null;
        if ($type == 'alipay') {
            //创建支付对象
            $pay = Pay::alipay($config);
            //支付宝支付,请根据你的需求,仅选择你所需要的即可
            $params = [
                'out_trade_no' => $orderid, //你的订单号
                'total_amount' => $amount, //单位元
                'subject' => $title,
            ];
            //如果是移动端自动切换为wap
            $method = $isMobile ? 'wap' : $method;
            switch ($method) {
                case 'web':
                    if ($addonConfig['alipay']['isper']) {
                        //个人扫码支付
                        $result = $pay->scan($params);
                        Session::set("alipayorderdata", [
                            'out_trade_no' => $orderid, //你的订单号
                            'body'    => $title,
                            'total_fee'    => $amount * 100, //单位分
                            "qr_code" => $result->qr_code,
                        ]);
                        $url = url('index/payapi/alipay');
                        header("location:{$url}");
                    } else {
                        //电脑支付,跳转
                        $result = $pay->web($params);
                    }
                    break;
                case 'wap':
                    //手机网页支付,跳转
                    $result = $pay->h5($params);
                    break;
                default:
            }
        } else {
            if ($method == 'web') {
                if ($isMobile) {
                    //不是微信环境 H5支付
                    if (!$isWechat) {
                        $method = 'wap';
                    } else {
                        $params['openid'] = $openid = $openid ?: self::getOpenid();
                        $method           = 'mp';
                    }
                }
            }
            //创建支付对象
            $pay = Pay::wechat($config);

            //单位分
            $total_fee = function_exists('bcmul') ? bcmul($amount, 100) : $amount * 100;
            $total_fee = (int) $total_fee;
            //如果是子商户的公众号则为sub_openid，并且sub_appid必填
            $openidName = $addonConfig['wechat']['mode'] == 2 ? 'sp_openid' : 'openid';

            $params = [
                'out_trade_no' => $orderid,
                'description'  => $title,
                'amount'       => [
                    'total' => $total_fee,
                ],
            ];
            switch ($method) {
                case 'mp':
                    $params['payer']     = [$openidName => $openid];
                    $jsapi               = $pay->mp($params);
                    $params["jsapi"]     = $jsapi;
                    $params["returnurl"] = $returnurl;
                    Session::set("wechatorderdata", $params);
                    $url = url('index/payapi/wechat');
                    header("location:{$url}");
                    break;
                case 'web':
                    //电脑支付,跳转到自定义展示页面
                    $result = $pay->scan($params);
                    Session::set("wechatorderdata", [
                        'out_trade_no' => $orderid, //你的订单号
                        'body'     => $title,
                        'total_fee'    => $total_fee, //单位分
                        "code_url" => $result->code_url,
                        //"code_url" => "weixin://wxpay/bizpayurl?pr=4aXtmGv",
                    ]);
                    $url = url('index/payapi/wechat');
                    header("location:{$url}");
                    break;
                case 'wap':
                    $params['scene_info'] = [
                        'payer_client_ip' => $request->ip(),
                        'h5_info'         => [
                            'type' => 'Wap',
                        ],
                    ];
                    //手机网页支付,跳转
                    $result = $pay->h5($params);
                    header("location:{$result->h5_url}");
                    break;
                case 'mini':
                case 'miniapp':
                    $params['payer'] = ['openid' => $openid];
                    $result          = $pay->mini($params);
                    break;
                default:
            }

        }
        return $result;

    }

    /**
     * 验证回调是否成功
     * @param string $type   支付类型
     * @param array  $config 配置信息
     * @return bool|Pay
     */
    public static function checkNotify($type, $config = [])
    {
        $type = strtolower($type);
        if (!in_array($type, ['wechat', 'alipay'])) {
            return false;
        }
        try {
            $pay  = Pay::$type(self::getConfig($type));
            $data = $pay->callback();
            if ($type == 'alipay') {
                if (in_array($data['trade_status'], ['TRADE_SUCCESS', 'TRADE_FINISHED'])) {
                    return $pay;
                }
            } else {
                return $pay;
            }
        } catch (Exception $e) {
            return false;
        }

        return false;
    }

    /**
     * 验证返回是否成功
     * @param string $type   支付类型
     * @param array  $config 配置信息
     * @return bool|Pay
     */
    public static function checkReturn($type, $config = [])
    {
        $type = strtolower($type);
        if (!in_array($type, ['wechat', 'alipay'])) {
            return false;
        }
        //微信无需验证
        if ($type == 'wechat') {
            return true;
        }
        try {
            $pay  = Pay::$type(self::getConfig($type));
            $data = $pay->callback();
            if ($data) {
                return $pay;
            }
        } catch (Exception $e) {
            return false;
        }
        return false;
    }

    /**
     * 获取配置
     */
    public static function getConfig($type = 'wechat', $custom = [])
    {
        $config         = get_addon_config('pay');
        $config         = isset($config[$type]) ? $config[$type] : $config['wechat'];
        $config['mode'] = (int) $config['mode'];

        // 日志
        if ($config['log']) {
            $config['log'] = [
                'enable' => true,
                'file'   => runtime_path() . 'log/epaylogs/' . $type . '-' . date("Y-m-d") . '.log',
                'level'  => 'debug',
            ];
        } else {
            $config['log'] = [
                'enable' => false,
            ];
        }

        // GuzzleHttp配置，可选
        $config['http'] = [
            'timeout'         => 10,
            'connect_timeout' => 10,
            // 更多配置项请参考 [Guzzle](https://guzzle-cn.readthedocs.io/zh_CN/latest/request-options.html)
        ];

        if ($type == 'wechat') {
            $config['mch_public_cert_path'] = ADDON_PATH . 'pay' . DS . 'certs' . DS . 'apiclient_cert.pem';
            $config['mch_secret_cert']      = ADDON_PATH . 'pay' . DS . 'certs' . DS . 'apiclient_key.pem';
            //强烈建议您手动配置 wechat_public_cert_path 参数
            /*$config['wechat_public_cert_path'] = [
        '36CF9C105ED5878715397F1A1BBDCD503CFA7AA31' => ADDON_PATH . 'pay' . DS . 'certs' . DS . 'wechatPublicKey.crt',
        ];*/
        }

        if ($type == 'alipay') {
            $config['app_public_cert_path']    = ADDON_PATH . 'pay' . DS . 'certs' . DS . 'alipay' . DS . 'appPublicCert.crt';
            $config['alipay_root_cert_path']   = ADDON_PATH . 'pay' . DS . 'certs' . DS . 'alipay' . DS . 'alipayRootCert.crt';
            $config['alipay_public_cert_path'] = ADDON_PATH . 'pay' . DS . 'certs' . DS . 'alipay' . DS . 'alipayPublicCert.crt';
        }

        //合并自定义配置
        $config = array_merge($config, $custom);

        $config = [$type => ['default' => $config], 'logger' => $config['log'], 'http' => $config['http'], '_force' => true];

        return $config;
    }

    /**
     * 获取微信Openid
     *
     * @return mixed|string
     */
    public static function getOpenid($custom = [])
    {
        $openid = '';
        $auth   = Auth::instance();
        if ($auth->isLogin()) {
            $synclogin = get_addon_info('synclogin');
            if ($synclogin && $synclogin['status']) {
                $syncInfo = \addons\synclogin\model\Synclogin::where('user_id', $auth->id)->where('platform', 'wechat')->where('apptype', 'mp')->find();
                $openid   = $syncInfo ? $syncInfo['openid'] : '';
            }
        }
        if (!$openid) {
            $openid = Session::get("openid");
            //如果未传openid，则去读取openid
            if (!$openid) {
                $addonConfig = get_addon_config('pay');
                $wechat      = new Wechat($custom['app_id'] ?? $addonConfig['wechat']['mp_app_id'], $custom['app_secret'] ?? $addonConfig['wechat']['mp_app_secret']);
                $openid      = $wechat->getOpenid();
            }
        }
        return $openid;
    }

}
