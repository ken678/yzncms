define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {
            //刷新验证码
            $("#verify").click(function() {
                var verifyimg = $("#verify").attr("src");
                $("#verify").attr("src", verifyimg.replace(/\?.*$/, '') + '?' + Math.random());
            });

            //点击充值金额
            $(document).on("click", ".row-money label[data-type]", function() {
                $(".row-money label[data-type]").removeClass("active");
                $(this).addClass("active");
                $("#col-custom").toggleClass("layui-hide", $(this).data("type") === "fixed");
                $("input[name=money]").val($(this).data("value"));
                if ($(this).data("type") === 'custom') {
                    $("input[name=custommoney]").trigger("focus").trigger("change");
                }
            });
            $(document).on("click", ".row-paytype label", function() {
                $(".row-paytype label").removeClass("active");
                $(this).addClass("active");
                $("input[name=paytype]").val($(this).data("value"));
            });
            $(document).on("keyup change", ".custommoney", function() {
                $("input[name=money]").val($(this).val());
            });
            $(".layui-form").on("submit", function() {
                var price = parseFloat($("input[name=money]").val());
                if (isNaN(price) || price <= 0) {
                    Layer.msg("充值金额不正确");
                    return false;
                }
            });
        },
        change_credit: function() {
            Form.api.bindevent($("form.layui-form"), function(data, res) {
                Layer.msg(res.msg, {
                    offset: '15px',
                    icon: 1,
                    time: 1000
                }, function() {
                    window.location.href = res.url;
                });
                return false;
            });
            $("#money").keyup(function() {
                $(this).val($(this).val().replace(/[^\d]/g, ''));
                $("#point").html($("#money").val() * Config.user_rmb_point_rate);
                if (Config.amount < $(this).val()) {
                    $("#alert").html('您的余额不足');
                } else {
                    $("#alert").html('');
                }
            });
        },
        pointlog: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'pay/pointlog',
                search: false,
                cols: [
                    [{
                            field: 'point',
                            width: 100,
                            title: '变更积分',
                            templet: function(d) {
                                if (d.point > 0) {
                                    return '<span class="layui-font-green">+' + d.point + '</span>';
                                } else {
                                    return '<span class="layui-font-red">' + d.point + '</span>';
                                }
                            }
                        },
                        { field: 'before', width: 100, title: '变更前' },
                        { field: 'after', width: 100, title: '变更后' },
                        { field: 'remark', title: '备注' },
                        { field: 'create_time', width: 160, title: '创建时间', search: 'range' },
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        amountlog: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'pay/amountlog',
                search: false,
                cols: [
                    [{
                            field: 'amount',
                            width: 100,
                            title: '变更余额',
                            templet: function(d) {
                                if (d.amount > 0) {
                                    return '<span class="layui-font-green">+' + d.amount + '</span>';
                                } else {
                                    return '<span class="layui-font-red">' + d.amount + '</span>';
                                }
                            }
                        },
                        { field: 'before', width: 100, title: '变更前' },
                        { field: 'after', width: 100, title: '变更后' },
                        { field: 'remark', title: '备注' },
                        { field: 'create_time', width: 160, title: '创建时间', search: 'range' },
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        }

    };
    return Controller;
});