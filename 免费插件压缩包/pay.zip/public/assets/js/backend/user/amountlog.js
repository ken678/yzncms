define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "user.amountlog/add",
                delete_url: "user.amountlog/del",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add'],
                url: 'user.amountlog/index',
                cols: [
                    [
                        { field: 'id', width: 80, title: 'ID' },
                        { field: 'user_id', width: 80, title: '用户id' },
                        { field: 'user.username', minWidth: 120, title: '用户名' },
                        { field: 'user.nickname', minWidth: 120, title: '用户昵称' },
                        {
                            field: 'amount',
                            title: '变更余额',
                            templet: function(d) {
                                if (d.amount > 0) {
                                    return '<span class="layui-font-green">+' + d.amount + '</span>';
                                } else {
                                    return '<span class="layui-font-red">' + d.amount + '</span>';
                                }
                            }
                        },
                        { field: 'before', title: '变更前' },
                        { field: 'after', title: '变更后' },
                        { field: 'remark', title: '备注' },
                        { field: 'create_time', width: 180, title: '创建时间' },
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});