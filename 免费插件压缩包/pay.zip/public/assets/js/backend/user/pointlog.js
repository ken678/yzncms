define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "user.pointlog/add",
                delete_url: "user.pointlog/del",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add'],
                url: 'user.pointlog/index',
                cols: [
                    [
                        { field: 'id', width: 80, title: 'ID' },
                        { field: 'user_id', width: 80, title: '用户id' },
                        { field: 'user.username', minWidth: 120, title: '用户名' },
                        { field: 'user.nickname', minWidth: 120, title: '用户昵称' },
                        {
                            field: 'point',
                            title: '变更积分',
                            templet: function(d) {
                                if (d.point > 0) {
                                    return '<span class="layui-font-green">+' + d.point + '</span>';
                                } else {
                                    return '<span class="layui-font-red">' + d.point + '</span>';
                                }
                            }
                        },
                        { field: 'before', title: '变更前' },
                        { field: 'after', title: '变更后' },
                        { field: 'remark', title: '备注' },
                        { field: 'create_time', width: 180, title: '创建时间' },
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});