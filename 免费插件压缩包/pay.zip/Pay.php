<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 支付插件
// +----------------------------------------------------------------------
namespace addons\pay;

use app\common\library\Menu;
use think\Addons;

class Pay extends Addons
{
    //后台菜单
    protected $menu = [
        [
            'name'    => 'user.amountlog',
            'title'   => '会员余额日志',
            'sublist' => [
                ['name' => 'user.amountlog/index', 'title' => '查看'],
                ['name' => 'user.amountlog/add', 'title' => '添加'],
                ['name' => 'user.amountlog/edit', 'title' => '修改'],
                ['name' => 'user.amountlog/del', 'title' => '删除'],
                ['name' => 'user.amountlog/multi', 'title' => '批量更新'],
            ],
        ],
        [
            'name'    => 'user.pointlog',
            'title'   => '会员积分日志',
            'sublist' => [
                ['name' => 'user.pointlog/index', 'title' => '查看'],
                ['name' => 'user.pointlog/add', 'title' => '添加'],
                ['name' => 'user.pointlog/edit', 'title' => '修改'],
                ['name' => 'user.pointlog/del', 'title' => '删除'],
                ['name' => 'user.pointlog/multi', 'title' => '批量更新'],
            ],
        ],
    ];

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        Menu::create($this->menu, 'user');
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('user.amountlog');
        Menu::delete('user.pointlog');
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable('user.amountlog');
        Menu::enable('user.pointlog');
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable('user.amountlog');
        Menu::disable('user.pointlog');
        return true;
    }

    //或者run方法
    public function userSidenavAfter($content)
    {
        return $this->fetch('userSidenavAfter');
    }

}
