<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 会员支付前台
// +----------------------------------------------------------------------
namespace app\index\controller;

use addons\pay\model\PayRechargeOrder;
use addons\pay\model\UserAmountLog;
use addons\pay\model\UserPointLog;
use app\common\controller\Frontend;
use app\common\model\User as UserModel;
use think\Exception;

class Pay extends Frontend
{
    protected $noNeedLogin = ['epay'];

    //充值
    public function index()
    {
        if ($this->request->isPost()) {
            $money   = $this->request->request('money/f');
            $paytype = $this->request->request('paytype');
            if (!$money || $money < 0) {
                $this->error("支付金额必须大于0");
            }
            if (!$paytype || !in_array($paytype, ['alipay', 'wechat'])) {
                $this->error("支付类型不能为空");
            }
            $config = get_addon_config('pay');
            if (isset($config['minmoney']) && $money < $config['minmoney']) {
                $this->error('充值金额不能低于' . $config['minmoney'] . '元');
            }
            //验证码
            if (!captcha_check($this->request->post('verify/s', ''))) {
                $this->error('验证码输入错误！');
                return false;
            }
            try {
                $response = PayRechargeOrder::submitOrder($money, $paytype ? $paytype : 'wechat');
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
            return $response;

        } else {
            $config    = get_addon_config('pay');
            $moneyList = [];
            foreach ($config['moneylist'] as $index => $item) {
                $moneyList[] = ['value' => $item, 'text' => $index, 'default' => $item === $config['defaultmoney']];
            }
            $paytypeList = [];
            foreach (explode(',', $config['paytypelist']) as $index => $item) {
                $paytypeList[] = ['value' => $item, 'image' => '/pay/images/' . $item . '-pay.png', 'default' => $item === $config['defaultpaytype']];
            }
            $this->assign('moneyList', $moneyList);
            $this->assign('paytypeList', $paytypeList);
            $this->assign('addonConfig', $config);
            $this->assign('title', '在线充值');
            return $this->fetch('index');
        }
    }

    //余额日志
    public function amountlog()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 1);

            $list = UserAmountLog::where('user_id', $this->auth->id)
                ->page($page, $limit)
                ->order('id DESC')
                ->select();
            $total = UserAmountLog::where('user_id', $this->auth->id)
                ->count();

            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);

        } else {
            $this->assign('title', '余额日志');
            return $this->fetch('amountlog');
        }
    }

    //积分日志
    public function pointlog()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 1);

            $list = UserPointLog::where('user_id', $this->auth->id)
                ->page($page, $limit)
                ->order('id DESC')
                ->select();
            $total = UserPointLog::where('user_id', $this->auth->id)
                ->count();

            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);

        } else {
            $this->assign('title', '积分日志');
            return $this->fetch('pointlog');
        }
    }

    //积分兑换
    public function change_credit()
    {
        if ($this->request->isPost()) {
            $money = $this->request->param('money/d', 0);
            if (!$money || $money < 0) {
                $this->error("兑换金额必须大于0");
            }
            $point = $money * config('yzn.user_rmb_point_rate');

            try {
                if ($this->auth->amount < $money) {
                    throw new Exception('余额不足，无法进行兑换');
                }
                //扣除金钱
                UserModel::amount(-$money, $this->auth->id, '积分兑换');
                //增加积分
                UserModel::point($point, $this->auth->id, '积分兑换');
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
            $this->success("兑换成功！");
        } else {
            $this->assignconfig('amount', $this->auth->amount);
            $this->assignconfig('user_rmb_point_rate', config('yzn.user_rmb_point_rate'));
            $this->assign('title', '积分兑换');
            return $this->fetch('change_credit');
        }
    }

    //企业支付通知和回调
    public function epay()
    {
        $type    = $this->request->param('type');
        $paytype = $this->request->param('paytype');
        if ($type == 'notify') {
            $pay = \addons\pay\library\Service::checkNotify($paytype);
            if (!$pay) {
                echo '签名错误';
                return;
            }
            try {
                $data = $pay->callback();
                if ($paytype === 'wechat') {
                    $data              = $data['resource']['ciphertext'];
                    $data['total_fee'] = $data['amount']['total'];
                }
                $payamount = $paytype == 'alipay' ? $data['total_amount'] : $data['total_fee'] / 100;

                PayRechargeOrder::settle($data['out_trade_no'], $payamount);
            } catch (Exception $e) {
                //写入日志
                // $e->getMessage();
            }
            return $pay->success();
        } else {
            $pay = \addons\pay\library\Service::checkReturn($paytype);
            if (!$pay) {
                $this->error('签名错误');
            }
            //你可以在这里定义你的提示信息,但切记不可在此编写逻辑
            $this->success("恭喜你！充值成功!", url("user/index"));
        }
        return;
    }
}
