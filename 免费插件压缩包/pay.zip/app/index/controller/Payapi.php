<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 支付API接口控制器
// +----------------------------------------------------------------------
namespace app\index\controller;

use addons\pay\library\Service;
use app\common\controller\Frontend;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
use think\facade\Session;
use think\Response;
use Yansongda\Pay\Exceptions\GatewayException;
use Yansongda\Pay\Pay;

class Payapi extends Frontend
{
    protected $noNeedLogin = ['*'];

    /**
     * 微信支付
     * @return string
     */
    public function wechat()
    {
        $config    = Service::getConfig('wechat');
        $isWechat  = stripos($this->request->server('HTTP_USER_AGENT'), 'MicroMessenger') !== false;
        $orderData = Session::get("wechatorderdata");
        $jumpUrl   = Session::get("jumpUrl") ?: url('index/pay/amountlog');
        if ($isWechat) {
            $type = 'jsapi';
            $this->assign("orderData", $orderData);
        } else {
            //检测订单状态
            if ($this->request->isPost()) {
                $pay = Pay::wechat($config);
                try {
                    $result = $pay->query(['out_trade_no' => $orderData['out_trade_no']]);
                    if ($result['trade_state'] == 'SUCCESS') {
                        $this->success('', $jumpUrl, ['trade_state' => $result['trade_state']]);
                    } else {
                        $this->error("查询失败");
                    }
                } catch (GatewayException $e) {
                    $this->error("查询失败");
                }
            }
            //发起PC支付(Native支付)
            $data = [
                'body'         => $orderData['body'],
                'code_url'     => $orderData['code_url'],
                'out_trade_no' => $orderData['out_trade_no'],
                'total_fee'    => $orderData['total_fee'],
            ];
            $type = 'pc';
            $this->assign("data", $data);
        }
        $this->assign("type", $type);
        return $this->fetch('wechat');
    }

    /**
     * 支付宝支付
     * @return string
     */
    public function alipay()
    {
        $config    = Service::getConfig('alipay');
        $orderData = Session::get("alipayorderdata");
        $jumpUrl   = Session::get("jumpUrl") ?: url('index/pay/amountlog');
        //检测订单状态
        if ($this->request->isPost()) {
            $pay = Pay::alipay($config);
            try {
                $result = $pay->query(['out_trade_no' => $orderData['out_trade_no']]);
                if (in_array($result['trade_status'], ['TRADE_SUCCESS', 'TRADE_FINISHED'])) {
                    $this->success('', $jumpUrl, ['trade_status' => $result['trade_status']]);
                } else {
                    $this->error("查询失败");
                }
            } catch (GatewayException $e) {
                $this->error("查询失败");
            }
        }
        $data = [
            'body'         => $orderData['body'],
            'qr_code'      => $orderData['qr_code'],
            'out_trade_no' => $orderData['out_trade_no'],
            'total_fee'    => $orderData['total_fee'],
        ];
        $this->assign("data", $data);
        return $this->fetch('alipay');
    }

    /**
     * 生成二维码
     * @return Response
     */
    public function qrcode()
    {
        $text   = $this->request->get('text', 'hello world');
        $result = Builder::create()
            ->writer(new PngWriter())
            ->writerOptions([])
            ->data($text)
            ->encoding(new Encoding('UTF-8'))
            ->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
            ->size(300)
            ->margin(10)
            ->roundBlockSizeMode(new RoundBlockSizeModeMargin())
            ->validateResult(false)
            ->build();

        return Response::create($result->getString(), 'html')->contentType('image/png');
    }

}
