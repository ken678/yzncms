<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 余额变动管理
// +----------------------------------------------------------------------
namespace app\admin\controller\user;

use app\admin\model\user\UserAmountLog;
use app\common\controller\Backend;
use app\common\model\User as UserModel;

class Amountlog extends Backend
{
    protected $modelValidate = true;
    protected $modelClass    = null;

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new UserAmountLog;
    }

    public function index()
    {
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            [$page, $limit, $where, $sort, $order] = $this->buildTableParames();
            $list                                  = $this->modelClass
                ->with('user')
                ->where($where)
                ->order($sort, $order)
                ->page($page, $limit)
                ->select();
            $total = $this->modelClass
                ->with('user')
                ->where($where)
                ->count();
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        return $this->fetch();
    }

    public function add()
    {
        if ($this->request->isPost()) {
            $row     = $this->request->post("row/a");
            $user_id = isset($row['user_id']) ? $row['user_id'] : 0;
            $amount  = isset($row['amount']) ? $row['amount'] : 0;
            $memo    = isset($row['memo']) ? $row['memo'] : '';
            if (!$user_id || !$amount) {
                $this->error("金额和会员ID不能为空");
            }
            UserModel::amount($amount, $user_id, $memo);
            $this->success("添加成功");
        }
        return parent::add();
    }

}
