<?php

return [
    [
        'name'  => 'rechargetips',
        'title' => '充值提示文字',
        'type'  => 'textarea',
        'value' => '余额可用于会员升级或购买商品',
    ],
    [
        'name'  => 'moneylist',
        'title' => '充值金额列表',
        'type'  => 'array',
        'value' => [
            '￥10'  => '10',
            '￥20'  => '20',
            '￥30'  => '30',
            '￥50'  => '50',
            '￥100' => '100',
        ],
    ],
    [
        'name'  => 'defaultmoney',
        'title' => '默认充值金额',
        'type'  => 'text',
        'value' => '10',
    ],
    [
        'name'  => 'minmoney',
        'title' => '最低充值金额',
        'type'  => 'text',
        'value' => '0.1',
    ],
    [
        'name'    => 'paytypelist',
        'title'   => '支付方式',
        'type'    => 'checkbox',
        'options' => [
            'wechat' => '微信支付',
            'alipay' => '支付宝支付',
        ],
        'value'   => 'wechat,alipay',
    ],
    [
        'name'    => 'defaultpaytype',
        'title'   => '默认支付方式',
        'type'    => 'radio',
        'options' => [
            'wechat' => '微信支付',
            'alipay' => '支付宝支付',
        ],
        'value'   => 'wechat',
    ],
    [
        'name'  => 'wechat',
        'title' => '微信',
        'type'  => 'array',
        'value' => [
            'mp_app_id'       => '',
            'mp_app_secret'   => '',
            'mini_app_id'     => '',
            'mch_id'          => '',
            'mch_secret_key'  => '',
            'mode'            => 0,
            'sub_mch_id'      => '',
            'sub_mp_app_id'   => '',
            'sub_app_id'      => '',
            'sub_mini_app_id' => '',
            'log'             => 1,
        ],
        'tip'   => '微信参数配置',
    ],
    [
        'name'  => 'alipay',
        'title' => '支付宝',
        'type'  => 'array',
        'value' => [
            'app_id'          => '',
            'app_secret_cert' => '',
            'isper'           => 0,
            'mode'            => 0,
            'log'             => 1,
        ],
        'tip'   => '支付宝参数配置',
    ],
];
