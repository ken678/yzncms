<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 支付模块模型
// +----------------------------------------------------------------------
namespace addons\pay\model;

use app\common\library\Auth;
use app\common\model\User;
use think\Model;

class PayRechargeOrder extends Model
{
    // 定义时间戳字段名
    protected $autoWriteTimestamp = true;
    protected $updateTime         = false;

    /**
     * 发起订单支付
     * @param float  $money
     * @param string $paytype
     */
    public static function submitOrder($money, $paytype = 'wechat', $method = 'web', $openid = '', $notifyurl = '', $returnurl = '')
    {
        $auth    = Auth::instance();
        $user_id = $auth->isLogin() ? $auth->id : 0;

        $order = self::where('user_id', $user_id)->where('amount', $money)->where('status', 'unpay')->order('id', 'desc')->find();
        if (!$order) {
            $orderid = date("Ymdhis") . sprintf("%08d", $user_id) . mt_rand(1000, 9999);
            $data    = [
                'orderid'   => $orderid,
                'user_id'   => $user_id,
                'amount'    => $money,
                'payamount' => 0,
                'paytype'   => $paytype,
                'ip'        => request()->ip(),
                'useragent' => substr(request()->server('HTTP_USER_AGENT'), 0, 255),
                'status'    => 'unpay',
            ];
            $order = self::create($data);
        }
        $notifyurl = request()->domain() . '/index/pay/epay/type/notify/paytype/' . $paytype;
        $returnurl = request()->domain() . '/index/pay/epay/type/return/paytype/' . $paytype;

        $params = [
            'amount'    => $money,
            'orderid'   => $order->orderid,
            'type'      => $paytype,
            'title'     => "充值{$money}元",
            'notifyurl' => $notifyurl,
            'returnurl' => $returnurl,
            'method'    => $method,
            'openid'    => $openid,
        ];

        //小程序和公众号openid不能为空
        if (in_array($method, ['mp', 'miniapp']) && empty($openid)) {
            throw new Exception("公众号和小程序支付openid不能为空！");
        }

        $response = \addons\pay\library\Service::submitOrder($params);
        return $response;
    }

    /**
     * 订单结算
     * @param int    $orderid
     * @param string $payamount
     * @param string $remark
     * @return bool
     */
    public static function settle($orderid, $payamount = null, $remark = '')
    {
        $order = PayRechargeOrder::where('orderid', $orderid)->find();
        if (!$order) {
            return false;
        }
        if ($payamount != $order['amount']) {
            \think\facade\Log::write("[pay][{$orderid}][订单支付金额不一致]");
            return false;
        }
        if ($order['status'] != 'succ') {
            $order->payamount = $payamount;
            $order->pay_time  = time();
            $order->status    = 'succ';
            $order->remark    = $remark;
            $order->save();
            // 更新会员余额
            User::amount($payamount, $order->user_id, '充值');
        }
        return true;
    }

}
