<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 采集模型
// +----------------------------------------------------------------------
namespace app\admin\model\collection;

use think\Model;

class Node extends Model
{
    protected $name = 'collection_node';

    public function getListConfigTextAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['list_config'], true);
    }

    public function getContentConfigTextAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['content_config'], true);
    }

    public static function onBeforeWrite($row)
    {
        $row['urlpage'] = $row['urlpage'] ?? ($row['sourcetype'] == 1 ? $row['urlpage1'] : $row['urlpage2']);
        unset($row['urlpage1'], $row['urlpage2']);
    }
}
