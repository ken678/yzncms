<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 采集模型
// +----------------------------------------------------------------------
namespace app\admin\model\collection;

use think\Model;

class Program extends Model
{
    protected $name = 'collection_program';

    public function setConfigAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }

    public function getConfigAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['config'], true);
    }
}
