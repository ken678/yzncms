<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 采集管理
// +----------------------------------------------------------------------
namespace app\admin\controller\collection;

use app\admin\model\collection\Content as ContentModel;
use app\admin\model\collection\Node as NodeModel;
use app\common\controller\Backend;

class Node extends Backend
{
    protected $modelValidate = true;

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new NodeModel;
    }

    //网址采集
    public function col_url_list()
    {
        set_time_limit(0);
        //@session_start();
        //\think\facade\Session::pause();
        $nid                    = $this->request->param('id/d', 0);
        $data                   = $this->modelClass->find($nid);
        $data['content_config'] = $data['content_config'];
        $data['list_config']    = $data['list_config'];
        $event                  = new \addons\collection\library\Collection;
        $event->init($data);
        $urls       = $event->url_list();
        $total_page = count($urls);
        if ($total_page > 0) {
            foreach ($urls as $key => $vo) {
                $listData = $event->get_url_lists($vo);
                $event->echo_msg("采集起始页：<a href='{$vo}' target='_blank'>{$vo}</a>", 'green');
                if (is_array($listData) && !empty($listData)) {
                    foreach ($listData as $v) {
                        if (empty($v['url']) || empty($v['title'])) {
                            continue;
                        }
                        //是否采集过
                        if (!ContentModel::where(['url' => $v['url']])->find()) {
                            $contentData = $event->get_content($v['url']);
                            $allData     = array_merge($v, $contentData);
                            $event->echo_msg("采集内容页：<a href='{$v['url']}' target='_blank'>{$v['url']}</a>", 'black');
                            ContentModel::create([
                                'nid'    => $nid,
                                'status' => 1,
                                'url'    => $v['url'],
                                'title'  => mb_substr(trim($v['title']), 0, 100),
                                'data'   => $allData,
                            ]);
                        }
                    }
                }
            }
            $this->modelClass->update(['lastdate' => time(), 'id' => $nid]);
            $event->echo_msg('网址采集已完成！');
        } else {
            $event->echo_msg('网址采集已完成！');
        }
    }

    //导出
    public function export()
    {
        $id  = $this->request->param('id/d');
        $row = $this->modelClass->find($id);
        if (!$row) {
            $this->error('采集项目不存在');
        }
        $data = $row->getData();
        return download(base64_encode(json_encode($data)), 'task_' . $id . '.txt', true, 0);
    }

    //导入
    public function import()
    {
        $file = $this->request->param('file');
        if (!$file) {
            $this->error('参数file不能为空');
        }
        $filePath = public_path() . DS . $file;
        if (!is_file($filePath)) {
            $this->error('记录未找到');
        }
        $data = file_get_contents($filePath);
        $data = json_decode(base64_decode($data), true);
        try {
            unset($data['id']);
            NodeModel::create($data);
        } catch (\Exception $e) {
            $this->error($e->getMessage());
        }
        $this->success('新增成功！', url('index'));
    }

}
