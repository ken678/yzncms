<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 采集内容管理
// +----------------------------------------------------------------------
namespace app\admin\controller\collection;

use app\admin\model\collection\Content as ContentModel;
use app\common\controller\Backend;

class Content extends Backend
{
    protected $modelValidate = true;

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new ContentModel;
        $this->assignconfig('type', $this->request->param('type/d', 0));
    }

    //文章列表
    public function index()
    {
        $this->request->only(['id', 'type', 'limit', 'page']);
        $param   = $this->request->param();
        $where   = [];
        $where[] = ['nid', '=', $param['id']];
        if (isset($param['type']) && !empty($param['type'])) {
            $where[] = ['status', '=', $param['type']];
        }
        if ($this->request->isAjax()) {
            $limit = intval($param['limit']) < 10 ? 10 : $param['limit'];
            $page  = intval($param['page']) < 1 ? 1 : $param['page'];
            $data  = ContentModel::where($where)
                ->page($page, $limit)
                ->order('id', 'desc')
                ->select();
            $total = ContentModel::where($where)->order('id', 'desc')->count();
            return json(["code" => 0, "count" => $total, "data" => $data]);
        }
        $this->assign('param', $param);
        return $this->fetch();
    }

    public function show()
    {
        $id  = $this->request->param('id/d', 0);
        $row = ContentModel::where('id', $id)->find();
        $this->assign('data', $row['data']);
        return $this->fetch();
    }

}
