<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 方案管理
// +----------------------------------------------------------------------
namespace app\admin\controller\collection;

use addons\cms\library\Service;
use app\admin\model\cms\Category as CategoryModel;
use app\admin\model\cms\Cms as CmsModel;
use app\admin\model\collection\Content as ContentModel;
use app\admin\model\collection\Node as NodeModel;
use app\admin\model\collection\Program as ProgramModel;
use app\common\controller\Backend;

class Program extends Backend
{
    protected function initialize()
    {
        parent::initialize();
        $this->CmsModel   = new CmsModel;
        $this->modelClass = new ProgramModel;
        $this->assignconfig('id', $this->request->param('id/d', 0));
    }

    //导入文章
    public function index()
    {
        $nid = $this->request->param('id/d', 0);
        if ($this->request->isAjax()) {
            $data = $this->modelClass->where('nid', $nid)->select();
            return json(["code" => 0, "data" => $data]);
        }
        $this->assign('id', $nid);
        return $this->fetch();
    }

    //添加方案
    public function add()
    {
        $nid   = $this->request->param('id/d', 0);
        $catid = $this->request->param('catid/d', 0);
        $title = $this->request->param('title/s', '');
        if ($this->request->isPost()) {
            $modelid = CategoryModel::where('id', $catid)->value('modelid');
            $config  = [];
            $data    = $this->request->post();
            foreach ($data['node_field'] as $k => $v) {
                if (empty($v)) {
                    continue;
                }
                $config[$data['model_type'][$k]][$data['model_field'][$k]] = $v;
            }
            foreach ($data['funcs'] as $k => $v) {
                if (empty($v)) {
                    continue;
                }
                $config['funcs'][$data['model_field'][$k]] = $v;
            }
            $result = $this->modelClass->save([
                'nid'     => $nid,
                'catid'   => $catid,
                'modelid' => $modelid,
                'title'   => $title,
                'config'  => $config,
            ]);
            if (false !== $result) {
                $this->success("添加成功！", url('import', ['id' => $nid]));
            } else {
                $this->error('添加失败！');
            }

        } else {
            $tree  = new \util\Tree();
            $str   = "<option value=@catidurl @selected @disabled>@spacer @catname</option>";
            $array = CategoryModel::order('listorder ASC, id ASC')->column('*', 'id');
            foreach ($array as $k => $v) {
                if ($v['id'] == $catid) {
                    $array[$k]['selected'] = "selected";
                }
                //含子栏目和单页不可以发表
                if ($v['child'] == 1 || $v['type'] == 1) {
                    $array[$k]['disabled'] = "disabled";
                    $array[$k]['catidurl'] = '';
                } else {
                    $array[$k]['disabled'] = "";
                    $array[$k]['catidurl'] = url('add', ['id' => $nid, 'catid' => $v['id']]);
                }
            }
            $tree->init($array);
            $category = $tree->getTree(0, $str);
            $cat_info = [];
            if ($catid) {
                $cat_info   = CategoryModel::field('catname,modelid')->where('id', $catid)->find();
                $data       = Service::getFieldList($cat_info['modelid']);
                $_node      = NodeModel::where('id', $nid)->find();
                $node_data  = array_merge($_node['list_config_text'], $_node['content_config_text']);
                $node_field = [];
                if (is_array($node_data)) {
                    foreach ($node_data as $k => $v) {
                        if (empty($v['name']) || empty($v['title'])) {
                            continue;
                        }
                        $node_field[$v['name']] = $v['title'];
                    }
                }
                $this->assign("node_field", $node_field);
                $this->assign("data", $data);
            }
            $this->assign("catname", $cat_info['catname'] ?? '');
            $this->assign("category", $category);
            $this->assign('id', $nid);
            $this->assign('catid', $catid);
            return $this->fetch();
        }
    }

    //方案编辑
    public function edit()
    {
        $id  = $this->request->param('id/d', 0);
        $row = $this->modelClass->find($id);
        if (!$row) {
            $this->error('记录未找到');
        }
        if ($this->request->isPost()) {
            $config = [];
            $data   = $this->request->post();
            foreach ($data['node_field'] as $k => $v) {
                if (empty($v)) {
                    continue;
                }
                $config[$data['model_type'][$k]][$data['model_field'][$k]] = $v;
            }
            foreach ($data['funcs'] as $k => $v) {
                if (empty($v)) {
                    continue;
                }
                $config['funcs'][$data['model_field'][$k]] = $v;
            }
            $row->title  = $data['title'];
            $row->config = $config;
            $row->save();
            $this->success("修改成功！");
        } else {
            $tree = new \util\Tree();
            $str  = "<option value=@catidurl @selected @disabled>@spacer @catname</option>";
            $cate = CategoryModel::order('listorder ASC, id ASC')->column('*', 'id');
            foreach ($cate as $k => $v) {
                if ($v['id'] == $row['catid']) {
                    $cate[$k]['selected'] = "selected";
                }
                //含子栏目和单页不可以发表
                if ($v['child'] == 1 || $v['type'] == 1) {
                    $cate[$k]['disabled'] = "disabled";
                    $cate[$k]['catidurl'] = '';
                } else {
                    $cate[$k]['disabled'] = "";
                    $cate[$k]['catidurl'] = url('add_program', ['id' => $id, 'catid' => $v['id']]);
                }
            }
            $tree->init($cate);
            $category = $tree->getTree(0, $str);

            $cat_info = CategoryModel::field('catname,modelid')->where('id', $row['catid'])->find();
            $field    = Service::getFieldList($cat_info['modelid']);

            $_node     = NodeModel::where('id', $row['nid'])->find();
            $node_data = array_merge($_node['list_config_text'], $_node['content_config_text']);

            foreach ($field as $key => $value) {
                if ($value['fieldArr'] == 'modelField') {
                    if (isset($row['config']['modelField'][$value['name']])) {
                        $field[$key]['value'] = $row['config']['modelField'][$value['name']];
                    }
                }
                if ($value['fieldArr'] == 'modelFieldExt') {
                    if (isset($row['config']['modelFieldExt'][$value['name']])) {
                        $field[$key]['value'] = $row['config']['modelFieldExt'][$value['name']];
                    }
                }
                $field[$key]['funcs'] = isset($row['config']['funcs'][$value['name']]) ? $row['config']['funcs'][$value['name']] : '';
            }
            $node_field = [];
            if (is_array($node_data)) {
                foreach ($node_data as $k => $v) {
                    if (empty($v['name']) || empty($v['title'])) {
                        continue;
                    }
                    $node_field[$v['name']] = $v['title'];
                }
            }
            $this->assign("node_field", $node_field);
            $this->assign("field", $field);
            $this->assign("data", $row);
            $this->assign("catname", $cat_info['catname']);
            $this->assign("category", $category);
            $this->assign('id', $id);
            $this->assign('catid', $row['catid']);
            return $this->fetch();
        }
    }

    //导入文章到模型
    public function import()
    {
        $id  = $this->request->param('id/d', 0);
        $row = $this->modelClass->find($id);
        if (!$row) {
            $this->error('记录未找到');
        }

        $content = ContentModel::where('nid', $row['nid'])->where('status', 1)->select();

        foreach ($content as $k => $v) {
            $data['modelField'] = ['catid' => $row['catid'], 'status' => 1];
            if (!$v['data']) {
                continue;
            }
            foreach ($row['config']['modelField'] as $a => $b) {
                if (isset($row['config']['funcs'][$a])) {
                    $data['modelField'][$a] = $this->parseFunction($row['config']['funcs'][$a], $v['data'][$b]);
                } else {
                    $data['modelField'][$a] = $v['data'][$b];
                }
            }
            if (isset($row['config']['modelFieldExt'])) {
                foreach ($row['config']['modelFieldExt'] as $a => $b) {
                    if (isset($row['config']['funcs'][$a])) {
                        $data['modelFieldExt'][$a] = $this->parseFunction($row['config']['funcs'][$a], $v['data'][$b]);
                    } else {
                        $data['modelFieldExt'][$a] = $v['data'][$b];
                    }
                }
            }
            try {
                $this->CmsModel->addModelData($data['modelField'], $data['modelFieldExt']);
            } catch (\Exception $ex) {
                $this->error($ex->getMessage());
            }
            //更新状态
            $v->status = 2;
            $v->save();
        }
        $this->success('操作成功！');
    }

    protected function parseFunction($match, $content)
    {
        $varArray = explode('|', $match);
        $length   = count($varArray);
        for ($i = 0; $i < $length; $i++) {
            $args = explode('=', $varArray[$i], 2);
            $fun  = trim($args[0]);
            if (isset($args[1])) {
                $args[1] = explode(',', $args[1]);
                if (false !== $key = array_search("###", $args[1])) {
                    $args[1][$key] = $content;
                    $content       = call_user_func_array($fun, $args[1]);
                } else {
                    $content = call_user_func_array($fun, array_merge([$content], $args[1]));
                }
            } else {
                if (!empty($args[0])) {
                    $content = $fun($content);
                }
            }
        }
        return $content;
    }
}
