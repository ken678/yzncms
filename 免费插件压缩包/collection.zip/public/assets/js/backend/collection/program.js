define(['jquery', 'table', 'form'], function($, Table, Form) {
    Yzn.config.openArea = ['900px', '80%'];
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: 'collection.program/add?id=' + Config.id,
                edit_url: 'collection.program/edit',
                delete_url: 'collection.program/del',
                import_url: 'collection.program/import',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add'],
                url: 'collection.program/index?id=' + Config.id,
                cols: [
                    [
                        { field: 'id', width: 70, title: 'ID' },
                        { field: 'title', title: '方案名称' },
                        {
                            fixed: 'right',
                            width: 130,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    class: 'layui-btn layui-btn-xs layui-btn-normal btn-ajax',
                                    url: Table.init.import_url,
                                    auth: 'import',
                                    text: "导入",
                                    extend: "",
                                }], 'edit', 'delete'
                            ]
                        }
                    ]
                ]
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
                layui.form.on('select(filter)', function(data) {
                    location.href = data.value + '&dialog=1';
                });

                layui.form.on('select(funcs)', function(data) {
                    var dom = $(data.elem).parent().parent('td').find('.layui-input');
                    if (dom.val() == '') {
                        dom.val($(data.elem).find("option:selected").attr("data-fun"));
                    } else {
                        dom.val(dom.val() + '|' + $(data.elem).find("option:selected").attr("data-fun"));
                    }
                });
            }
        }
    };
    return Controller;
});