define(['jquery', 'table', 'form'], function($, Table, Form) {
    Yzn.config.openArea = ['80%', '80%'];
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "collection.node/add",
                edit_url: "collection.node/edit",
                delete_url: "collection.node/del",
                export_url: "collection.node/export",
                import_url: "collection.node/import",
            };
            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add', 'delete', [{
                    text: '配置导入',
                    class: 'layui-btn layui-btn-sm btn-import',
                    icon: "iconfont icon-upload-fill",
                    extend: 'lay-event="btn-import" data-mimetype="txt" data-type="file"',
                    auth: 'import',
                }]],
                url: 'collection.node/index',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'id', width: 80, title: 'ID', sort: true },
                        { field: 'name', align: "left", title: '名称' },
                        { field: 'lastdate', width: 180, title: '最后采集时间', templet: Table.formatter.datetime, search: 'range' },
                        { width: 200, title: '内容操作', templet: '#caijiTool' },
                        {
                            width: 160,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    text: '配置导出',
                                    url: Table.init.export_url,
                                    method: 'href',
                                    auth: 'export',
                                    class: 'layui-btn layui-btn-xs layui-btn-warm',
                                    extend: 'target="_blank"',
                                }], 'edit', 'delete'
                            ]
                        }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
                layui.form.on('radio(urlType)', function(data) {
                    if (2 == data.value) {
                        $('.url_type').hide();
                        $('.url_type2').show();
                    }
                    if (1 == data.value) {
                        $('.url_type').show();
                        $('.url_type2').hide();
                    }
                });
            }
        }
    };
    return Controller;
});