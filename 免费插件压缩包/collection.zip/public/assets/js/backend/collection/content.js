define(['jquery', 'table'], function($, Table) {
    var Controller = {
        index: function() {

            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                delete_url: 'collection.content/del' + location.search,
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'delete', [{
                    class: 'layui-btn layui-btn-sm layui-btn-warm',
                    url: 'collection.program/index' + location.search,
                    hidden: function(j) {
                        return Config.type !== 1;
                    },
                    auth: 'program',
                    text: "全部导入",
                    extend: "",
                }]],
                url: 'collection.content/index' + location.search,
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'status', title: '状态', width: 80, templet: '<div>{{#  if(d.status==2){ }} <button class="layui-btn layui-btn layui-btn-xs">已导入</button> {{#  } else { }} <button class="layui-btn layui-btn-danger layui-btn layui-btn-xs">未导入</button> {{#  } }} </div>' },
                        { field: 'title', title: '标题' },
                        { field: 'url', title: '网址' },
                        {
                            fixed: 'right',
                            width: 120,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    class: 'layui-btn layui-btn-xs layui-btn-normal btn-dialog',
                                    icon: 'iconfont icon-eye-line',
                                    auth: 'delete',
                                    text: "查看",
                                    title: 'show',
                                    url: 'collection.content/show',
                                    extend: "",
                                }], 'delete'
                            ]
                        }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
    };
    return Controller;
});