<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 采集插件
// +----------------------------------------------------------------------
namespace addons\collection;

use app\common\library\Menu;
use Composer\Autoload\ClassLoader;
use think\Addons;

class Collection extends Addons
{
    //后台菜单
    protected $menu = [
        [
            "name"    => "collection",
            "title"   => "采集任务",
            "sublist" => [
                [
                    "name"    => "collection.node",
                    "title"   => "采集任务",
                    "sublist" => [
                        ["name" => "collection.node/index", "title" => "查看"],
                        ["name" => "collection.node/add", "title" => "新增"],
                        ["name" => "collection.node/edit", "title" => "编辑"],
                        ["name" => "collection.node/del", "title" => "删除"],
                        ["name" => "collection.node/col_url_list", "title" => "采集"],
                        ["name" => "collection.node/export", "title" => "导出"],
                        ["name" => "collection.node/import", "title" => "导入"],
                    ],
                ],
                [
                    "name"    => "collection.content",
                    "title"   => "采集内容",
                    "ismenu"  => 0,
                    "sublist" => [
                        ["name" => "collection.content/index", "title" => "文章列表"],
                        ["name" => "collection.content/show", "title" => "详情"],
                        ["name" => "collection.content/del", "title" => "采集数据删除"],
                    ],
                ],
                [
                    "name"    => "collection.program",
                    "title"   => "采集方案",
                    "ismenu"  => 0,
                    "sublist" => [
                        ["name" => "collection.program/index", "title" => "查看"],
                        ["name" => "collection.program/add", "title" => "新增"],
                        ["name" => "collection.program/edit", "title" => "编辑"],
                        ["name" => "collection.program/del", "title" => "删除"],
                        ["name" => "collection.program/import", "title" => "导入模型"],
                    ],
                ],
            ],
        ],

    ];

    //安装
    public function install()
    {
        if (version_compare(PHP_VERSION, '8.1.0', '<')) {
            throw new \think\Exception("运行此插件需PHP8.1及以上版本");
        }
        Menu::create($this->menu);
        return true;
    }

    //卸载
    public function uninstall()
    {
        Menu::delete("collection");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("collection");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("collection");
        return true;
    }

    /**
     * 添加命名空间
     */
    public function appInit()
    {
        if (!class_exists('\QL\QueryList')) {
            $vendorDir = ADDON_PATH . 'collection' . DS . 'SDK' . DS;

            $map = [
                'Symfony\\Contracts\\Service\\'     => [$vendorDir . '/symfony/service-contracts'],
                'Symfony\\Contracts\\Cache\\'       => [$vendorDir . '/symfony/cache-contracts'],
                'Symfony\\Component\\VarExporter\\' => [$vendorDir . '/symfony/var-exporter'],
                'Symfony\\Component\\Cache\\'       => [$vendorDir . '/symfony/cache'],
                'QL\\'                              => [$vendorDir . '/jaeger/querylist/src'],
                'Psr\\Cache\\'                      => [$vendorDir . '/psr/cache/src'],
                'Jaeger\\'                          => [$vendorDir . '/jaeger/g-http/src'],
            ];
            $classMap = [
                'Callback'                     => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'CallbackBody'                 => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'CallbackParam'                => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'CallbackParameterToReference' => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'CallbackReturnReference'      => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'CallbackReturnValue'          => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'DOMDocumentWrapper'           => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'DOMEvent'                     => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'ICallbackNamed'               => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'phpQuery'                     => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'phpQueryEvents'               => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'phpQueryObject'               => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                'phpQueryPlugins'              => $vendorDir . '/jaeger/phpquery-single/phpQuery.php',
                '©'                            => $vendorDir . '/symfony/cache/Traits/ValueWrapper.php',
            ];
            $loader = new ClassLoader();
            foreach ($map as $namespace => $path) {
                $loader->setPsr4($namespace, $path);
            }
            if ($classMap) {
                $loader->addClassMap($classMap);
            }
            $loader->register(true);
        }
    }

}
