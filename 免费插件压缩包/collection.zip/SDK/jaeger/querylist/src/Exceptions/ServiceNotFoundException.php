<?php
/**
 * Created by PhpStorm.
 * User: Jaeger <JaegerCode@gmail.com>
 * Date: 2017/9/21
 */

namespace QL\Exceptions;

use Exception;

class ServiceNotFoundException extends Exception
{

}