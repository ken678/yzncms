define(['jquery', 'form'], function($, Form) {

    var Controller = {
        index: function() {
            Form.api.bindevent($("#form-baidu"), function(data, ret) {
                html = '成功推送的url条数:' + data.success + '\n';
                html += '当天剩余的可推送url条数:' + data.remain + '\n';
                $("#form-baidu textarea[name=result]").val(html);
            }, function(data, ret) {
                html = ret.msg + '\n';
                $("#form-baidu textarea[name=result]").val(html);
            });
            Form.api.bindevent($("#form-shenma"), function(data, ret) {
                html = ret.msg + '\n';
                $("#form-shenma textarea[name=result]").val(html);
            }, function(data, ret) {
                html = ret.msg + '\n';
                $("#form-shenma textarea[name=result]").val(html);
            });
        }
    };
    return Controller;
});