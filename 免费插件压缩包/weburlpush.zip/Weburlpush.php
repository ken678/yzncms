<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 聚合推送插件
// +----------------------------------------------------------------------
namespace addons\weburlpush;

use addons\weburlpush\library\Push;
use app\common\library\Menu;
use think\Addons;

class Weburlpush extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                "name"    => "weburlpush",
                "title"   => "百度推送",
                "sublist" => [
                    ["name" => "weburlpush/index", "title" => "查看"],
                    ["name" => "weburlpush/baidu", "title" => "百度推送"],
                    ["name" => "weburlpush/shenma", "title" => "神马推送"],
                ],
            ],
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("weburlpush");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("weburlpush");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("weburlpush");
        return true;
    }

    public function weburlpush(Push $push, $params, $extra = null)
    {
        $config = $this->getAddonConfig();
        $urls   = is_string($params) ? [$params] : $params;
        $extra  = $extra ? $extra : 'push';
        $status = explode(',', $config['status']);
        try {
            foreach ($status as $index => $item) {
                if ($extra == 'push') {
                    $push->channel($item)->push($urls);
                }
            }
        } catch (\Exception $e) {
            //$this->error("推送失败：" . $e->getMessage());
        }
    }

}
