<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 网站地图插件
// +----------------------------------------------------------------------
namespace addons\sitemap;

use app\common\library\Menu;
use think\Addons;

class Sitemap extends Addons
{
    //后台菜单
    protected $menu = [
        [
            "name"    => "sitemap",
            "title"   => "网站地图",
            "icon"    => "iconfont icon-map-2-line",
            'sublist' => [
                ['name' => 'sitemap/index', 'title' => '查看/提交'],
            ],
        ],
    ];

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        Menu::create($this->menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("sitemap");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("sitemap");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("sitemap");
        return true;
    }

}
