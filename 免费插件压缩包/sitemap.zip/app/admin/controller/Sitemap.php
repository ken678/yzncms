<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | sitemap管理
// +----------------------------------------------------------------------
namespace app\admin\controller;

use addons\sitemap\library\Sitemap as SitemapLib;
use app\common\controller\Backend;
use think\facade\Db;

class Sitemap extends Backend
{
    protected $filename = 'sitemap.xml';
    protected $data     = [];
    protected $directory;
    protected $url_mode = 1;

    protected function initialize()
    {
        parent::initialize();
        $this->url_mode  = (int) get_addon_config('cms')['site_url_mode'];
        $this->directory = public_path();
    }

    public function index()
    {
        if ($this->request->isPost()) {
            $info = get_addon_info('cms');
            if (!$info || $info['status'] != 1) {
                $this->error("请在后台插件管理中安装《内容管理系统》并启用后再尝试");
            }
            $Category = cache('Category');
            $data     = $this->request->post();
            $Sitemap  = new SitemapLib();
            $rootUrl  = $this->request->domain();

            $item = $this->sitemap_item($rootUrl, intval($data['index']['priority']), $data['index']['changefreq'], time());
            $this->add_data($item);

            //栏目
            $List = Db::name('cms_category')->where('status', 1)->order('id desc')->field('id,url,catdir')->select();
            if (!empty($List)) {
                foreach ($List as $vo) {
                    $cat  = $this->url_mode == 1 ? $vo['id'] : $vo['catdir'];
                    $item = $this->sitemap_item($rootUrl . buildCatUrl($cat), intval($data['category']['priority']), $data['category']['changefreq'], time());
                    $this->add_data($item);
                }
            }

            //列表
            $modelList = cache('Model');
            if (!empty($modelList)) {
                $num    = 1;
                $volist = [];
                foreach ($modelList as $vo) {
                    if ($vo['module'] == "cms") {
                        $volist = Db::name($vo['tablename'])->where('status', 1)->order('update_time desc')->field('id,catid,update_time')->select();
                        if (!empty($volist)) {
                            foreach ($volist as $v) {
                                $cat  = $this->url_mode == 1 ? $v['catid'] : (isset($Category[$v['catid']]) ? $Category[$v['catid']]['catdir'] : getCategory($v['catid'], 'catdir'));
                                $item = $this->sitemap_item($rootUrl . buildContentUrl($cat, $v['id']), intval($data['content']['priority']), $data['content']['changefreq'], $v['update_time']);
                                $this->add_data($item);
                                $num++;
                                if ($num >= $data['num']) {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            //标签
            $tags = Db::name('cms_tags')->order('create_time desc')->field('tag,update_time')->select();
            if (!empty($tags)) {
                foreach ($tags as $vo) {
                    $item = $this->sitemap_item($rootUrl . addon_url('cms/tags/index', [':tag' => $vo['tag']]), intval($data['tag']['priority']), $data['tag']['changefreq'], time());
                    $this->add_data($item);
                }
            }
            if (!$data['type']) {
                try {
                    foreach ($this->data as $val) {
                        $Sitemap->AddItem($val['loc'], $val['priority'], $val['changefreq'], $val['lastmod']);
                    }
                    $Sitemap->SaveToFile($this->directory . $this->filename);
                } catch (\Exception $ex) {
                    $this->error($ex->getMessage());
                }
            } else {
                $str            = $this->txt_format();
                $this->filename = 'sitemap.txt';
                @file_put_contents($this->directory . $this->filename, $str);
            }
            $this->success($this->filename . "文件已生成到运行根目录");

        } else {

            if (is_file($this->directory . 'sitemap.xml')) {
                $make_xml_time = date('Y-m-d H:i:s', filemtime($this->directory . 'sitemap.xml'));
                $this->assign('make_xml_time', $make_xml_time);
            }
            if (is_file($this->directory . 'sitemap.txt')) {
                $make_txt_time = date('Y-m-d H:i:s', filemtime($this->directory . 'sitemap.txt'));
                $this->assign('make_txt_time', $make_txt_time);
            }
            return $this->fetch();
        }
    }

    /**
     * 添加数据
     */
    private function add_data($new_item)
    {
        $this->data[] = $new_item;
    }

    /**
     * 生成txt格式
     */
    private function txt_format()
    {
        $str = '';
        foreach ($this->data as $val) {
            $str .= $val['loc'] . PHP_EOL;
        }
        return $str;
    }

    /**
     * 创建地图格式
     */
    private function sitemap_item($loc, $priority = '', $changefreq = '', $lastmod = '')
    {
        $data               = [];
        $data['loc']        = $loc;
        $data['priority']   = $priority;
        $data['changefreq'] = $changefreq;
        $data['lastmod']    = $lastmod;
        return $data;
    }

}
