define(['jquery', 'form'], function($, Form) {

    var Controller = {
        index: function() {
            Form.api.bindevent($("form.layui-form"));
        }
    };
    return Controller;
});