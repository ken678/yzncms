    require.config({
        paths: {
            'locationX': '../addons/address/locationX',
            'location': '../addons/address/location',
        },
        shim: {
            'location': {
                deps: ['css!../addons/address/location.css']
            }
        }
    });

    require(['form'], function(Form) {
        var _bindevent = Form.events.bindevent;
        Form.events.bindevent = function(form) {
            _bindevent.apply(this, [form]);
            if ($("#locationBtn", form).size() > 0) {
                require(['location'], function(Location) {
                    Location.render("#locationBtn", {
                        type: 1,
                        apiType: "baiduMap",
                        coordinate: "baiduMap",
                        mapType: 2,
                        zoom: 15,
                        title: '区域定位',
                        init: function() {
                            return { longitude: $("#longitude").val(), latitude: $("#latitude").val() };
                        },
                        success: function(data) {
                            $("#longitude").val(data.lng);
                            $("#latitude").val(data.lat);
                        }
                    });
                })
            }
        }
    })