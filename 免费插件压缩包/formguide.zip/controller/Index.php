<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单前台管理
// +----------------------------------------------------------------------

namespace addons\formguide\controller;

use addons\formguide\library\Service;
use addons\formguide\model\Models;
use think\addons\Controller;
use think\facade\Config;
use think\facade\Db;
use think\facade\Event;

class Index extends Controller
{
    //当前表单ID
    public $formid;
    //表单模型缓存
    protected $tableName;
    //模型信息
    protected $modelInfo = [];
    //配置
    protected $setting = [];

    protected $noNeedLogin = ['*'];
    protected $noNeedRight = [];

    protected function initialize()
    {
        parent::initialize();
        $this->formid = $this->request->param('id/d', 0);
        //模型
        $this->modelInfo = Models::where('id', $this->formid)->where('module', 'formguide')->find();
        if (empty($this->modelInfo)) {
            $this->error('该表单不存在或者已经关闭！');
        }

        $this->tableName = $this->modelInfo['tablename'];
        $this->setting   = $this->modelInfo['setting'];

        $this->assign('id', $this->formid);
        Config::set(['view_path' => TEMPLATE_PATH . (empty(config('site.theme')) ? "default" : config('site.theme')) . DS . "formguide" . DS], 'view');
    }

    //显示表单
    public function index()
    {
        if ($this->request->isPost()) {
            $this->token();
            //验证权限
            $this->competence();
            //提交间隔
            if ($this->setting['interval']) {
                $formguide = cookie('formguide_' . $this->formid);
                if ($formguide) {
                    $this->error("操作过快，请歇息后再次提交！");
                }
            }
            $data = $this->request->post();
            //开启验证码
            if ($this->setting['isverify']) {
                // 验证码
                if (!captcha_check($data['captcha'])) {
                    $this->error('验证码错误或失效');
                }
            }
            try {
                $data                = Service::dealModelPostData($this->formid, $data['modelField']);
                $data['user_id']     = $this->auth->id;
                $data['username']    = $this->auth->username ?: '游客';
                $data['create_time'] = $this->request->time();
                $data['ip']          = $this->request->ip();
                Db::name($this->tableName)->insert($data);
            } catch (\Exception $ex) {
                $this->error($ex->getMessage());
            }
            if ($this->setting['interval']) {
                cookie('formguide_' . $this->formid, 1, $this->setting['interval']);
            }
            //发送邮件
            if ($this->setting['mails']) {
                //$ems['email'] = explode(",", $this->setting['mails']);
                $ems['email'] = $this->setting['mails'];
                $ems['title'] = "[" . $this->modelInfo['name'] . "]表单消息提醒！";
                $ems['msg']   = "刚刚有人在[" . $this->modelInfo['name'] . "]中提交了新的信息，请进入后台查看！";
                $result       = hook('ems_notice', $ems, true, true);
            }
            //跳转地址
            $forward = $this->setting['forward'] ? ((strpos($this->setting['forward'], '://') !== false) ? $this->setting['forward'] : (string) url($this->setting['forward'])) : '';
            $this->success('提交成功！', $forward);
        }
        //模板
        $show_template = $this->setting['show_template'] ? $this->setting['show_template'] : "show";
        $modelid       = $this->request->param('id/d', 0);
        $fieldList     = Service::getFieldList($modelid);

        $site   = Config::get("site");
        $upload = \app\common\model\Config::upload();
        // 配置信息
        $config = [
            'site'           => array_intersect_key($site, array_flip(['name', 'cdnurl', 'version'])),
            'upload'         => $upload,
            'modulename'     => 'addons',
            'controllername' => 'formguide',
            'actionname'     => 'index',
            'jsname'         => 'formguide/index',
            'moduleurl'      => rtrim(url("/index", [], false), '/'),
        ];
        $config = array_merge($config, Config::get("view.tpl_replace_string"), ...Event::trigger("config_init"));

        $this->view->assign('jsconfig', $config);

        $seo = seo('', $this->modelInfo['name'], $this->modelInfo['description'], '');
        $this->assign([
            'SEO'       => $seo,
            'modelInfo' => $this->modelInfo,
            'fieldList' => $fieldList,
        ]);
        return $this->fetch("/{$show_template}");
    }

    //验证提交权限
    protected function competence()
    {
        //是否允许游客提交
        if ((int) $this->setting['allowunreg'] == 0) {
            //判断是否登陆
            if (!$this->auth->isLogin()) {
                $this->error('该表单不允许游客提交，请登陆后操作！', url('index/user/login'));
            }
        }
        //是否允许同一IP多次提交
        if ((int) $this->setting['allowmultisubmit'] == 0) {
            $ip    = $this->request->ip();
            $count = Db::name($this->tableName)->where("ip", $ip)->count();
            if ($count) {
                $this->error('你已经提交过了！');
            }
        }
    }

}
