define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {

            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                delete_url: 'formguide.info/del?formid=' + Config.formid,
                view_url: 'formguide.info/public_view?formid=' + Config.formid,
            };

            var cols = [
                { type: 'checkbox', fixed: 'left' },
                { field: 'id', width: 60, title: 'ID' },
                { field: 'user_id', width: 80, title: '会员ID' },
                { field: 'username', width: 120, title: '会员名' },
            ];
            if (Config.fieldList && Config.fieldList.length) {
                Config.fieldList.forEach(item => {
                    const inputTypes = ['text', 'number', 'datetime', 'image', 'images'];
                    if (inputTypes.includes(item.type)) {
                        let obj = {
                            field: item.name,
                            title: item.title
                        }
                        if (item.type == 'datetime') {
                            obj.width = 160;
                            obj.templet = Table.formatter.datetime;
                        }
                        if (item.type == 'image' || item.type == 'images') {
                            obj.search = false;
                            obj.templet = item.type == 'image' ? Table.formatter.image : Table.formatter.images;
                        }
                        cols.push(obj);
                    }
                })
            }
            cols.push({ field: 'ip', title: 'IP' }, { field: 'create_time', width: 160, title: '创建时间', search: 'range', templet: Table.formatter.datetime }, {
                width: 100,
                title: '操作',
                templet: Table.formatter.tool,
                operat: [
                    [{
                        class: 'layui-btn layui-btn-xs btn-dialog',
                        url: Table.init.view_url,
                        auth: 'view',
                        text: "查看",
                        extend: '',
                    }], 'delete'
                ]
            });

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'delete'],
                url: 'formguide.info/index?formid=' + Config.formid,
                lineStyle: 'height: 45px;',
                cols: [
                    cols
                ],
                page: {}
            });

            Table.api.bindevent();
        }
    };
    return Controller;
});