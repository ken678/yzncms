define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "formguide.formguide/add",
                edit_url: "formguide.formguide/edit",
                delete_url: "formguide.formguide/del",
                field_url: "formguide.field/index",
                info_url: "formguide.info/index",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add'],
                url: 'formguide.formguide/index',
                search: false,
                cols: [
                    [
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'name', align: "left", title: '表单名称(信息数)' },
                        { field: 'tablename', align: "left", width: 200, title: '表名' },
                        { field: 'description', width: 200, title: '简介' },
                        { field: 'create_time', width: 180, title: '创建时间' },
                        { field: 'status', width: 80, title: '状态', templet: Table.formatter.status, selectList: { 0: '禁用', 1: '正常' }, search: false },
                        {
                            fixed: 'right',
                            width: 280,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    class: 'layui-btn layui-btn-xs layui-btn-primary btn-dialog',
                                    auth: 'info',
                                    url: Table.init.info_url+'?formid={id}',
                                    text: "信息列表",
                                    extend: 'data-area=\'["80%","80%"]\'',
                                },{
                                    class: 'layui-btn layui-btn-xs',
                                    url: '/addons/formguide/index',
                                    text: "前台浏览",
                                    extend: 'target="_blank"',
                                },{
                                    class: 'layui-btn layui-btn-xs layui-btn-normal btn-dialog',
                                    auth: 'field',
                                    url: Table.init.field_url,
                                    text: "字段管理",
                                    extend: 'data-area=\'["80%","80%"]\'',
                                }],
                                'edit', 'delete'

                            ]
                        }
                    ]
                ],
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});