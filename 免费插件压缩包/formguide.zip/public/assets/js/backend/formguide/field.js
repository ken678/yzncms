define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: 'formguide.field/add?id=' + Config.fieldid,
                edit_url: 'formguide.field/edit',
                multi_url: 'formguide.field/multi',
                delete_url: 'formguide.field/del',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add'],
                url: 'formguide.field/index?id=' + Config.fieldid,
                cols: [
                    [
                        { field: 'listorder', width: 60, title: '排序', edit: 'text' },
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'name', title: '字段名称' },
                        { field: 'title', title: '标题' },
                        { field: 'type', width: 120, title: '字段类型' },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                        { field: 'ifrequire', width: 60, title: '必填', templet: Table.formatter.label, selectList: { 0: '否', 1: '是' } },
                        { field: 'status', width: 80, title: '状态', templet: Table.formatter.label, selectList: { 0: '禁用', 1: '启用' } },
                        {
                            width: 100,
                            title: '操作',
                            templet: function(d) {
                                if (d.iffixed) {
                                    return '<a class="layui-btn layui-btn-xs layui-btn-danger layui-btn-disabled">不可操作</a>';
                                } else {
                                    return Table.formatter.tool.call(this, d, this);
                                }
                            },
                            operat: ['edit', 'delete']
                        }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
                layui.form.on('select(fieldtype)', function(data) {
                    $('#define').val($(data.elem).find("option:selected").attr("data-define"));
                    var ifoption = $(data.elem).find("option:selected").attr("data-ifoption");
                    var ifstring = $(data.elem).find("option:selected").attr("data-ifstring");
                    if (ifoption == '1') {
                        $('#options').show();
                    } else {
                        $('#options').hide();
                    }
                });
                layui.form.on('select(fasttype)', function(data) {
                    $('#define').val($(data.elem).find("option:selected").attr("data-define"));
                });
                layui.form.on('select(pattern)', function(data) {
                    $('#pattern').val($(data.elem).find("option:selected").attr("data-define"));
                });
            }
        }
    };
    return Controller;
});