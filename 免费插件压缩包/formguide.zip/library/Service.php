<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单处理类
// +----------------------------------------------------------------------
namespace addons\formguide\library;

use addons\formguide\model\ModelField;
use think\facade\Db;
use think\facade\Validate;

class Service
{

    public static function getFieldInfo($modelid, $id = null)
    {
        $modelInfo = Db::name('Model')->where('id', $modelid)->field('tablename,type')->find();
        $list      = ModelField::where('modelid', $modelid)->where('status', 1)->order('listorder asc,id asc')->column("name,title,remark,type,isadd,iscore,ifsystem,ifrequire,setting");
        if (!empty($list)) {
            if ($id) {
                $dataInfo = Db::name($modelInfo['tablename'])->where('id', $id)->find();
            }
            foreach ($list as $key => &$value) {
                if ($value['iscore']) {
                    unset($list[$key]);
                }

                if (isset($dataInfo[$value['name']])) {
                    $value['value'] = $dataInfo[$value['name']];
                }

                //$value['setting'] = unserialize($value['setting']);
                $value['options'] = $value['setting']['options'] ?? [];
                if (!empty($value['options'])) {
                    $value['options'] = parse_attr($value['options']);
                }
                if ($value['type'] == 'image' || $value['type'] == 'file') {
                    $value['value'] = !empty($value['value']) ? '<img src="' . cdnurl($value['value']) . '">' : '';
                }
                if ($value['type'] == 'datetime') {
                    $value['value'] = empty($value['value']) ? date('Y-m-d H:i:s') : date('Y-m-d H:i:s', $value['value']);
                }
            }
        }
        return $list;
    }

    //查询解析模型数据用以构造from表单
    public static function getFieldList($modelId, $id = null)
    {
        $list = ModelField::where('modelid', $modelId)->where('status', 1)->order('listorder DESC,id DESC')->select();
        if (!empty($list)) {
            //编辑信息时查询出已有信息
            if ($id) {
                $modelInfo = Db::name('Model')->where('id', $modelId)->field('tablename,type')->find();
                $dataInfo  = Db::name($modelInfo['tablename'])->where('id', $id)->find();
            }
            foreach ($list as $key => &$value) {
                //内部字段不显示
                if ($value['iscore']) {
                    unset($list[$key]);
                }
                //核心字段做标记
                $value['fieldArr'] = 'modelField';
                if (isset($dataInfo[$value['name']])) {
                    $value['value'] = $dataInfo[$value['name']];
                }
                //扩展配置
                //$value['setting'] = unserialize($value['setting']);
                $value['options'] = $value['setting']['options'] ?? '';
                //在新增时候添加默认值
                if (!$id) {
                    $value['value'] = $value['setting']['value'] ?? '';
                }
                if ($value['type'] == 'custom') {
                    if ($value['options'] != '') {
                        $tpar             = explode(".", $value['options'], 2);
                        $value['options'] = \think\Response::create('admin@custom/' . $tpar[0], 'view')->assign('vo', $value)->getContent();
                        unset($tpar);
                    }
                } elseif ($value['options'] != '') {
                    $value['options'] = parse_attr($value['options']);
                }
                if ($value['type'] == 'checkbox') {
                    $value['value'] = empty($value['value']) ? [] : explode(',', $value['value']);
                }
                if ($value['type'] == 'datetime') {
                    $value['value'] = empty($value['value']) ? date('Y-m-d H:i:s') : date('Y-m-d H:i:s', $value['value']);
                }
                if ($value['type'] == 'date') {
                    $value['value'] = empty($value['value']) ? '' : date('Y-m-d', $value['value']);
                }
                if ($value['type'] == 'Ueditor' || $value['type'] == 'markdown') {
                    $value['value'] = isset($value['value']) ? htmlspecialchars_decode($value['value']) : '';
                }
            }
        }
        return $list;
    }

    //处理post提交的模型数据
    public static function dealModelPostData($modelid, $data)
    {
        //字段类型
        $query = ModelField::where('modelid', $modelid)->where('status', 1);

        $filedTypeList = $query->order('listorder DESC, id DESC')->column('title,type,ifsystem,ifrequire,pattern,errortips', 'name');

        foreach ($filedTypeList as $name => $vo) {
            if (!isset($data[$name])) {
                switch ($vo['type']) {
                    // 开关
                    case 'switch':
                        $data[$name] = 0;
                        break;
                    case 'checkbox':
                        $data[$name] = '';
                        break;
                }
            } else {
                if (is_array($data[$name])) {
                    $data[$name] = implode(',', $data[$name]);
                }
                switch ($vo['type']) {
                    // 开关
                    case 'switch':
                        $data[$name] = 1;
                        break;
                    // 日期+时间
                    case 'datetime':
                        //if ($vo['ifeditable']) {
                        $data[$name] = strtotime($data[$name]);
                        //}
                        break;
                    // 日期
                    case 'date':
                        $data[$name] = strtotime($data[$name]);
                        break;
                    // 编辑器
                    case 'markdown':
                    case 'Ueditor':
                        $data[$name] = htmlspecialchars(stripslashes($data[$name]));
                        break;
                }
            }
            //数据必填验证
            if ($vo['ifrequire'] && (!isset($data[$name]) || $data[$name] == '')) {
                throw new \Exception("'" . $vo['title'] . "'必须填写~");
            }
            //正则校验
            if (isset($data[$name]) && $data[$name] && $vo['pattern'] && !Validate::regex($data[$name], $vo['pattern'])) {
                throw new \Exception("'" . $vo['title'] . "'" . (!empty($vo['errortips']) ? $vo['errortips'] : '正则校验失败') . "");
            }
            //数据格式验证
            if (!empty($data[$name]) && in_array($vo['type'], ['number']) && !Validate::isNumber($data[$name])) {
                throw new \Exception("'" . $vo['title'] . "'格式错误~");
                //安全过滤
            } else {

            }
        }
        return $data;
    }
}
