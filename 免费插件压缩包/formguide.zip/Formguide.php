<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单插件
// +----------------------------------------------------------------------
namespace addons\formguide;

use app\common\library\Menu;
use think\Addons;
use think\facade\Config;
use think\facade\Db;
use think\facade\Env;

class Formguide extends Addons
{
    //后台菜单
    public $menu = [
        [
            "name"    => "formguide.formguide",
            "title"   => "表单管理",
            "icon"    => "iconfont icon-file-list-3-line",
            "sublist" => [
                ["name" => "formguide.formguide/index", "title" => "查看"],
                ["name" => "formguide.formguide/add", "title" => "新增"],
                ["name" => "formguide.formguide/edit", "title" => "编辑"],
                ["name" => "formguide.formguide/del", "title" => "删除"],
            ],
        ],
        [
            "name"    => "formguide.field",
            "title"   => "字段管理",
            "ismenu"  => 0,
            "sublist" => [
                ["name" => "formguide.field/index", "title" => "查看"],
                ["name" => "formguide.field/add", "title" => "新增"],
                ["name" => "formguide.field/edit", "title" => "编辑"],
                ["name" => "formguide.field/del", "title" => "删除"],
                ["name" => "formguide.info/index", "title" => "信息列表"],
                ["name" => "formguide.info/public_view", "title" => "信息查看"],
                ["name" => "formguide.info/del", "title" => "信息删除"],
            ],
        ],
    ];

    //安装
    public function install()
    {
        Menu::create($this->menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        $droptables = request()->param("droptables");
        $auth       = \app\admin\library\Auth::instance();
        //只有开启调试且为超级管理员才允许删除相关数据库
        if ($droptables && Env::get('APP_DEBUG') && $auth->isAdministrator()) {
            //删除模型中建的表
            $table_list = Db::name('model')->where('module', 'formguide')->field('tablename,id')->select();
            if ($table_list) {
                foreach ($table_list as $val) {
                    $tablename = Config::get('database.connections.mysql.prefix') . $val['tablename'];
                    Db::execute("DROP TABLE IF EXISTS `{$tablename}`;");
                    Db::name('model_field')->where('modelid', $val['id'])->delete();
                }
            }
        }
        //删除模型中的表
        Db::name('model')->where('module', 'formguide')->delete();
        Menu::delete("formguide.formguide");
        Menu::delete("formguide.field");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("formguide");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("formguide");
        return true;
    }

}
