<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 模型模型
// +----------------------------------------------------------------------
namespace app\admin\model\formguide;

use think\Exception;
use think\facade\Cache;
use think\facade\Config;
use think\facade\Db;
use think\Model;

class Models extends Model
{
    protected $name               = 'model';
    protected $autoWriteTimestamp = true;

    public static function onBeforeUpdate($row)
    {
        unset($row['type'], $row['tablename']);
    }

    public static function onAfterDelete($row)
    {
        cache::set("Model", null);
        cache::set('ModelField', null);
        //删除所有和这个模型相关的字段
        Db::name("ModelField")->where("modelid", $row['id'])->delete();
        //删除主表
        $prefix = Config::get("database.connections.mysql.prefix");
        Db::execute("DROP TABLE IF EXISTS `{$prefix}{$row['tablename']}`");
    }

    public static function onBeforeInsert($row)
    {
        $row['tablename'] = 'formguide_' . $row['tablename'];
        $row['module']    = 'formguide';

        $info = null;
        try {
            $info = Db::name($row['tablename'])->getPk();
        } catch (\Exception $e) {
        }
        if ($info) {
            throw new Exception("数据表已经存在");
        }
    }

    public static function onAfterUpdate($row)
    {
        //更新缓存
        cache::set("Model", null);
        cache::set('ModelField', null);
    }

    public static function onAfterInsert($row)
    {
        cache::set("Model", null);
        cache::set('ModelField', null);

        $prefix = Config::get("database.connections.mysql.prefix");
        //创建模型表
        $sql = "CREATE TABLE `{$prefix}{$row['tablename']}` (
                `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
                `user_id` int(10) DEFAULT NULL COMMENT '会员ID',
                `username` varchar(20) NOT NULL,
                `create_time` int(10) unsigned DEFAULT NULL COMMENT '添加时间',
                `ip` char(15) NOT NULL DEFAULT '',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;";
        Db::execute($sql);
    }

    public function getSettingAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['setting'], true);
    }

    public function setSettingAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }
}
