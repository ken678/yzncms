<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 字段模型
// +----------------------------------------------------------------------
namespace app\admin\model\formguide;

use think\Exception;
use think\facade\Db;
use think\Model;

class ModelField extends Model
{
    protected $autoWriteTimestamp = true;

    public function getSettingAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['setting'], true);
    }

    public function setSettingAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }

    public static function onBeforeInsert($row)
    {
        $modelid = $row['modelid'];
        $model   = Models::find($modelid);
        if (!$model) {
            throw new Exception("未找到指定模型");
        }

        $tablename = self::getTable($model['tablename']);

        //判断字段名唯一性
        if (self::where('name', $row['name'])->where('modelid', $modelid)->find()) {
            throw new Exception("字段'" . $row['name'] . "`已经存在");
        }
        $row['isadd']     = isset($row['isadd']) ? intval($row['isadd']) : 0;
        $row['ifrequire'] = isset($row['ifrequire']) ? intval($row['ifrequire']) : 0;
        if ($row['ifrequire'] && !$row['isadd']) {
            throw new Exception('必填字段不可以隐藏！');
        }
        if ($row['setting']['value'] === '') {
            $default = '';
        } elseif (strstr(strtolower($row['setting']['define']), 'text') || strstr(strtolower($row['setting']['define']), 'blob')) {
            $default = '';
        } else {
            $default = " DEFAULT '{$row['setting']['value']}'";
        }

        //先将字段存在设置的主表或附表里面 再将数据存入ModelField
        $sql = <<<EOF
            ALTER TABLE `{$tablename}`
            ADD COLUMN `{$row['name']}` {$row['setting']['define']} {$default} COMMENT '{$row['title']}';
EOF;
        try {
            Db::execute($sql);
        } catch (\Exception $e) {
            throw new Exception($e->getMessage());
        }

        $fieldInfo      = Db::name('field_type')->where('name', $row['type'])->field('ifoption,ifstring')->find();
        $row['status']  = isset($row['status']) ? intval($row['status']) : 0;
        $row['iffixed'] = 0;
        //清理缓存
        cache('ModelField', null);
    }

    public static function onBeforeUpdate($row)
    {
        $modelid = $row['modelid'];
        $model   = Models::find($modelid);
        if (!$model) {
            throw new Exception("未找到指定模型");
        }

        $tablename = self::getTable($model['tablename']);

        //判断字段名唯一性
        if (self::where('name', $row['name'])->where('modelid', $modelid)->where('id', '<>', $row->id)->find()) {
            throw new Exception("字段'" . $row['name'] . "`已经存在");
        }

        $row['isadd']     = isset($row['isadd']) ? intval($row['isadd']) : 0;
        $row['ifrequire'] = isset($row['ifrequire']) ? intval($row['ifrequire']) : 0;
        if ($row['ifrequire'] && !$row['isadd']) {
            throw new \Exception('必填字段不可以隐藏！');
        }

        if ($row['setting']['value'] === '') {
            $default = '';
        } elseif (strstr(strtolower($row['setting']['define']), 'text') || strstr(strtolower($row['setting']['define']), 'blob')) {
            $default = '';
        } else {
            $default = " DEFAULT '{$row['setting']['value']}'";
        }

        $sql = <<<EOF
            ALTER TABLE `{$tablename}`
            CHANGE COLUMN `{$row->getOrigin('name')}` `{$row['name']}` {$row['setting']['define']} {$default} COMMENT '{$row['title']}';
EOF;
        try {
            Db::execute($sql);
        } catch (\Exception $e) {
            throw new Exception($e->getMessage());
        }
        $fieldInfo     = Db::name('field_type')->where('name', $row['type'])->field('ifoption,ifstring')->find();
        $row['status'] = isset($row['status']) ? intval($row['status']) : 0;
        //清理缓存
        cache('ModelField', null);
    }

    public static function onBeforeDelete($row)
    {
        $modelid = $row['modelid'];
        $model   = Models::find($modelid);
        if (!$model) {
            throw new Exception("未找到指定模型");
        }

        $tablename = self::getTable($model['tablename']);

        //判断是否允许删除
        $sql = <<<EOF
            ALTER TABLE `{$tablename}`
            DROP COLUMN `{$row['name']}`;
EOF;
        Db::execute($sql);
    }
}
