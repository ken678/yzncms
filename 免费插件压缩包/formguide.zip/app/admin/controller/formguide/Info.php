<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单信息管理
// +----------------------------------------------------------------------
namespace app\admin\controller\formguide;

use app\admin\model\formguide\Models;
use app\common\controller\Backend;
use think\facade\Db;

class Info extends Backend
{
    /**
     * @var FormguideModel
     */
    protected $modelClass = null;

    protected function initialize()
    {
        parent::initialize();
        //$this->modelClass = new ModelField;
    }

    //信息列表
    public function index()
    {
        $formid = $this->request->param('formid/d', 0);
        if ($this->request->isAjax()) {
            $model     = Models::find($formid);
            $tableName = $model['tablename'];

            $this->modelClass           = Db::name($tableName);
            list($page, $limit, $where) = $this->buildTableParames();

            $total = Db::name($tableName)
                ->where($where)
                ->count();
            $list = Db::name($tableName)
                ->where($where)
                ->page($page, $limit)
                ->order(['id' => 'desc'])
                ->select();
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        } else {
            $fieldList = Db::name('ModelField')->where('modelid', $formid)->where('status', 1)->order('listorder desc')->select();
            $this->assignconfig('fieldList', $fieldList);
            $this->assignconfig('formid', $formid);
            return $this->fetch();
        }

    }

    //删除信息
    public function del()
    {
        $formid = $this->request->param('formid/d', 0);
        $ids    = $this->request->param('id/a', null);
        if (empty($ids) || !$formid) {
            $this->error('参数错误！');
        }
        if (!is_array($ids)) {
            $ids = [0 => $ids];
        }
        $model     = Models::find($formid);
        $tableName = $model['tablename'];
        try {
            foreach ($ids as $id) {
                Db::name($tableName)->where('id', $id)->delete();
            }
        } catch (\Exception $ex) {
            $this->error($ex->getMessage());
        }
        $this->success('删除成功！');
    }

    //信息查看
    public function public_view()
    {
        $id        = $this->request->param('id', 0);
        $formid    = $this->request->param('formid', 0);
        $fieldList = \addons\formguide\library\Service::getFieldInfo($formid, $id);
        $this->assign([
            'fieldList' => $fieldList,
        ]);
        return $this->fetch();
    }
}
