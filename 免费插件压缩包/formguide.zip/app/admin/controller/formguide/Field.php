<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单字段后台管理
// +----------------------------------------------------------------------
namespace app\admin\controller\formguide;

use app\admin\model\formguide\ModelField as ModelField;
use app\common\controller\Backend;
use think\facade\Db;

class Field extends Backend
{
    public $fields, $banfie;
    protected $modelClass    = null;
    protected $modelValidate = true;

    //初始化
    protected function initialize()
    {
        parent::initialize();
        //允许使用的字段列表
        $this->banfie     = ["text", "checkbox", "textarea", "radio", "select", "image", "number", "Ueditor", "color", "file", "datetime"];
        $this->modelClass = new ModelField;
    }

    //首页
    public function index()
    {
        $fieldid = $this->request->param('id/d', 0);
        if ($this->request->isAjax()) {
            list($page, $limit, $where) = $this->buildTableParames();
            $count                      = $this->modelClass->where($where)->where(['modelid' => $fieldid])->count();
            $data                       = $this->modelClass->where($where)->where(['modelid' => $fieldid])->page($page, $limit)->order(['listorder' => 'DESC', 'id' => 'DESC'])->select();
            return json(["code" => 0, 'count' => $count, "data" => $data]);
        } else {
            $this->assignconfig('fieldid', $fieldid);
            return $this->fetch();
        }
    }

    //添加
    public function add()
    {
        $fieldid   = $this->request->param('id/d', 0);
        $fieldType = Db::name('field_type')->where('name', 'in', $this->banfie)->order('listorder')->column('name,title,default_define,ifoption,ifstring');
        $modelInfo = Db::name('model')->where('id', $fieldid)->find();
        $this->assign(
            [
                'modelType' => $modelInfo['type'],
                "modelid"   => $fieldid,
                'fieldType' => $fieldType,
            ]
        );
        return parent::add();
    }

    //编辑
    public function edit()
    {
        $fieldid = $this->request->param('id/d', 0);
        //字段信息
        $fieldData = ModelField::find($fieldid);
        if (empty($fieldData)) {
            $this->error('该字段信息不存在！');
        }
        //模型信息
        $modedata = Db::name('model')->where('id', $fieldData->getAttr('modelid'))->find();
        if (empty($modedata)) {
            $this->error('该模型不存在！');
        }
        $fieldType = Db::name('field_type')->where('name', 'in', $this->banfie)->order('listorder')->column('name,title,default_define,ifoption,ifstring', 'name');
        $this->assign([
            'data'      => $fieldData,
            'fieldid'   => $fieldid,
            'fieldType' => $fieldType,
        ]);
        return parent::edit();
    }
}
