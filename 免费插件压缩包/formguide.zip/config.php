<?php
return [
    [
        'name'  => 'rewrite',
        'title' => '伪静态',
        'type'  => 'array',
        'value' => [
            'index/index' => '/formguide/[:id]$',
        ],
        'tip'   => '',
    ],
];
