<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 腾讯云COS插件
// +----------------------------------------------------------------------
namespace addons\cos;

use app\common\model\Attachment;
use Composer\Autoload\ClassLoader;
use Qcloud\Cos\Client as OssClient;
use think\Addons;
use think\facade\Db;

class Cos extends Addons
{
    /**
     * 上传附件
     */
    public function uploadAfter($params = [])
    {
        $file      = $params['file'];
        $config    = $this->getAddonConfig();
        $error_msg = '';
        if ($config['secretId'] == '') {
            $error_msg = '未填写腾讯云COS【SecretId】';
        } elseif ($config['secretKey'] == '') {
            $error_msg = '未填写腾讯云COS【SecretKey】';
        } elseif ($config['bucket'] == '') {
            $error_msg = '未填写腾讯云COS【Bucket】';
        } elseif ($config['region'] == '') {
            $error_msg = '未填写腾讯云COS【Region】';
        } elseif ($config['domain'] == '') {
            $error_msg = '未填写腾讯云COS【Domain】';
        }
        if ($error_msg != '') {
            return json([
                'code'    => 0,
                'msg'     => $error_msg,
                'state'   => $error_msg, //兼容百度
                'message' => $error_msg, //兼容editormd
            ]);
        }

        $accessKeyId     = $config['secretId'];
        $accessKeySecret = $config['secretKey'];
        $region          = $config['region'];
        // 存储空间名称
        $bucket = $config['bucket'];

        // 文件信息
        $info['type']     = $file->getOriginalMime();
        $info['size']     = $file->getSize();
        $info['name']     = $file->getOriginalName();
        $info['tmp_name'] = $file->getPathname();

        $suffix = strtolower(pathinfo($info['name'], PATHINFO_EXTENSION));
        $suffix = $suffix && preg_match("/^[a-zA-Z0-9]+$/", $suffix) ? $suffix : 'file';

        $stylename = '';
        //对图片处理的规则名称stylename
        if (in_array($suffix, ['gif', 'jpg', 'jpeg', 'bmp', 'png', 'webp']) && $config['stylename'] && $config['separator']) {
            $stylename = trim($config['separator']) . trim($config['stylename']);
        }

        // 要上传文件的本地路径
        $filePath = $info['tmp_name'];

        $file_name = explode('.', $info['name']);
        $ext       = end($file_name);
        $object    = $params['dir'] . '/' . date('Ymd') . '/' . $file->hash('md5') . '.' . $ext;

        try {
            $ossClient = new OssClient([
                'region' => $region, 'credentials' => [
                    'secretId'  => $accessKeyId,
                    'secretKey' => $accessKeySecret,
                ],
            ]);
            $ossClient->putObject([
                'Bucket' => $bucket,
                'Key'    => $object,
                'Body'   => fopen($filePath, 'rb'),
            ]);
        } catch (\Exception $e) {
            return json([
                'code'    => 0,
                'msg'     => $e->getMessage(),
                'state'   => $e->getMessage(), //兼容百度
                'message' => $e->getMessage(), //兼容editormd
            ]);
        }

        // 获取附件信息
        $data = [
            'admin_id' => (int) session('admin.id'),
            'user_id'  => (int) cookie('uid'),
            'name'     => $info['name'],
            'mime'     => $info['type'],
            'path'     => $config['domain'] . $object . $stylename,
            'ext'      => $suffix,
            'size'     => $info['size'],
            'md5'      => $file->hash('md5'),
            'sha1'     => $file->hash('sha1'),
            'driver'   => 'alioss',
        ];
        if ($file_add = Attachment::create($data)) {
            // 返回结果
            return json([
                'code'    => 1,
                'msg'     => $data['name'] . '上传成功',
                'id'      => $file_add['id'],
                'path'    => $data['path'],
                "state"   => "SUCCESS", // 上传状态，上传成功时必须返回"SUCCESS" 兼容百度
                "url"     => $data['path'], // 返回的地址 兼容百度
                "title"   => $data['name'], // 附件名 兼容百度
                "success" => 1, //兼容editormd
                "message" => $data['name'], // 附件名 兼容editormd
            ]);
        } else {
            return json([
                'code'    => 0,
                'msg'     => '上传成功,写入数据库失败',
                'state'   => '上传成功,写入数据库失败', //兼容百度
                'message' => '上传成功,写入数据库失败', //兼容editormd
            ]);
        }
    }

    /**
     * 删除附件
     */
    public function uploadDelete($params = [])
    {
        $config          = $this->getAddonConfig();
        $accessKeyId     = $config['secretId'];
        $accessKeySecret = $config['secretKey'];
        $region          = $config['region'];
        $bucket          = $config['bucket'];

        $stylename = '';
        //图片有stylename需要去除 否则无法删除
        if (in_array($params['ext'], ['gif', 'jpg', 'jpeg', 'bmp', 'png', 'webp']) && $config['stylename'] && $config['separator']) {
            $stylename = trim($config['separator']) . trim($config['stylename']);
        }
        $object = rtrim(str_replace($config['domain'], '', $params['path']), $stylename);

        try {
            $ossClient = new OssClient([
                'region' => $region, 'credentials' => [
                    'secretId'  => $accessKeyId,
                    'secretKey' => $accessKeySecret,
                ]]);
            $ossClient->deleteObject(
                [
                    'Bucket' => $bucket,
                    'Key'    => $object,
                ]);
        } catch (\Exception $e) {

        }
        return true;

    }

    //安装
    public function install()
    {
        $upload_driver = Db::name('config')->where(['name' => 'upload_driver', 'group' => 'upload'])->find();
        if (!$upload_driver) {
            $this->error = '未找到【上传驱动】配置';
            return false;
        }
        $options = parse_attr($upload_driver['options']);
        if (isset($options['cos'])) {
            $this->error = '已存在名为【cos】的上传驱动';
            return false;
        }
        $upload_driver['options'] .= PHP_EOL . 'cos:腾讯云';

        $result = Db::name('config')
            ->where(['name' => 'upload_driver', 'group' => 'upload'])
            ->update(['options' => $upload_driver['options']]);

        if (false === $result) {
            $this->error = '上传驱动设置失败';
            return false;
        }
        return true;
    }

    //卸载
    public function uninstall()
    {
        $upload_driver = Db::name('config')->where(['name' => 'upload_driver', 'group' => 'upload'])->find();
        if ($upload_driver) {
            $options = parse_attr($upload_driver['options']);
            if (isset($options['cos'])) {
                unset($options['cos']);
            }
            $options = $this->implode_attr($options);
            $result  = Db::name('config')
                ->where(['name' => 'upload_driver', 'group' => 'upload'])
                ->update(['options' => $options, 'value' => 'local']);

            if (false === $result) {
                $this->error = '上传驱动设置失败';
                return false;
            }
        }
        return true;
    }

    protected function implode_attr($array = [])
    {
        $result = [];
        foreach ($array as $key => $value) {
            $result[] = $key . ':' . $value;
        }
        return empty($result) ? '' : implode(PHP_EOL, $result);
    }

    /**
     * 添加命名空间
     */
    public function appInit()
    {
        require_once __DIR__ . '/SDK/cos/src/Common.php';
        $loader = new ClassLoader();
        if (!class_exists('\Qcloud\Cos')) {
            $loader->addPsr4('Qcloud\\Cos\\', ADDON_PATH . 'cos' . DS . 'SDK' . DS . 'cos' . DS . 'src', true);
        }
        if (!class_exists('\GuzzleHttp\Command')) {
            $loader->addPsr4('GuzzleHttp\\Command\\', ADDON_PATH . 'cos' . DS . 'SDK' . DS . 'command' . DS . 'src', true);
        }
        if (!class_exists('\GuzzleHttp\Command\Guzzle')) {
            $loader->addPsr4('GuzzleHttp\\Command\Guzzle\\', ADDON_PATH . 'cos' . DS . 'SDK' . DS . 'services' . DS . 'src', true);
        }
        if (!class_exists('\GuzzleHttp\UriTemplate')) {
            $loader->addPsr4('GuzzleHttp\\UriTemplate\\', ADDON_PATH . 'cos' . DS . 'SDK' . DS . 'template' . DS . 'src', true);
        }
        $loader->register();
    }

}
