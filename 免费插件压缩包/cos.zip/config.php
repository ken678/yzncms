<?php
return [
    [
        'name'  => 'secretId',
        'title' => '腾讯云secretId',
        'type'  => 'text',
        'value' => '',
        'tip'   => '腾讯云secretId',
    ],
    [
        'name'  => 'secretKey',
        'title' => '腾讯云secretKey',
        'type'  => 'text',
        'value' => '',
        'tip'   => '腾讯云secretKey',
    ],
    [
        'name'  => 'bucket',
        'title' => '存储桶名称',
        'type'  => 'text',
        'value' => '',
        'tip'   => '存储桶名称',
    ],
    [
        'name'  => 'region',
        'title' => '所属地域',
        'type'  => 'text',
        'value' => '',
        'tip'   => '所属地域',
    ],
    [
        'name'  => 'domain',
        'title' => '空间绑定的域名',
        'type'  => 'text',
        'value' => '',
        'tip'   => '对应绑定的域名，已http://开头，/结尾',
    ],
    [
        'name'  => 'stylename',
        'title' => '图片处理规则名称',
        'type'  => 'text',
        'value' => '',
        'tip'   => '设置后，同时在腾讯云cos后台【图片处理】开启原图保护',
    ],
    [
        'name'    => 'separator',
        'title'   => '图片处理自定义分隔符',
        'type'    => 'select',
        'options' => [
            '-' => '-',
            '_' => '_',
            '/' => '/',
            '!' => '!',
        ],
        'value'   => '',
        'tip'     => '需要在腾讯云cos后台【图片处理】样式分隔符打勾',
    ],
];
