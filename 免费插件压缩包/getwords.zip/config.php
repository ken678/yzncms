<?php

return [
    [
        'name'    => 'type',
        'title'   => '分词平台',
        'type'    => 'radio',
        'options' => [
            'local' => '本地',
            'baidu' => '百度',
            'xfyun' => '讯飞',
        ],
        'value'   => 'baidu',
        'tip'     => '',
    ],
    [
        'name'  => 'appid',
        'title' => '你的 App ID',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ],
    [
        'name'  => 'apikey',
        'title' => '你的 Api Key',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ],
    [
        'name'  => 'secretkey',
        'title' => '你的 Secret Key',
        'type'  => 'text',
        'value' => '',
        'tip'   => '讯飞不用填写此项',
    ],
    [
        'name'  => 'max',
        'title' => '最多获取数量',
        'type'  => 'text',
        'value' => '5',
        'tip'   => '',
    ],
];
