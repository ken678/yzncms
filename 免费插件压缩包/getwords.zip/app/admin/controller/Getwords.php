<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 中文分词管理
// +----------------------------------------------------------------------
namespace app\admin\controller;

use addons\getwords\library\aip\AipNlp;
use addons\getwords\library\VicWord;
use app\common\controller\Backend;

class Getwords extends Backend
{
    //获取内容关键字
    public function index()
    {
        $content = $this->request->param('content/s', '');
        $content = mb_substr($content, 0, 20000, 'UTF-8');
        $config  = get_addon_config('getwords');
        $arr     = [];
        $max     = $config['max'];
        switch ($config['type']) {
            case 'local':
                ini_set('memory_limit', '-1');
                $handle = new VicWord();
                $result = $handle->getAutoWord($content);
                $max    = count($result) > $max ? $max : count($result);
                foreach ($result as $item) {
                    if ($item[2] !== '0' && mb_strlen($item[0], 'utf-8') > 1 && !is_numeric($item[0])) {
                        $arr[] = $item[0];
                    }
                }
                $arr = array_slice(array_unique($arr), 0, $max);
                $arr = implode(',', $arr);
                break;
            case 'baidu':
                $client = new AipNlp($config['appid'], $config['apikey'], $config['secretkey']);
                $result = $client->lexer($content);
                if (isset($result['items'])) {
                    $max = count($result['items']) > $max ? $max : count($result['items']);
                    foreach ($result['items'] as $k => $v) {
                        if (in_array($v['pos'], ['n', 'nr', 'nt', 'nw']) && $v['byte_length'] > 2) {
                            $arr[] = $v['item'];
                        }
                    }
                    $arr = array_slice(array_unique($arr), 0, $max);
                    $arr = implode(',', $arr);
                }
                break;
            case 'xfyun':
                $XAppid    = $config['appid'];
                $Apikey    = $config['apikey'];
                $XCurTime  = time();
                $XParam    = "";
                $XCheckSum = "";
                $Param     = [
                    "type" => "dependent",
                ];
                $Post = [
                    'text' => $content,
                ];
                $XParam    = base64_encode(json_encode($Param));
                $XCheckSum = md5($Apikey . $XCurTime . $XParam);

                $options = [
                    CURLOPT_HTTPHEADER => [
                        'X-CurTime:' . $XCurTime,
                        'X-Param:' . $XParam,
                        'X-Appid:' . $XAppid,
                        'X-CheckSum:' . $XCheckSum,
                        'Content-Type:application/x-www-form-urlencoded; charset=utf-8',
                    ],
                ];
                $result = \util\Http::sendRequest('http://ltpapi.xfyun.cn/v1/ke', http_build_query($Post), 'POST', $options);
                if ($result['ret']) {
                    $res = (array) json_decode($result['msg'], true);
                    if ($res['code'] == 0) {
                        $max = count($res['data']['ke']) > $max ? $max : count($res['data']['ke']);
                        foreach ($res['data']['ke'] as $t) {
                            $arr[] = $t['word'];
                        }
                        $arr = array_slice(array_unique($arr), 0, $max);
                        $arr = implode(',', $arr);
                    }
                }
                break;
        }
        $this->success('', '', empty($arr) ? '' : $arr);
    }
}
