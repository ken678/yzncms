<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 消息插件
// +----------------------------------------------------------------------
namespace addons\message;

use app\common\library\Menu;
use think\Addons;

class Message extends Addons
{
    //后台菜单
    protected $menu = [
        [
            "name"    => "message",
            "title"   => "短消息",
            "icon"    => "iconfont icon-mail-line",
            "sublist" => [
                [
                    "name"    => "message.message",
                    "title"   => "消息列表",
                    "icon"    => "iconfont icon-mail-unread-line",
                    "sublist" => [
                        ["name" => "message.message/index", "title" => "查看"],
                        ["name" => "message.message/add", "title" => "新增"],
                        ["name" => "message.message/del", "title" => "删除"],
                    ],
                ],
                [
                    "name"    => "message.group",
                    "title"   => "群发消息",
                    "icon"    => "iconfont icon-mail-send-line",
                    "sublist" => [
                        ["name" => "message.group/index", "title" => "查看"],
                        ["name" => "message.group/add", "title" => "新增"],
                        ["name" => "message.group/del", "title" => "删除"],
                    ],
                ],
            ],
        ],
    ];

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        Menu::create($this->menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("message");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("message");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("message");
        return true;
    }

    //或者run方法
    public function userSidenavAfter($content)
    {
        return $this->fetch('userSidenavAfter');
    }
}
