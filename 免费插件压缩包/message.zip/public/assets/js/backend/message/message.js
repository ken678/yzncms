define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Yzn.config.openArea = ['700px', '500px'];
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "message.message/add",
                delete_url: "message.message/del",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'delete',
                    [{
                        text: "发送短消息",
                        url: Table.init.add_url,
                        icon:'iconfont icon-add-fill',
                        auth: 'add',
                        class: 'layui-btn layui-btn-sm btn-dialog',
                        extend: '',
                    }],
                ],
                url: 'message.message/index',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'id', width: 70, title: 'ID' },
                        { field: 'subject', align: "left", width: 200, title: '标题' },
                        { field: 'content', align: "left", title: '内容' },
                        { field: 'send_from', width: 120, title: '发件人' },
                        { field: 'send_to', width: 120, title: '收件人' },
                        { field: 'status', width: 80, align: 'center', title: '状态', templet: Table.formatter.label, selectList: { 0: '未读', 1: '已读' } },
                        { field: 'create_time', width: 200, align: "center", title: '发送时间', search: 'range' },
                        { width: 80, title: '操作', templet: Table.formatter.tool, operat: ['delete'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});