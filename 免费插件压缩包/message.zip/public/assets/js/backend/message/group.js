define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Yzn.config.openArea = ['700px', '500px'];
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "message.group/add",
                delete_url: "message.group/del",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'delete',
                    [{
                        text: "群发短消息",
                        icon:'iconfont icon-add-fill',
                        url: Table.init.add_url,
                        auth: 'add',
                        class: 'layui-btn layui-btn-sm btn-dialog',
                        extend: '',
                    }],
                ],
                url: 'message.group/index',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'id', width: 70, title: 'ID' },
                        { field: 'subject', align: "left", width: 200, title: '标题' },
                        { field: 'content', align: "left", title: '内容' },
                        { field: 'group.name', width: 120, title: '会员组别' },
                        { field: 'count', width: 100, title: '已读数量' },
                        { field: 'create_time', width: 200, align: "center", title: '发送时间', search: 'range' },
                        { width: 80, title: '操作', templet: Table.formatter.tool, operat: ['delete'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});