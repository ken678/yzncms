define(['jquery', 'table', 'form'], function($, Table, Form) {
    $(document).on("click", ".btn-look", function() {
        var that = this;
        Layer.open({
            type: 2,
            title: $(this).data('title'),
            area: ["500px", "400px"],
            content: $(this).data('href'),
            btn: false
        });

    });
    var Controller = {
        send: function() {
            Form.api.bindevent($("form.layui-form"), function(data, ret) {
                setTimeout(function() {
                    window.location.href = ret.url;
                }, 1500);
            }, function(res) {
                $("#verify").click();
            });

            //刷新验证码
            $("#verify").click(function() {
                var verifyimg = $("#verify").attr("src");
                $("#verify").attr("src", verifyimg.replace(/\?.*$/, '') + '?' + Math.random());
            });
        },
        read: function() {},
        read_only: function() {},
        read_group: function() {},
        group: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'message/group',
                search: false,
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'subject', title: '标题' },
                        { field: 'isread', width: 80, align: 'center', title: '状态', templet: Table.formatter.label, selectList: { 0: '未读', 1: '已读' }, search: false },
                        { field: 'create_time', width: 180, title: '发送时间' },
                        { fixed: 'right', width: 70, title: '操作', templet: '#barTool' }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        inbox: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'message/inbox',
                search: false,
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'subject', title: '标题' },
                        { field: 'send_from', width: 120, title: '发件人' },
                        { field: 'status', width: 80, align: 'center', title: '状态', templet: Table.formatter.label, selectList: { 0: '未读', 1: '已读' }, search: false },
                        { field: 'create_time', width: 180, title: '发送时间' },
                        { fixed: 'right', width: 70, title: '操作', templet: '#barTool' }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        outbox: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: 'message/send',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'message/outbox',
                search: false,
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'subject', title: '标题' },
                        { field: 'send_to', width: 120, title: '收件人' },
                        { field: 'status', width: 100, align: 'center', title: '收件人状态', templet: Table.formatter.label, selectList: { 0: '未读', 1: '已读' }, search: false },
                        { field: 'create_time', width: 200, title: '发送时间' },
                        { fixed: 'right', width: 70, title: '操作', templet: '#barTool' }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();

        },
    };
    return Controller;
});