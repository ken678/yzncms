<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 短信息后台管理
// +----------------------------------------------------------------------
namespace app\index\controller;

use app\common\controller\Frontend;
use app\common\model\User as UserModel;
use app\common\model\UserGroup;
use app\index\model\Message as MessageModel;
use app\index\model\MessageData as MessageDataModel;
use app\index\model\MessageGroup as MessageGroupModel;
use think\exception\ValidateException;

class Message extends Frontend
{
    protected $groupCache = [];
    //初始化
    public function initialize()
    {
        parent::initialize();
        $this->groupCache = UserGroup::where('status', 1)
            ->column('name,allowsendmessage,allowmessage', 'id'); //会员组模型
    }

    //发送消息
    public function send()
    {
        if ($this->request->isPost()) {
            //判断当前会员，是否可发，短消息．
            $this->messagecheck();
            $data = $this->request->post('info/a');
            //验证码
            if (!captcha_check($this->request->post('verify/s', ''))) {
                $this->error('验证码输入错误！');
                return false;
            }
            $data['send_from'] = $this->auth->username;

            try {
                $this->validate($data, 'message');
            } catch (ValidateException $e) {
                $this->error($e->getMessage());
            }

            if ($data['send_to'] == $this->auth->username) {
                return $this->error('不能发给自己');
            }
            if (!UserModel::getByUsername($data['send_to'])) {
                return $this->error('用户不存在');
            }
            if (MessageModel::create($data)) {
                $this->success('发送成功！', url('outbox'));
            } else {
                $this->error('发送失败！');
            }
        } else {
            $this->assign('title', '发送消息');
            return $this->fetch();
        }
    }

    //查看短消息
    public function read()
    {
        $messageid = $this->request->param('id/d', 0);
        empty($messageid) && $this->error('参数不能为空！');
        $info = MessageModel::where([
            'id'      => $messageid,
            'send_to' => $this->auth->username,
        ])->findOrEmpty();

        empty($info) && $this->error('你查看的信息不存在！');
        if (0 == $info['status']) {
            $info->status = 1;
            $info->save();
        }
        $this->assign("info", $info);
        return $this->fetch();

    }

    //查看自己发的短消息
    public function read_only()
    {
        $messageid = $this->request->param('id/d', 0);
        empty($messageid) && $this->error('参数不能为空！');
        $info = MessageModel::where([
            'id'        => $messageid,
            'send_from' => $this->auth->username,
        ])->find();
        empty($info) && $this->error('你查看的信息不存在！');
        $this->assign("info", $info);
        return $this->fetch('read');

    }

    //系统消息列表
    public function group()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 1);
            $list  = MessageGroupModel::where('group_id', $this->auth->group_id)
                ->page($page, $limit)
                ->select();
            $total = MessageGroupModel::where('group_id', $this->auth->group_id)
                ->count();

            //未读已读判断
            foreach ($list as $key => $val) {
                $d = MessageDataModel::where(['user_id' => $this->auth->id, 'group_message_id' => $val['id']])->find();
                if (!$d) {
                    $list[$key]['isread'] = 0;
                } else {
                    $list[$key]['isread'] = 1;
                }
            }
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        $this->assign('title', '系统消息');
        return $this->fetch();
    }

    //查看系统消息
    public function read_group()
    {
        $group_id = $this->request->param('id/d', 0);
        empty($group_id) && $this->error('参数不能为空！');
        $info = MessageGroupModel::find($group_id);
        if (!$info) {
            $this->error('系统消息不存在！');
        }
        //检查查看表是否有记录,无则向message_data 插入浏览记录
        $check = MessageDataModel::where(['user_id' => $this->auth->id, 'group_message_id' => $group_id])->find();
        if (!$check) {
            MessageDataModel::create([
                'user_id'          => $this->auth->id,
                'group_message_id' => $group_id,
            ]);
        }
        $this->assign("info", $info);
        return $this->fetch('read');
    }

    //收件箱列表
    public function inbox()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 1);
            $list  = MessageModel::where('send_to', $this->auth->username)
                ->page($page, $limit)
                ->order('id DESC')
                ->select();
            $total = MessageModel::where('send_to', $this->auth->username)
                ->count();
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        $this->assign('title', '收件箱');
        return $this->fetch();
    }

    //发件箱列表
    public function outbox()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 1);
            $list  = MessageModel::where('send_from', $this->auth->username)
                ->page($page, $limit)
                ->order('id DESC')
                ->select();
            $total = MessageModel::where('send_from', $this->auth->username)
                ->count();
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        $this->assign('title', '发件箱');
        return $this->fetch();
    }

    /**
     *
     * 检查当前用户短消息相关权限
     */
    protected function messagecheck()
    {
        if ($this->groupCache[$this->auth->group_id]['allowsendmessage'] == 0) {
            $this->error("对不起你没有权限发短消息！");
        } else {
            //判断是否到限定条数
            $num = MessageModel::where('send_from', $this->auth->username)->count();
            if ($num >= $this->groupCache[$this->auth->group_id]['allowmessage']) {
                $this->error('你的短消息条数已达最大值!');
            }
        }
    }

}
