<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 短信息后台管理
// +----------------------------------------------------------------------
namespace app\admin\controller\message;

use app\admin\model\message\MessageData;
use app\admin\model\message\MessageGroup;
use app\admin\model\user\UserGroup;
use app\common\controller\Backend;

class Group extends Backend
{
    //初始化
    protected function initialize()
    {
        parent::initialize();
        $this->groupCache = cache("Member_Group");
        $this->modelClass = new MessageGroup;
    }
    /**
     * 群发消息管理
     */
    public function index()
    {
        if ($this->request->isAjax()) {

            [$page, $limit, $where] = $this->buildTableParames();
            $list                   = $this->modelClass
                ->where($where)
                ->with(['group'])
                ->page($page, $limit)
                ->select();
            foreach ($list as $k => $v) {
                $list[$k]['count'] = MessageData::where('group_message_id', $v['id'])->count();
            }
            $total = $this->modelClass
                ->where($where)
                ->with(['group'])
                ->count();
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        return $this->fetch();
    }

    /**
     * 管理按组或角色 群发消息
     */
    public function add()
    {
        $group = UserGroup::where('status', 1)
            ->order(["listorder" => "DESC", "id" => "DESC"])
            ->column('name', 'id');
        $this->assign("group", $group);
        return parent::add();
    }
}
