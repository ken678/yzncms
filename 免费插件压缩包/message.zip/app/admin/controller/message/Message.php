<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 短信息后台管理
// +----------------------------------------------------------------------
namespace app\admin\controller\message;

use app\admin\model\message\Message as MessageModel;
use app\admin\model\user\User as UserModel;
use app\common\controller\Backend;
use think\exception\ValidateException;

class Message extends Backend
{
    //初始化
    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new MessageModel;
    }

    /**
     * 发消息
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $data              = $this->request->post('info/a');
            $data['send_from'] = $this->auth->username;

            try {
                $this->validate($data, 'app\admin\validate\message\Message');
            } catch (ValidateException $e) {
                $this->error($e->getMessage());
            }

            if (!UserModel::getByUsername($data['send_to'])) {
                return $this->error('用户不存在');
            }
            if ($this->modelClass->save($data)) {
                $this->success('发送成功！');
            } else {
                $this->error('发送失败！');
            }

        } else {
            return $this->fetch();
        }
    }

}
