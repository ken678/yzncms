    //ueditor.config.js,编辑器所在的目录
    window.UEDITOR_HOME_URL = Config.__CDN__ + "/assets/addons/ueditor/";
    require.config({
        paths: {
            'ueditor.config': '../addons/ueditor/ueditor.config',
            'ueditor': '../addons/ueditor/ueditor.all',
            'zeroclipboard': '../addons/ueditor/third-party/zeroclipboard/ZeroClipboard',
        },
        shim: {
            'ueditor': {
                //注意：此处的依赖顺序不能颠倒
                deps: ['zeroclipboard', 'ueditor.config'],
                exports: 'UE',
                init: function(ZeroClipboard) {
                    //导出到全局变量，供ueditor使用
                    window.ZeroClipboard = ZeroClipboard;
                },
            }
        }
    });

    require(['form', 'upload'], function(Form, Upload) {
        var _bindevent = Form.events.bindevent;
        Form.events.bindevent = function(form) {
            _bindevent.apply(this, [form]);
            try {
                //绑定editor事件
                if ($('.editor', form).length > 0) {
                    require(['ueditor'], function(UE, undefined) {
                        UE.list = [];
                        $('.editor', form).each(function() {
                            var id = $(this).attr("id");
                            var name = $(this).attr("name");
                            $(this).removeClass('layui-textarea');

                            var simple_mode = Yzn.api.parame($(this).data('simple-mode'), false);

                            var config = {
                                serverUrl: Yzn.api.fixurl('/addons/ueditor/api/index'),
                                allowDivTransToP: false, //转换p标签
                                initialFrameWidth: '100%',
                                initialFrameHeight: 400, //初始化编辑器高度,默认320
                                maximumWords: 50000, //允许的最大字符数
                            }

                            if (simple_mode) {
                                // 如果是精简模式，设置精简的工具栏按钮
                                config.toolbars = [
                                    ['fullscreen', 'source', '|', 'undo', 'redo', '|', 'bold', 'italic', 'underline', 'pasteplain', '|',
                                        'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', '|', 'paragraph', 'fontfamily', 'fontsize', '|',
                                        'indent', '|', 'justifyleft', 'justifycenter', 'justifyright', '|', 'link', '|', 'simpleupload', 'insertimage', 'insertvideo',
                                        'attachment', 'insertframe', 'pagebreak', '|', 'horizontal', 'inserttable', '|', 'preview'
                                    ]
                                ];
                            }

                            UE.list[id] = UE.getEditor(id, config);

                            UE.list[id].addListener("contentChange", function () {
                                $('#' + id).val(this.getContent());
                                $('textarea[name="' + name + '"]').val(this.getContent());
                            })

                            //打开图片管理
                            UE.list[id].addListener("upload.online", function(e, editor, dialog) {
                                dialog.close(false);
                                Yzn.api.open("general.attachments/select?element_id=&multiple=true&mimetype=image/*", "选择", {
                                    callback: function(data) {
                                        var urlArr = data.url.split(/\,/);
                                        urlArr.forEach(function(item, index) {
                                            var url = Yzn.api.cdnurl(item);
                                            editor.execCommand('insertimage', {
                                                src: url
                                            });
                                        });
                                    }
                                });
                            });

                            //打开附件管理
                            UE.list[id].addListener("file.online", function(e, editor, dialog) {
                                dialog.close(false);
                                Yzn.api.open("general.attachments/select?element_id=&multiple=true&mimetype=application/*", "选择", {
                                    callback: function(data) {
                                        var urlArr = data.url.split(/\,/);
                                        urlArr.forEach(function(item, index) {
                                            var url = Yzn.api.cdnurl(item);
                                            editor.execCommand('insertfile', {
                                                url: url
                                            });
                                        });
                                    }
                                });
                            });
                        });
                    })
                }
            } catch (e) {}
        }
    });