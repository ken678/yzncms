<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | dedecmsv5.7数据转换插件
// +----------------------------------------------------------------------
namespace addons\dedetoyzn;

use app\common\library\Menu;
use think\Addons;

class Dedetoyzn extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                "name"    => "dedetoyzn",
                "title"   => "织梦数据转换",
                "sublist" => [
                    ["name" => "dedetoyzn/init", "title" => "初始化"],
                    ["name" => "dedetoyzn/start", "title" => "任务执行"],
                ],
            ],
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("dedetoyzn");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("dedetoyzn");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("dedetoyzn");
        return true;
    }
}
