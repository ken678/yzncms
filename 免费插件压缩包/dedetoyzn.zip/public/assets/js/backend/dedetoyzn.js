define(['jquery', 'form'], function($, Form) {
    var Controller = {
        index: function() {
            layui.form.on('submit', function(data) {
                $('.layui-btn').addClass('layui-btn-disabled').prop('disabled', true).html('<i class="layui-icon layui-icon-loading layui-icon layui-anim layui-anim-rotate layui-anim-loop"></i> 转换中...');
                Yzn.api.ajax({
                    url: "dedetoyzn/init",
                    data: data.field,
                }, function(data, ret) {
                    $('#change_div').show();
                    $('#change_html').html('<p>' + ret.msg + '</p>');
                    start_change(0);
                    return false
                }, function(data, ret) {
                    $('.layui-btn').attr('disabled', false).removeClass("layui-btn-disabled").html('开始转换');
                    Layer.msg(ret.msg, { icon: 2 });
                });
                return false;
            });

            function start_change(page) {
                Yzn.api.ajax({
                    type: "GET",
                    url: "dedetoyzn/start?page=" + page,
                }, function(data, ret) {
                    if (data.code == 1) {
                        start_change(data.page);
                        $('#change_html').append('<p>' + ret.msg + '</p>');
                    } else if (data.code == 2) {
                        $('.layui-btn').attr('disabled', false).removeClass("layui-btn-disabled").html('开始转换');
                        Layer.msg(ret.msg, { icon: 1 });
                    } else {

                    }
                    return false
                }, function(data, ret) {
                    Layer.msg(ret.msg, { icon: 2 });
                    $('.layui-btn').attr('disabled', false).removeClass("layui-btn-disabled").html('重新转换');
                });
            }
        },
    };
    return Controller;
});