require.config({
    paths: {
        'easymde': '../addons/easymde/easymde.min',
    },
    shim: {
        'easymde': ['css!../addons/easymde/css/easymde.min.css','css!../addons/easymde/css/font-awesome.min.css']
    }
});
require(['form', 'upload'], function(Form, Upload) {
    var _bindevent = Form.events.bindevent;
    Form.events.bindevent = function(form) {
        _bindevent.apply(this, [form]);
        try {
            if ($('.markdown', form).length > 0) {
                require(['easymde'], function(EasyMDE) {
                    var insert = function(e, url, type) {
                        var urlArr = url.split(/\,/);
                        $.each(urlArr, function() {
                            var url = Yzn.api.cdnurl(this, true);
                            if (type && type == 'image') {
                                e.codemirror.replaceSelection("\n" + '![输入图片说明](' + url + ')');
                            } else {
                                e.codemirror.replaceSelection("\n" + '[输入链接说明](' + url + ')');
                            }
                        });
                    };

                    var easymdes = {};
                    $('.markdown', form).each(function() {
                        var that = this;
                        var id = $(that).attr('id');
                        var easyMDE = new EasyMDE({
                            element: that,
                            promptURLs: true,
                            autoDownloadFontAwesome:false,
                            promptTexts: {
                                link: "URL地址:",
                            },
                            forceSync: true,
                            toolbar: [
                                "bold", "strikethrough", "italic", "heading", "heading-2", "heading-3", "|",
                                "code", "quote", "|",
                                "unordered-list", "ordered-list", "table", "|",
                                "link", "upload-image", "|", "preview", "side-by-side", "fullscreen", "|",
                                "guide"
                            ],
                            lineNumbers: true,
                            uploadImage: true,
                            status: false,
                            imageUploadFunction: (file, onSuccess, onError) => {
                                Upload.api.send(file, function(data) {
                                    url = Yzn.api.cdnurl(data.url, true);
                                    if (file.type.indexOf("image") !== -1) {
                                        insert(easyMDE, url, 'image');
                                    } else {
                                        insert(easyMDE, url, 'file');
                                    }
                                })
                            }
                        });

                        /*easyMDE.codemirror.on("change", () => {
                            $(that).val(easyMDE.value());
                        });*/

                        easymdes[id] = easyMDE;
                    })
                })
            }
        } catch (e) {}
    }
})