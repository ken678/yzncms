define(['jquery', 'table'], function($, Table) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'cms.order/index',
                search: false,
                cols: [
                    [
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'trade_sn', width: 240, align: "left", title: '订单ID' },
                        { field: 'title', width: 120, title: '标题' },
                        { field: 'catid', width: 80, title: '栏目id' },
                        { field: 'content_id', width: 80, title: '内容id' },
                        { field: 'pay_price', width: 100, title: '支付金额', templet: '<div>{{ d.pay_price }} {{#  if(d.type==1){ }} 元 {{#  } else { }} 点 {{#  } }}</div>' },
                        { field: 'pay_type', width: 100, title: '支付类型' },
                        { field: 'pay_time', width: 180, title: '支付时间', search: 'range', templet: Table.formatter.datetime },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                        {
                            field: 'status',
                            width: 90,
                            title: '订单状态',
                            templet: Table.formatter.label,
                            selectList: { 'succ': '已完成', 'cancel': '取消', 'unpay': '待支付' },
                            custom: { 'succ': "green", 'cancel': "orange", 'unpay': "red" }
                        },
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
    };
    return Controller;
});