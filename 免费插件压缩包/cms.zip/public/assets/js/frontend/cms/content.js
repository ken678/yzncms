define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        publish: function() {
            Form.api.bindevent($("form.layui-form"), function(data, ret) {
                $(".layer-footer [lay-submit]", this).addClass("layui-btn-disabled", "btn-disabled");
                setTimeout(function() {
                    location.href = Yzn.api.fixurl('cms.content/published');
                }, 1500);
            });

            layui.form.on('select(filter)', function(data) {
                location.href = data.value
            });
        },
        published: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                edit_url: 'cms.content/edit',
                delete_url: 'cms.content/del',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'cms.content/published',
                search: false,
                cols: [
                    [
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'title', title: '标题' },
                        { field: 'catname', width: 120, title: '所属栏目' },
                        { field: 'create_time', width: 180, title: '发布时间' },
                        { field: 'url', width: 60, align: "center", title: 'URL', templet: Table.formatter.url },
                        { field: 'status', width: 90, align: "center", title: '状态', templet: '#status' },
                        {
                            width: 85,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    class: 'layui-btn layui-btn-success layui-btn-xs',
                                    icon:'iconfont icon-edit-2-line',
                                    text: "",
                                    title: '编辑信息',
                                    extend: '',
                                    url: Table.init.edit_url,
                                }], , 'delete'
                            ]
                        }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        }
    };
    return Controller;
});