define(['jquery', 'table', 'form'], function($, Table, Form) {
    Yzn.config.openArea = ['90%', '90%'];
    var Controller = {
        index: function() {
            var B_tab_height = parent.layui.$("#content>.pear-frame").length > 0 ? 93 : 135;
            var B_frame_height = parent.layui.$("#content").height() - B_tab_height;

            $(window).on('resize', function() {
                setTimeout(function() {
                    B_frame_height = parent.layui.$("#content").height() - B_tab_height;
                    frameheight();
                }, 100);
            });

            $('.collapse').on("click", function() {
                var t = $(this).find('.layui-icon');
                $('#left-sider').toggleClass("layui-hide");
                if ($('#left-sider').hasClass("layui-hide")) {
                    t.attr("class", "layui-icon layui-icon-shrink-right");
                    $("#right-box").attr("class", 'layui-col-md12 layui-col-sm12');
                } else {
                    t.attr("class", "layui-icon layui-icon-spread-left");
                    $("#right-box").attr("class", 'layui-col-md10 layui-col-sm12');
                };
            })

            function frameheight() {
                $("#categorys").height(B_frame_height);
                $("#iframe_content").height(B_frame_height + 36);
            }
            frameheight();

            require(['jstree'], function() {

                let isExpanded = false;
                $('.openAll').click(function(e) {
                    $("#category-tree").jstree(isExpanded === true ? "open_all" : "close_all");

                    $(this).html(isExpanded ? '<i class="iconfont icon-add-line"></i> 全部展开' : '<i class="iconfont icon-subtract-line"></i> 全部折叠')

                    isExpanded = !isExpanded;
                });

                $('#category-tree').on("activate_node.jstree", function(e, data) {
                    var node = data.node;
                    if (node.original.url) {
                        $('#iframe_content').attr('src', node.original.url);
                    }
                });

                $('#category-tree').jstree({
                    "themes": {
                        "stripes": true
                    },
                    "core": {
                        "multiple": false,
                        "data": Config.categoryList
                    }
                });
            })

        },
        panl: function() {
            require(['echarts', 'echarts-theme'], function(Echarts, undefined) {
                // 基于准备好的dom，初始化echarts实例
                var echartsRecords = Echarts.init(document.getElementById('echarts-records'), 'walden');
                // 指定图表的配置项和数据
                var optionRecords = {
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {},
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    toolbox: {
                        feature: {
                            saveAsImage: {}
                        }
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: Config.xAxisData
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: Config.seriesData
                };

                // 使用刚指定的配置项和数据显示图表。
                echartsRecords.setOption(optionRecords);
                // echarts 窗口缩放自适应
                window.onresize = function() {
                    echartsRecords.resize();
                }

                //点击按钮
                $(document).on("click", ".btn-time", function() {
                    var start_time = $(this).data("start");
                    var end_time = $(this).data("end");
                    $(".datetime").val(start_time + ' - ' + end_time);
                    refreshEchart(start_time + ' - ' + end_time);
                });

                layui.lay('.datetime').each(function() {
                    layui.laydate.render({
                        elem: this,
                        trigger: 'click',
                        range: true,
                        type: 'datetime',
                        done: function(value, date) {
                            refreshEchart(value);
                        }
                    });
                });

                //点击刷新
                $(document).on("click", ".btn-refresh", function() {
                    if ($(this).data("type")) {
                        refreshEchart($(this).data("type"), "");
                    } else {
                        var input = $(this).closest(".layui-btn-group").find(".datetime");
                        var type = $(input).data("type");
                        var date = $(input).val();
                        refreshEchart(type, date);
                    }
                });

                var refreshEchart = function(date) {
                    var ok = function(res) {
                        optionRecords.xAxis.data = res.xAxisData;
                        optionRecords.series = res.seriesData;
                        echartsRecords.clear();
                        echartsRecords.setOption(optionRecords, true);
                        return false;
                    };
                    Yzn.api.ajax({
                        url: 'cms.cms/panl',
                        data: { date: date }
                    }, ok);

                };
                //icon动画
                $(".panel a").hover(function() {
                    $(this).find(".layui-anim").addClass("layui-anim-scaleSpring");
                }, function() {
                    $(this).find(".layui-anim").removeClass("layui-anim-scaleSpring");
                })

            })

        },
        classlist: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: 'cms.cms/add?catid=' + Config.catid,
                edit_url: 'cms.cms/edit?catid=' + Config.catid,
                delete_url: "cms.cms/del?catid=" + Config.catid,
                multi_url: 'cms.cms/multi?catid=' + Config.catid,
                recyclebin_url: 'cms.cms/recyclebin?catid=' + Config.catid,
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add', 'delete', [{
                    text: '批量移动',
                    auth: 'remove',
                    icon: 'iconfont icon-drag-move-2-fill',
                    class: 'layui-btn layui-btn-sm layui-btn-normal btn-move btn-disabled layui-btn-disabled',
                    extend: '',
                }], 'recyclebin'],
                url: 'cms.cms/classlist?catid=' + Config.catid,
                lineStyle: 'height: 45px;',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'listorder', width: 70, title: '排序', edit: 'text', search: false },
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'title', align: "left", title: '标题', templet: '#title', searchOp: 'like' },
                        { field: 'flag', width: 100, title: '属性', hide: true, selectList: { 1: '置顶', 2: '头条', 3: '特荐', 4: '推荐', 5: '热点', 6: '幻灯' }, searchOp: 'FIND_IN_SET' },
                        { field: 'thumb', width: 70, align: "center", title: '图片', search: false, templet: Table.formatter.image },
                        { field: 'hits', width: 80, title: '点击量', search: 'between', searchTip: '点击量' },
                        { field: 'update_time', width: 160, title: '更新时间', search: 'range' },
                        { field: 'url', width: 60, align: "center", title: 'URL', templet: Table.formatter.url, search: false },
                        { field: 'status', width: 100, align: "center", title: '状态', unresize: true, templet: Table.formatter.switch, tips: '待审核|通过', selectList: { 0: '待审核', 1: '通过' } },
                        { fixed: 'right', width: 90, title: '操作', templet: Table.formatter.tool, operat: ['edit', 'delete'] }
                    ]
                ],
                page: {}
            });

            $('body').on('click', '.btn-move', function() {
                var checkStatus = layui.table.checkStatus('currentTable'),
                    ids = [],
                    data = checkStatus.data;
                if (data.length > 0) {
                    $.each(data, function(i, v) {
                        ids.push(v.id);
                    });
                    Layer.open({
                        title: '批量移动',
                        type: 1,
                        content: $('#remove'),
                        area: ['300px', '250px'],
                        btn: ['移动'],
                        yes: function(index, layero) {
                            var tocatid = $("select[name='remove']").val();
                            if (tocatid == 0) {
                                Layer.msg("请选择移动的栏目", { icon: 2 });
                                return;
                            }
                            Yzn.api.ajax({
                                url: "cms.cms/remove?catid=" + Config.catid,
                                data: { 'ids': ids, 'tocatid': tocatid },
                            }, function(data) {
                                layui.table.reload('currentTable');
                                Layer.close(index);
                            })
                        },
                        end: function() {
                            $('#remove').hide();
                        }
                    });
                } else {
                    Layer.msg("请选择需要移动的数据", { icon: 2 });
                }
            });

            //重写按钮添加
            Table.toolbarEvents['btn-add'] = function(obj, options) {
                var url = options.init.add_url;
                parent.Yzn.api.open(url, $(this).data("original-title") || $(this).attr("title") || '添加', $(this).data() || {});
            }

            //重写按钮编辑
            Table.toolEvents['btn-editone'] = function(obj, options) {
                var data = obj.data;
                var ids = data[options.pk];
                var row = $.extend({}, data ? data : {}, { id: ids });
                var url = options.init.edit_url;
                parent.Yzn.api.open(Table.api.toolSpliceUrl(url, row), $(this).data("original-title") || $(this).attr("title") || '编辑', $(this).data() || {});
            }

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                var insertHtml = function(html) {
                    if (typeof UE !== 'undefined' && typeof UE.list["editor-content"] !== 'undefined') {
                        UE.list["editor-content"].setContent(html, false);
                    } else {
                        Layer.open({
                            content: "当前编辑器不支持插入html,请至插件市场安装编辑器插件",
                            title: "温馨提示"
                        });
                    }
                };
                //标题检查重复
                var input = $("input[name='modelField[title]']");
                input.after("<button type='button' class='layui-btn layui-btn-sm btn-repeat'>重复检测</button>");

                $(document).on("click", ".btn-repeat", function(e) {
                    Yzn.api.ajax({
                        url: "cms.cms/check_title",
                        data: {
                            'id': Config.id,
                            'catid': Config.catid,
                            'data': input.val()
                        },
                    })
                });
                //图片本地化
                $(document).on("click", ".btn-grabimg", function(e) {
                    Yzn.api.ajax({
                        url: "general.attachments/getUrlFile",
                        data: {
                            'content': $("#editor-content").val(),
                            'type': 'images'
                        },
                    }, function(data, ret) {
                        insertHtml(data);
                        return false
                    })

                });
                //检查违禁词
                $(document).on("click", ".btn-filterword", function(a) {
                    Yzn.api.ajax({
                        url: "ajax/filterWord",
                        data: { content: $("#editor-content").val() }
                    }, function(data, ret) {

                    }, function(data, ret) {
                        if ($.isArray(data)) {
                            if (data.length > 1) {
                                Layer.alert("违禁词：" + data.join(","), { icon: 2 });
                            } else {
                                Layer.alert(ret.msg);
                            }
                            return false;
                        }
                    });
                });
                //提取关键词
                $(document).on("click", ".btn-getwords", function(a) {
                    require(['tagsinput'], function() {
                        Yzn.api.ajax({
                            url: "getwords/index",
                            data: {
                                content: $("#editor-content").val()
                            }
                        }, function(data, ret) {
                            $(".tags-keywords").importTags(data);
                        });
                    });
                });
                Form.api.bindevent($("form.layui-form"), function(data, ret) {
                    Layer.confirm(ret.msg, {
                        btn: ['继续添加', '返回列表'] //按钮
                    }, function() {
                        $(window).scrollTop(0);
                        location.reload();
                    }, function() {
                        parent.$('#iframe_content').contents().find('.btn-refresh')[0].click();
                        var index = parent.Layer.getFrameIndex(window.name);
                        parent.Layer.close(index);
                    });
                    return false;
                });
            }
        }
    };
    return Controller;
});