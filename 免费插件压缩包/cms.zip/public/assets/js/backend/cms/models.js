define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "cms.models/add",
                edit_url: "cms.models/edit",
                delete_url: "cms.models/del",
                multi_url: 'cms.models/multi',
                field_url: 'cms.field/index',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add'],
                url: 'cms.models/index',
                search: false,
                cols: [
                    [
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'name', width: 120, title: '模型名称' },
                        { field: 'tablename', width: 120, title: '数据表' },
                        { field: 'description', align: "left", title: '描述' },
                        { field: 'type', width: 120, title: '类型', templet: '<div>{{#  if(d.type==1){ }} 独立表 {{#  } else { }} 主附表 {{#  } }} </div>' },
                        { field: 'create_time', width: 180, title: '创建时间' },
                        { field: 'status', width: 100, title: '状态', unresize: true, templet: Table.formatter.switch },
                        {
                            width: 150,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    text: '字段管理',
                                    url: Table.init.field_url,
                                    auth: 'field',
                                    class: 'layui-btn layui-btn-xs layui-btn-normal',
                                    extend: '',
                                }],
                                'edit', 'delete'
                            ]
                        }
                    ]
                ]
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});