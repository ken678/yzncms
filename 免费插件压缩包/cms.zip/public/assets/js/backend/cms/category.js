define(['jquery', 'table', 'form'], function($, Table, Form) {
    Yzn.config.openArea = ['80%', '80%'];
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "cms.category/add",
                edit_url: "cms.category/edit",
                delete_url: "cms.category/del",
                multi_url: 'cms.category/multi',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add', 'delete', [{
                        text: '栏目授权',
                        url: "cms.category/cat_priv",
                        auth: 'cat_priv',
                        class: 'layui-btn layui-btn-sm layui-btn-normal btn-dialog',
                        icon: 'iconfont icon-menu-line',
                    },
                    {
                        text: '栏目数据校正',
                        url: "cms.category/count_items",
                        class: 'layui-btn layui-btn-sm btn-ajax',
                        icon: 'iconfont icon-check-line',
                        extend: '',
                    },
                    {
                        text: "更新栏目缓存",
                        url: "cms.category/public_cache",
                        class: 'layui-btn layui-btn-sm btn-ajax',
                        icon: 'iconfont icon-loop-left-line',
                        extend: '',
                    }
                ]],
                url: 'cms.category/index',
                search: false,
                escape: false,
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'listorder', width: 70, title: '排序', edit: 'text' },
                        { field: 'id', width: 70, title: 'ID' },
                        {
                            field: 'catname',
                            align: "left",
                            title: '栏目名称',
                            templet: function(d) {
                                return '<span><a href="' + Table.init.edit_url + '?id=' + d.id + '" title="编辑信息" class="btn-dialog" data-table="currentTable">' + d.catname + '</a></span>';
                            }
                        },
                        { field: 'items', width: 80, title: '数据量' },
                        { field: 'catdir', width: 120, title: '唯一标识' },
                        { field: 'type', width: 90, title: '栏目类型', templet: Table.formatter.label, selectList: { 1: '单页', 2: '列表', 3: '外链' }, custom: { 1: "cyan", 2: "blue", 3: "green" }, search: false },
                        { field: 'modelname', width: 120, title: '所属模型' },
                        { field: 'url', width: 60, align: "center", title: 'URL', templet: Table.formatter.url },
                        { field: 'status', width: 100, align: "center", title: '状态', unresize: true, templet: Table.formatter.switch },
                        {
                            width: 170,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    text: '添加子栏目',
                                    auth: 'add',
                                    class: 'layui-btn layui-btn-xs layui-btn-normal btn-dialog',
                                    extend: '',
                                    url: function(row) {
                                        return Table.init.add_url + '?parentid=' + row.id;
                                    },
                                }],
                                'edit', 'delete'
                            ]
                        }
                    ]
                ],
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();

            //批理添加
            layui.form.on('radio(filter)', function(data) {
                if (1 == data.value) {
                    //批量
                    $('#normal_add').hide();
                    $('#catdir_tr').hide();
                    $('#batch_add').show();
                    $('#catname').attr('disabled', true).attr('lay-verify', '');

                }
                if (0 == data.value) {
                    $('#normal_add').show();
                    $('#catdir_tr').show();
                    $('#batch_add').hide();
                    $('#catname').attr('disabled', false).attr('lay-verify', 'required');
                }
            });

            //默认模型模板
            layui.form.on('select(filter)', function(data) {
                if (data.value) {
                    Yzn.api.ajax({
                        url: 'cms.category/public_tpl_file_list',
                        data: { id: data.value }
                    }, function(res) {
                        $('.category_template').val(res.data.category_template);
                        $('.category_template').next('.sp_hidden').val(res.data.category_template);
                        $('.list_template').val(res.data.list_template);
                        $('.list_template').next('.sp_hidden').val(res.data.list_template);
                        $('.show_template').val(res.data.show_template);
                        $('.show_template').next('.sp_hidden').val(res.data.show_template);
                        return false
                    });
                }
            });

            if (Config.parentid_modelid) {
                Yzn.api.ajax({
                    url: 'cms.category/public_tpl_file_list',
                    data: { id: Config.parentid_modelid }
                }, function(res) {
                    $('.category_template').val(res.data.category_template);
                    $('.category_template').next('.sp_hidden').val(res.data.category_template);
                    $('.list_template').val(res.data.list_template);
                    $('.list_template').next('.sp_hidden').val(res.data.list_template);
                    $('.show_template').val(res.data.show_template);
                    $('.show_template').next('.sp_hidden').val(res.data.show_template);
                    return false
                });

            }
        },
        edit: function() {
            Controller.api.bindevent();
        },
        cat_priv: function() {
            var act = Backend.api.query('act');
            if (act == 'authorization') {
                Form.api.bindevent($("form.layui-form"));

                layui.form.on('checkbox', function(data) {
                    var name = $(data.elem).data('name');
                    if (data.elem.checked == true) {
                        if (name == 0) {
                            $.each($("input[type='checkbox']"), function(i, rs) {
                                if (rs.disabled != true) {
                                    rs.checked = true;
                                }
                            })
                        } else {
                            $.each($("input[type='checkbox'][name='priv[" + name + "][]']"), function(i, rs) {
                                if (rs.disabled != true) {
                                    rs.checked = true;
                                }
                            });
                        }
                    } else {
                        if (name == 0) {
                            $.each($("input[type='checkbox']"), function(i, rs) {
                                rs.checked = false;
                            })
                        } else {
                            $.each($("input[type='checkbox'][name='priv[" + name + "][]']"), function(i, rs) {
                                rs.checked = false;
                            });
                        }
                    }
                    layui.form.render('checkbox');
                })
            } else {
                Table.init = {
                    table_elem: '#currentTable',
                    table_render_id: 'currentTable',
                };

                Table.render({
                    init: Table.init,
                    toolbar: ['refresh'],
                    url: 'cms.category/cat_priv',
                    search: false,
                    cols: [
                        [
                            { field: 'title', title: '角色名称' },
                            { field: 'num', title: '授权数量' },
                            { fixed: 'right', title: '操作', width: 120, templet: '#barTool' }
                        ]
                    ]
                });

                Table.api.bindevent();
            }


        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));

                layui.form.on('radio(type)', function(data) {
                    $(".lay").addClass("layui-hide");
                    //单页
                    if (data.value == 1) {
                        $('#modeTab').show();
                        $('#authTab').hide();
                        $('.lay-page').removeClass("layui-hide");
                    }
                    //列表
                    if (data.value == 2) {
                        $('#modeTab').show();
                        $('#authTab').show();
                        $('.lay-list').removeClass("layui-hide");
                    }
                    //外链
                    if (data.value == 3) {
                        $('#authTab').hide();
                        $('#modeTab').hide();
                        $('.lay-url').removeClass("layui-hide");
                    }
                });

                layui.form.on('select(fasttype)', function(data) {
                    $('#url').val($(data.elem).find("option:selected").attr("data-url"));
                });


                $("input[name='row[type]']:checked").next().trigger("click");

            }
        }
    };
    return Controller;
});