define(['jquery', 'table'], function($, Table) {
    Yzn.config.openArea = ['90%', '90%'];
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                delete_url: "cms.publish/del",
                edit_url: 'cms.cms/edit',
                multi_url: 'cms.publish/multi',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'delete',
                    [{
                        text: '通过审核',
                        auth: 'pass',
                        icon: 'iconfont icon-check-line',
                        class: 'layui-btn layui-btn-sm layui-btn-normal layui-btn-disabled btn-disabled',
                        extend: 'data-params="status=1" lay-event="btn-multi"',
                    }, {
                        text: '退稿',
                        auth: 'reject',
                        icon: 'iconfont icon-close-line',
                        class: 'layui-btn layui-btn-sm layui-btn-warm layui-btn-normal layui-btn-disabled btn-disabled',
                        extend: 'data-params="status=-1" lay-event="btn-multi"',
                    }]
                ],
                url: 'cms.publish/index',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'id', width: 70, title: 'ID' },
                        { field: 'title', title: '标题', search: false },
                        { field: 'catname', width: 180, title: '所属栏目', search: false },
                        { field: 'create_time', width: 180, title: '发布时间' },
                        { field: 'url', width: 60, align: "center", title: 'URL', search: false, templet: Table.formatter.url },
                        { field: 'status', width: 90, align: "center", title: '状态', templet: '#status' },
                        {
                            fixed: 'right',
                            width: 90,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    class: 'layui-btn layui-btn-success layui-btn-xs btn-dialog',
                                    icon: 'iconfont icon-edit-2-line',
                                    auth: 'edit',
                                    text: "",
                                    title: '编辑信息',
                                    url: function(row) {
                                        return Table.init.edit_url + '?catid=' + row.catid + '&id=' + row.content_id;
                                    },
                                }], 'delete'
                            ]
                        }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        }
    };
    return Controller;
});