define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                edit_url: "cms.tags/edit",
                delete_url: "cms.tags/del",
                modify_url: 'cms.tags/multi',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'delete',
                    [{
                        text: '数据重建',
                        url: "cms.tags/create",
                        class: 'layui-btn layui-btn-sm layui-btn-warm',
                        icon: 'iconfont icon-alert-line',
                        auth: 'create',
                    }],
                ],
                url: 'cms.tags/index',
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'listorder', width: 70, title: '排序', edit: 'text', search: false },
                        { field: 'id', width: 80, title: 'ID' },
                        { field: 'tag', align: "left", title: 'Tags名称', searchOp: 'like' },
                        { field: 'usetimes', width: 100, title: '信息总数' },
                        { field: 'hits', width: 100, title: '点击量', search: 'between', searchTip: '点击量' },
                        { field: 'url', width: 60, align: "center", title: 'URL', templet: Table.formatter.url, search: false },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                        { field: 'update_time', width: 180, title: '更新时间', search: 'range' },
                        { width: 90, title: '操作', templet: Table.formatter.tool, operat: ['edit', 'delete'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        create: function() {

        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});