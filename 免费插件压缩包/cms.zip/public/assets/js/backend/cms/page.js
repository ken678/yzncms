define(['jquery', 'table', 'form'], function($, Table, Form) {
    Yzn.config.openArea = ['90%', '90%'];
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                edit_url: "cms.page/edit",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'cms.page/index',
                lineStyle: 'height: 50px;',
                cols: [
                    [
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'title', align: "left", title: '标题' },
                        { field: 'category.catname', width: 120, align: "left", title: '所属栏目' },
                        { field: 'catid', width: 80, align: "left", title: '栏目ID' },
                        { field: 'thumb', width: 100, title: '缩略图', search: false, templet: Table.formatter.image },
                        { field: 'hits', width: 80, title: '点击量' },
                        { field: 'publish_time', width: 180, title: '发布时间', search: 'range', templet: Table.formatter.datetime },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                        { field: 'update_time', width: 180, title: '更新时间', search: 'range' },
                        { width: 60, title: '操作', templet: Table.formatter.tool, operat: ['edit'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});