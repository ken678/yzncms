define(['jquery', 'table'], function($, Table) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                delete_url: "cms.order/del",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'cms.order/index',
                cols: [
                    [
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'trade_sn', width: 250, align: "left", title: '订单ID' },
                        { field: 'title', title: '标题' },
                        { field: 'user_id', width: 80, title: '会员id' },
                        { field: 'catid', width: 80, title: '栏目id' },
                        { field: 'contentid', width: 80, title: '内容id' },
                        { field: 'pay_price', width: 120, title: '支付金额', templet: '<div>{{ d.pay_price }} {{#  if(d.type==1){ }} 元 {{#  } else { }} 点 {{#  } }}</div>' },
                        { field: 'pay_type', width: 100, title: '支付类型' },
                        { field: 'pay_time', width: 180, title: '支付时间', search: 'range', templet: Table.formatter.datetime },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                        {
                            field: 'status',
                            width: 90,
                            title: '订单状态',
                            templet: Table.formatter.label,
                            selectList: { 'succ': '已完成', 'cancel': '取消', 'unpay': '待支付' },
                            custom: { 'succ': "green", 'cancel': "orange", 'unpay': "red" }
                        },
                        { width: 60, title: '操作', templet: Table.formatter.tool, operat: ['delete'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        }
    };
    return Controller;
});