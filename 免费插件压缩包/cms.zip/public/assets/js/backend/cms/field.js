define(['jquery', 'table', 'form'], function($, Table, Form) {
    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "cms.field/add?modelid=" + Config.modelid,
                edit_url: "cms.field/edit",
                delete_url: "cms.field/del",
                multi_url: 'cms.field/multi',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh',
                    [{
                        html: '<a class="layui-btn layui-btn-sm" type="button" href="' + Yzn.api.fixurl("cms.models/index") + '"><i class="iconfont icon-arrow-go-back-line"></i>&nbsp;返回模型</a>'
                    }], 'add'
                ],
                url: 'cms.field/index?id=' + Config.modelid,
                cols: [
                    [
                        { field: 'listorder', width: 60, title: '排序', edit: 'text', search: false },
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'name', align: "left", title: '字段名称' },
                        { field: 'title', align: "left", title: '标题' },
                        { field: 'type', width: 120, title: '字段类型' },
                        { field: 'ifsystem', width: 60, align: "center", title: '主表', templet: '<div>{{#  if(d.ifsystem){ }} 是 {{#  } }} </div>' },
                        { field: 'create_time', width: 180, title: '创建时间', search: 'range' },
                        { field: 'ifsearch', width: 90, align: "center", title: '搜索', templet: '#ifsearchTpl', unresize: true, selectList: { 0: '否', 1: '是' } },
                        { field: 'ifrequire', width: 90, align: "center", title: '必填', templet: '#ifrequireTpl', unresize: true, selectList: { 0: '否', 1: '是' } },
                        { field: 'isadd', width: 100, align: "center", title: '投稿显示', templet: '#isaddTpl', unresize: true, selectList: { 0: '隐藏', 1: '显示' } },
                        { field: 'status', width: 100, align: "center", title: '状态', templet: '#switchTpl', unresize: true, selectList: { 0: '禁用', 1: '启用' } },
                        {
                            width: 90,
                            title: '操作',
                            templet: function(d) {
                                if (d.iffixed) {
                                    return '<a class="layui-btn layui-btn-xs layui-btn-danger layui-btn-disabled">不可操作</a>';
                                } else {
                                    return Table.formatter.tool.call(this, d, this);
                                }
                            },
                            operat: ['edit', 'delete']
                        }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));

                layui.form.on('select(fieldtype)', function(data) {
                    $('#define').val($(data.elem).find("option:selected").attr("data-define"));
                    var ifstring = $(data.elem).find("option:selected").attr("data-ifstring");
                    //搜索隐显
                    if (ifstring == '1') {
                        $('#ifsearch').show();
                    } else {
                        $('#ifsearch').hide();
                    }
                    if (data.value == 'checkbox' || data.value == 'select' || data.value == 'selects' || data.value == 'radio' || data.value == 'selectpage' || data.value == 'custom') {
                        if (data.value == 'selectpage') {
                            $('#options .options').html($('#options2').html());
                        } else if (data.value == 'custom') {
                            $('#options .options').html($('#options3').html());
                        } else {
                            $('#options .options').html($('#options1').html());
                        }
                        $('#options').show();
                        layui.form.render();
                    } else {
                        $('#options').hide();
                    }
                });

                layui.form.on('select(fasttype)', function(data) {
                    $('#define').val($(data.elem).find("option:selected").attr("data-define"));
                });
                layui.form.on('select(pattern)', function(data) {
                    $('#pattern').val($(data.elem).find("option:selected").attr("data-define"));
                });
            }
        }
    };
    return Controller;
});