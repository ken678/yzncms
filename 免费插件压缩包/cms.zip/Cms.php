<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 内容管理插件
// +----------------------------------------------------------------------
namespace addons\cms;

use addons\cms\library\FulltextSearch;
use app\common\library\Menu;
use think\Addons;
use think\facade\Config;
use think\facade\Db;
use think\facade\Env;

class Cms extends Addons
{
    protected $ext_table = '_data';

    //后台菜单
    protected $menu = [
        [
            "name"    => "cms",
            "title"   => "cms内容管理",
            "icon"    => "iconfont icon-draft-line",
            "sublist" => [
                [
                    "name"      => "addon/config/name/cms",
                    "title"     => "站点配置",
                    "icon"      => "iconfont icon-settings-4-line",
                    'ismenu'    => 1,
                    "listorder" => 99,
                ],
                [
                    "name"      => "cms.category",
                    "title"     => "栏目列表",
                    "icon"      => "iconfont icon-menu-line",
                    "listorder" => 88,
                    "sublist"   => [
                        ["name" => "cms.category/index", "title" => "查看"],
                        ["name" => "cms.category/add", "title" => "新增"],
                        ["name" => "cms.category/cat_priv", "title" => "栏目授权"],
                        ["name" => "cms.category/edit", "title" => "编辑"],
                        ["name" => "cms.category/del", "title" => "删除"],
                        ["name" => "cms.category/multi", "title" => "批量更新"],
                    ],
                ],
                [
                    "name"      => "cms.cms",
                    "title"     => "管理内容",
                    "icon"      => "iconfont icon-draft-line",
                    "listorder" => 77,
                    "sublist"   => [
                        ["name" => "cms.cms/index", "title" => "查看"],
                        ["name" => "cms.cms/add", "title" => "新增"],
                        ["name" => "cms.cms/edit", "title" => "编辑"],
                        ["name" => "cms.cms/del", "title" => "删除"],
                        ["name" => "cms.cms/multi", "title" => "批量更新"],
                        ["name" => "cms.cms/remove", "title" => "批量移动"],
                        ["name" => "cms.cms/recyclebin", "title" => "回收站"],
                        ["name" => "cms.cms/destroy", "title" => "清空回收站"],
                        ["name" => "cms.cms/restore", "title" => "还原回收站"],
                    ],
                ],
                [
                    "name"      => "cms.page",
                    "title"     => "单页管理",
                    "icon"      => "iconfont icon-bill-line",
                    "listorder" => 9,
                    "sublist"   => [
                        ["name" => "cms.page/index", "title" => "查看"],
                        ["name" => "cms.page/edit", "title" => "编辑"],
                        ["name" => "cms.page/multi", "title" => "批量更新"],
                    ],
                ],
                [
                    "name"      => "cms.publish",
                    "title"     => "稿件管理",
                    "icon"      => "iconfont icon-draft-line",
                    "listorder" => 8,
                    "sublist"   => [
                        ["name" => "cms.publish/index", "title" => "查看"],
                        ["name" => "cms.publish/del", "title" => "删除"],
                        ["name" => "cms.publish/multi", "title" => "批量更新"],
                    ],
                ],
                [
                    "name"      => "cms.order",
                    "title"     => "订单管理",
                    "icon"      => "iconfont icon-file-list-3-line",
                    "listorder" => 7,
                    "sublist"   => [
                        ["name" => "cms.order/index", "title" => "查看"],
                        ["name" => "cms.order/del", "title" => "删除"],
                    ],
                ],
                [
                    "name"      => "cms.tags",
                    "title"     => "Tags管理",
                    "icon"      => "iconfont icon-price-tag-3-line",
                    "listorder" => 6,
                    "sublist"   => [
                        ["name" => "cms.tags/index", "title" => "查看"],
                        ["name" => "cms.tags/add", "title" => "新增"],
                        ["name" => "cms.tags/edit", "title" => "编辑"],
                        ["name" => "cms.tags/del", "title" => "删除"],
                        ["name" => "cms.tags/create", "title" => "数据重建"],
                        ["name" => "cms.tags/multi", "title" => "批量更新"],
                    ],
                ],
                [
                    "name"      => "cms.models",
                    "title"     => "模型管理",
                    "icon"      => "iconfont icon-apps-line",
                    "listorder" => 4,
                    "sublist"   => [
                        ["name" => "cms.models/index", "title" => "查看"],
                        ["name" => "cms.models/add", "title" => "新增"],
                        ["name" => "cms.models/edit", "title" => "编辑"],
                        ["name" => "cms.models/del", "title" => "删除"],
                        ["name" => "cms.models/multi", "title" => "批量更新"],
                    ],
                ],
                [
                    "name"    => "cms.field",
                    "title"   => "字段管理",
                    "ismenu"  => 0,
                    "sublist" => [
                        ["name" => "cms.field/index", "title" => "查看"],
                        ["name" => "cms.field/add", "title" => "新增"],
                        ["name" => "cms.field/edit", "title" => "编辑"],
                        ["name" => "cms.field/del", "title" => "删除"],
                        ["name" => "cms.field/multi", "title" => "批量更新"],
                    ],
                ],
            ],
        ],

    ];

    //安装
    public function install()
    {
        Menu::create($this->menu);
        return true;
    }

    //卸载
    public function uninstall()
    {
        $droptables = request()->param("droptables");
        $auth       = \app\admin\library\Auth::instance();
        //只有开启调试且为超级管理员才允许删除相关数据库
        if ($droptables && Env::get('APP_DEBUG') && $auth->isAdministrator()) {
            // 删除模型中建的表
            $table_list = Db::name('model')->where('module', 'cms')->field('tablename,type,id')->select();
            if ($table_list) {
                foreach ($table_list as $val) {
                    $tablename = Config::get('database.connections.mysql.prefix') . $val['tablename'];
                    Db::execute("DROP TABLE IF EXISTS `{$tablename}`;");
                    if ($val['type'] == 2) {
                        Db::execute("DROP TABLE IF EXISTS `{$tablename}{$this->ext_table}`;");
                    }
                    Db::name('model_field')->where('modelid', $val['id'])->delete();
                }
            }
            //删除模型中的表
            Db::name('model')->where(['module' => 'cms'])->delete();
        }
        Menu::delete("cms");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("cms");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("cms");
        return true;
    }

    //或者run方法
    public function userSidenavAfter($content)
    {
        return $this->fetch('userSidenavAfter');
    }

    public function xunsearchIndexReset($project)
    {
        if ($project['name'] == 'cms') {
            return FulltextSearch::reset();
        }
    }

    /**
     * 插件升级方法
     */
    public function upgrade()
    {
        Menu::upgrade('cms', $this->menu);
        return true;
    }

    public function appInit()
    {
        //全局变量规则，全部路由有效
        \think\facade\Route::pattern([
            'catdir' => "[A-Za-z0-9\-\_]+",
            'id'     => "\d+",
            'catid'  => "\d+",
        ]);

        //此函数需要全局调用
        if (is_file(ADDON_PATH . 'cms' . DS . 'function.php')) {
            include_once ADDON_PATH . 'cms' . DS . 'function.php';
        }

        // 设置替换字符串
        $cdnurl                             = Config::get('site.cdnurl');
        $tpl_replace_string                 = Config::get('view.tpl_replace_string');
        $tpl_replace_string['__IMG_PATH__'] = $cdnurl . "/assets/addons/cms/images";
        $tpl_replace_string['__CSS_PATH__'] = $cdnurl . "/assets/addons/cms/css";
        $tpl_replace_string['__JS_PATH__']  = $cdnurl . "/assets/addons/cms/js";
        Config::set(['tpl_replace_string' => $tpl_replace_string], 'view');
    }
}
