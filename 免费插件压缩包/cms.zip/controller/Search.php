<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 搜索管理
// +----------------------------------------------------------------------
namespace addons\cms\controller;

use addons\cms\library\FulltextSearch;
use addons\cms\model\Cms as CmsModel;
use addons\cms\model\Models;
use think\exception\ValidateException;
use think\facade\Db;

class Search extends Cmsbase
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = [];
    protected $cms_model   = null;

    protected function initialize()
    {
        parent::initialize();
        $this->cms_model = new CmsModel;
    }

    // 搜索
    public function index()
    {
        if ($this->cmsConfig['web_site_searchtype'] == 'xunsearch') {
            $info = get_addon_info('xunsearch');
            if (!$info || $info['status'] != 1) {
                return $this->error('请在后台插件管理中安装《迅搜搜索》并启用后再尝试');
            }
            return $this->xunsearch();
        }
        $seo = seo('', '搜索结果');
        //模型
        $modelid = $this->request->param('modelid/d', 0);
        //关键词
        $keyword = $this->request->param('keyword/s', '', 'trim,safe_replace,strip_tags,htmlspecialchars');
        $keyword = str_replace('%', '', $keyword); //过滤'%'，用户全文搜索
        //时间范围
        $time = $this->request->param('time/s', '');

        try {
            $this->validate([
                'keyword' => $keyword,
            ], [
                'keyword|标题关键词' => 'chsDash|max:25',
            ]);
        } catch (ValidateException $e) {
            $this->error($e->getMessage());
        }
        $begin = microtime(true);
        //按时间搜索
        if ($time == 'day') {
            $search_time = time() - 86400;
            $sql_time    = ' AND publish_time > ' . $search_time;
        } elseif ($time == 'week') {
            $search_time = time() - 604800;
            $sql_time    = ' AND publish_time > ' . $search_time;
        } elseif ($time == 'month') {
            $search_time = time() - 2592000;
            $sql_time    = ' AND publish_time > ' . $search_time;
        } elseif ($time == 'year') {
            $search_time = time() - 31536000;
            $sql_time    = ' AND publish_time > ' . $search_time;
        } else {
            $search_time = 0;
            $sql_time    = '';
        }
        //搜索历史记录
        $shistory = session("shistory");
        if (!$shistory) {
            $shistory = [];
        }
        array_unshift($shistory, $keyword);
        $shistory = array_slice(array_unique($shistory), 0, 10);
        //加入搜索历史
        session("shistory", $shistory);

        $modellist = Models::where('status', 1)->where('module', 'cms')->select()->toArray();
        if (!$modellist) {
            return $this->error('没有可搜索模型~');
        }

        if ($modelid) {
            if (!array_key_exists($modelid, $modellist)) {
                $this->error('模型错误~');
            }
            $searchField = Db::name('model_field')->where('modelid', $modelid)->where('ifsystem', 1)->where('ifsearch', 1)->column('name');
            if (empty($searchField)) {
                $this->error('没有设置搜索字段~');
            }
            $where = '';
            foreach ($searchField as $vo) {
                $where .= "$vo like '%$keyword%' or ";
            }
            $where = '(' . substr($where, 0, -4) . ') ';
            $where .= " AND status='1' $sql_time";
            $list = $this->cms_model->getList($modelid, $where, false, '*', "listorder DESC,id DESC", 10, 1, false);
        } else {
            foreach ($modellist as $key => $vo) {
                $searchField = Db::name('model_field')->where('modelid', $key)->where('ifsystem', 1)->where('ifsearch', 1)->column('name');
                if (empty($searchField)) {
                    continue;
                }
                $where = '';
                foreach ($searchField as $v) {
                    $where .= "$v like '%$keyword%' or ";
                }
                $where = '(' . substr($where, 0, -4) . ') ';
                $where .= " AND status='1' $sql_time";
                $list = $this->cms_model->getList($key, $where, false, '*', 'listorder DESC,id DESC', 10, 1, false);
                if ($list->isEmpty()) {
                    continue;
                } else {
                    break;
                }
            }
        }
        $count = $list->total();
        $end   = microtime(true);
        $this->assign([
            'time'        => $time,
            'modelid'     => $modelid,
            'keyword'     => $keyword,
            'shistory'    => $shistory,
            'SEO'         => $seo,
            'list'        => $list,
            'count'       => $count,
            'modellist'   => $modellist,
            'search_time' => number_format(($end - $begin), 6), //运行时间
            'pages' => $list->render(),
        ]);
        if (!empty($keyword)) {
            return $this->fetch('/search_result');
        } else {
            return $this->fetch('/search');
        }
    }

    //迅搜简单搜索示例 复杂搜索重写此方法
    public function xunsearch()
    {
        $seo = seo('', '搜索结果');
        //模型
        $modelid = $this->request->param('modelid/d', 0);
        //关键词
        $keyword = $this->request->param('keyword/s', '', 'trim,safe_replace,strip_tags,htmlspecialchars');
        $keyword = str_replace('%', '', $keyword); //过滤'%'，用户全文搜索

        //时间范围
        $time     = $this->request->param('time/s', '');
        $page     = $this->request->get('page/d', '1');
        $pagesize = 5;
        $order    = $this->request->get('order', '');
        $fulltext = $this->request->get('fulltext/d', '1');
        $fuzzy    = $this->request->get('fuzzy/d', '0');
        $synonyms = $this->request->get('synonyms/d', '0');

        try {
            $this->validate([
                'keyword' => $keyword,
            ], [
                'keyword|标题关键词' => 'chsDash|max:25',
            ]);
        } catch (ValidateException $e) {
            $this->error($e->getMessage());
        }

        $search = FulltextSearch::setQuery($keyword, $fulltext, $fuzzy, $synonyms);
        if ($modelid > 0) {
            $search->addQueryString("modelid:({$modelid})");
        }
        //按时间搜索
        if ($time == 'day') {
            //一天
            $search_time = time() - 86400;
            $search->addRange('publish_time', $search_time, time());
        } elseif ($time == 'week') {
            //一周
            $search_time = time() - 604800;
            $search->addRange('publish_time', $search_time, time());
        } elseif ($time == 'month') {
            //一月
            $search_time = time() - 2592000;
            $search->addRange('publish_time', $search_time, time());
        } elseif ($time == 'year') {
            //一年
            $search_time = time() - 31536000;
            $search->addRange('publish_time', $search_time, time());
        }
        $modellist = Models::where('status', 1)->where('module', 'cms')->select()->toArray();
        if (!$modellist) {
            return $this->error('没有可搜索模型~');
        }
        $query  = ['keyword' => $keyword, 'modelid' => $modelid];
        $result = FulltextSearch::search($page, $pagesize, $order, $query);
        //获取热门搜索
        $hot = FulltextSearch::hot();
        $this->assign([
            'time'        => $time,
            'modelid'     => $modelid,
            'keyword'     => $keyword,
            'SEO'         => $seo,
            'list'        => $result['list'],
            'count'       => $result['count'],
            'total'       => $result['total'],
            'search_time' => $result['search_time'], //运行时间
            'pages' => $result['list'] ? $result['list']->render() : '',
            'search'      => $result['search'],
            'corrected'   => $result['corrected'],
            'related'     => $result['related'],
            'hot'         => $hot,
            'modellist'   => $modellist,
        ]);
        if (!empty($keyword)) {
            return $this->fetch('/xunsearch_result');
        } else {
            return $this->fetch('/search');
        }
    }
}
