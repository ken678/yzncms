<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | cms管理
// +----------------------------------------------------------------------
namespace addons\cms\controller;

use addons\cms\model\Tags as TagsModel;

class Tags extends Cmsbase
{
    // tags
    public function index()
    {
        $page  = $page  = $this->request->param('page/d', 1);
        $tag   = $this->request->param('tag', '');
        $where = [];
        if ($tag && is_numeric($tag)) {
            $where['id'] = $tag;
        } else {
            $where['tag'] = $tag;
        }
        //如果条件为空，则显示标签首页
        if (empty($tag)) {
            $data = TagsModel::order(['listorder' => 'DESC', 'hits' => 'DESC'])->limit(200)->select()->toArray();
            $this->assign("SEO", seo('', '标签'));
            $this->assign('list', $data);
            return $this->fetch('/tags_list');
        }
        //根据条件获取tag信息
        $row = TagsModel::where($where)->find();
        if (empty($row)) {
            $this->error('抱歉，沒有找到您需要的内容！');
        }
        //访问数+1
        $row->setInc("hits");

        $this->assign($row->toArray());
        $this->assign("SEO", seo('', $row['tag'], $row['seo_description'], $row['seo_keyword']));
        $this->assign("page", $page);
        return $this->fetch('/tags');
    }
}
