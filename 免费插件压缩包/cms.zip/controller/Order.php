<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 订单管理
// +----------------------------------------------------------------------
namespace addons\cms\controller;

use addons\cms\model\Order as OrderModel;
use think\Exception;

class Order extends Cmsbase
{
    //创建订单并发起支付请求
    public function submit()
    {
        if (!$this->auth->isLogin()) {
            $this->error('请先登录！', url('index/user/login'));
        }
        $catid    = $this->request->param('catid/d');
        $id       = $this->request->param('id/d');
        $pay_type = $this->request->param('pay_type');
        try {
            $res = OrderModel::submitOrder($catid, $id, $pay_type ? $pay_type : 'wechat');
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
        if ($res) {
            $this->success('支付成功');
        }
    }

    //企业支付通知和回调
    public function epay()
    {
        $type     = $this->request->param('type');
        $pay_type = $this->request->param('pay_type');
        if ($type == 'notify') {
            $pay = \addons\pay\library\Service::checkNotify($pay_type);
            if (!$pay) {
                echo '签名错误';
                return;
            }
            try {
                $data = $pay->callback();
                if ($pay_type === 'wechat') {
                    $data              = $data['resource']['ciphertext'];
                    $data['total_fee'] = $data['amount']['total'];
                }
                $payamount = $pay_type == 'alipay' ? $data['total_amount'] : $data['total_fee'] / 100;
                OrderModel::settle($data['out_trade_no'], $payamount);
            } catch (Exception $e) {
                //写入日志
                // $e->getMessage();
            }
            return $pay->success();
        } else {
            $pay = \addons\pay\library\Service::checkReturn($pay_type);
            if (!$pay) {
                $this->error('签名错误');
            }
            if ($pay === true) {
                //微信支付
                $data = ['out_trade_no' => $this->request->param('trade_sn')];
            } else {
                $data = $pay->callback();
            }
            $order = OrderModel::getByTradeSn($data['out_trade_no']);
            if (!$order) {
                $this->error('订单不存在!');
            }
            //你可以在这里定义你的提示信息,但切记不可在此编写逻辑
            $this->success("恭喜你！支付成功!", buildContentUrl($order['catid'], $order['content_id'], '', true, true));
        }
        return;
    }
}
