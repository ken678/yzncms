<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | cms管理
// +----------------------------------------------------------------------
namespace addons\cms\controller;

use addons\cms\library\Service;
use addons\cms\model\Cms as CmsModel;
use addons\cms\model\Page as PageModel;
use think\facade\Db;

class Index extends Cmsbase
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = [];
    protected $cms_model   = null;

    protected function initialize()
    {
        parent::initialize();
        $this->cms_model = new CmsModel;
    }

    // 首页
    public function index()
    {
        $page = $this->request->param('page/d', 1);
        $seo  = seo();
        $this->assign([
            'SEO'  => $seo,
            'page' => $page,
        ]);
        return $this->fetch('/index');
    }

    // 列表页
    public function lists()
    {
        $cat = $this->request->param('catid/d', 0);
        if (empty($cat)) {
            $cat = $this->request->param('catdir/s', '');
        }
        $page = $this->request->param('page/d', 1);

        //获取栏目数据
        $category = getCategory($cat);
        if (empty($category)) {
            throw new \think\exception\HttpException(404, '栏目不存在！');
        }
        $catid = $category['id'];

        //栏目扩展配置信息
        $setting = $category['setting'];
        //类型为列表的栏目
        if ($category['type'] == 2) {
            //栏目首页模板
            $template = $setting['category_template'] ?? 'category';
            //栏目列表页模板
            $template_list = $setting['list_template'] ?? 'list';
            //判断使用模板类型，如果有子栏目使用频道页模板
            $template = $category['child'] ? $template : $template_list;
            $seo      = seo($catid, '', $setting['meta_description'], $setting['meta_keywords']);
            //单页
        } elseif ($category['type'] == 1) {
            $template                 = $setting['page_template'] ?? 'page';
            [$cacheKey, $cacheExpire] = Service::getCacheConfig('page-' . $catid);

            $info = PageModel::where('catid', $catid)->cache($cacheKey, $cacheExpire, 'cms')->find();
            if (empty($info)) {
                throw new \think\exception\HttpException(404, '单页不存在！');
            }
            $info->setInc('hits');
            $info = $info->toArray();
            //SEO
            $keywords    = $info['keywords'] ?? $setting['meta_keywords'];
            $description = $info['description'] ?? $setting['meta_description'];
            $seo         = seo($catid, '', $description, $keywords);
            $this->assign($info);
        }
        $template = pathinfo($template, PATHINFO_FILENAME);
        if ($this->request->isAjax()) {
            $this->success('', '', $this->fetch('/' . $template . '_ajax'));
        }
        //获取顶级栏目ID
        $top_parentid = $category['arrparentid'][0] ?? $catid;
        unset($category['id']);
        $this->assign([
            'category'     => $category,
            'top_parentid' => $top_parentid,
            'SEO'          => $seo,
            'catid'        => $catid,
            'page'         => $page,
            'modelid'      => $category['modelid'],
        ]);
        return $this->fetch('/' . $template);

    }

    // 内容页
    public function shows()
    {
        //ID
        $id  = $this->request->param('id/d', 0);
        $cat = $this->request->param('catid/d', 0);
        if (empty($cat)) {
            $cat = $this->request->param('catdir/s', '');
        }
        $page = $this->request->param('page/d', 1);
        $page = max(1, $page);
        //获取栏目数据
        $category = getCategory($cat);
        if (empty($category)) {
            throw new \think\exception\HttpException(404, '栏目不存在！');
        }
        $catid = $category['catid'] = $category['id'];
        unset($category['id']);
        //模型ID
        $modelid   = $category['modelid'];
        $modelInfo = cms_cache('Model')[$modelid] ?? '';
        if (empty($modelInfo)) {
            throw new \think\exception\HttpException(404, '模型不存在！');
        }
        //更新点击量
        Db::name($modelInfo['tablename'])->where('id', $id)->setInc('hits');
        //内容所有字段
        [$cacheKey, $cacheExpire] = Service::getCacheConfig('show-' . $catid . '-' . $id);
        $info                     = $this->cms_model->getContent($modelid, ['catid' => $catid, 'id' => $id], true, '*', '', $cacheKey, $cacheExpire);

        if (!$info) {
            throw new \think\exception\HttpException(404, '内容不存在!');
        }
        //未审核的文章只允许管理员或者作者查看
        if ($info['status'] !== 1 && !\app\admin\library\Auth::instance()->isLogin() && $info['user_id'] !== $this->auth->id) {
            throw new \think\exception\HttpException(403, '内容未审核或没有权限!');
        }

        //内容分页
        $paginator = isset($info['content']) ? strpos($info['content'], '[page]') : false;
        if ($paginator !== false) {
            $contents = array_filter(explode('[page]', $info['content']));
            $total    = count($contents);
            $pages    = \addons\cms\paginator\Page::make([], 1, $page, $total, false, ['path' => $this->request->baseUrl()]);
            //判断[page]出现的位置是否在第一位
            if ($paginator < 7) {
                $info['content'] = $contents[$page];
            } else {
                $info['content'] = $contents[$page - 1];
            }
            $this->assign("pages", $pages);
        } else {
            $this->assign("pages", '');
        }
        //栏目扩展配置信息
        $setting = $category['setting'];
        //内容页模板
        $template = isset($setting['show_template']) ? pathinfo($setting['show_template'], PATHINFO_FILENAME) : 'show';

        //阅读收费
        $info['readpoint']   = $info['readpoint'] ?? 0; //金额
        $info['paytype']     = $info['paytype'] ?? 1; //1钱 2积分
        $is_pay              = 1;
        $is_part_content_pay = 0; //是否部分内容付费

        if (isset($info['content'])) {
            $info['content'] = str_replace(['###paidstart###', '###paidend###'], ['<paid>', '</paid>'], $info['content']);
        }
        if ($info['readpoint'] > 0) {
            //检查是否支付过
            $is_pay = \addons\cms\model\Order::check_payment($info);
            if (!$is_pay) {
                //部分内容阅读付费
                if (isset($info['content'])) {
                    $pattern = '/<paid>(.*?)<\/paid>/is';
                    if (preg_match($pattern, $info['content'])) {
                        //$payurl              = url('cms/index/readpoint', ['allow_visitor' => $allow_visitor]);
                        $info['content']     = preg_replace($pattern, "<div class='allow_visitor'>此处内容需要付费后方可阅读</div>", $info['content']);
                        $is_part_content_pay = 1;
                    }
                }
            } else {
                $is_pay = 1;
            }
        }
        //SEO
        $title       = $info['title'] ?: $setting['meta_title'];
        $keywords    = $info['keywords'] ?: $setting['meta_keywords'];
        $description = $info['description'] ?: $setting['meta_description'];
        $seo         = seo($catid, $title, $description, $keywords);

        $top_parentid = $category['arrparentid'][0] ?? $catid;
        $this->assign($info);
        $this->assign([
            'category'            => $category,
            'is_part_content_pay' => $is_part_content_pay,
            'is_pay'              => $is_pay,
            'top_parentid'        => $top_parentid,
            'SEO'                 => $seo,
            'catid'               => $catid,
            'page'                => $page,
            'modelid'             => $modelid,
        ]);
        return $this->fetch('/' . $template);
    }
}
