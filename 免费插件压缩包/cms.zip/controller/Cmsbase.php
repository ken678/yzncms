<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 前台控制模块
// +----------------------------------------------------------------------
namespace addons\cms\controller;

use think\facade\Config;

class Cmsbase extends \think\addons\Controller

{
    //CMS模型相关配置
    protected $cmsConfig = [];

    //初始化
    protected function initialize()
    {
        parent::initialize();
        $this->cmsConfig = get_addon_config("cms");

        if (!$this->cmsConfig['web_site_status']) {
            $this->error("站点已经关闭，请稍后访问~");
        }
        $this->assign("cms_config", $this->cmsConfig);

        $Theme = Config::get('site.theme') ?: 'default';
        Config::set(['view_path' => TEMPLATE_PATH . $Theme . '/cms' . DS], 'view');
        //分页驱动
        $this->app->bind('think\Paginator', 'addons\cms\paginator\Page');
    }

}
