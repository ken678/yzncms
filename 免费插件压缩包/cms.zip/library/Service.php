<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | cms处理类
// +----------------------------------------------------------------------
namespace addons\cms\library;

use addons\cms\model\ModelField;
use think\facade\Db;
use think\facade\Validate;

class Service
{
    private static $ext_table = '_data';

    //查询解析模型数据用以构造from表单
    public static function getFieldList($modelId, $id = null)
    {
        $list = ModelField::where('modelid', $modelId)->where('status', 1)->order('listorder DESC,id DESC')->select();
        if (!empty($list)) {
            //编辑信息时查询出已有信息
            if ($id) {
                $modelInfo = Db::name('Model')->where('id', $modelId)->field('tablename,type')->find();
                $dataInfo  = Db::name($modelInfo['tablename'])->where('id', $id)->find();
                //查询附表信息
                if ($modelInfo['type'] == 2 && !empty($dataInfo)) {
                    $dataInfoExt = Db::name($modelInfo['tablename'] . self::$ext_table)->where('did', $dataInfo['id'])->find();
                }
            }
            foreach ($list as $key => &$value) {
                //内部字段不显示
                if ($value['iscore']) {
                    unset($list[$key]);
                }
                //核心字段做标记
                if ($value['ifsystem']) {
                    $value['fieldArr'] = 'modelField';
                    if (isset($dataInfo[$value['name']])) {
                        $value['value'] = $dataInfo[$value['name']];
                    }
                } else {
                    $value['fieldArr'] = 'modelFieldExt';
                    if (isset($dataInfoExt[$value['name']])) {
                        $value['value'] = $dataInfoExt[$value['name']];
                    }
                }

                //扩展配置
                $value['options'] = $value['setting']['options'] ?? '';
                //在新增时候添加默认值
                if (!$id) {
                    $value['value'] = $value['setting']['value'] ?? '';
                }
                if ($value['type'] == 'custom') {
                    if ($value['options'] != '') {
                        $tpar             = explode(".", $value['options'], 2);
                        $value['options'] = \think\Response::create('admin@custom/' . $tpar[0], 'view')->assign('vo', $value)->getContent();
                        unset($tpar);
                    }
                } elseif ($value['options'] != '') {
                    $value['options'] = parse_attr($value['options']);
                }
                /*if ('' != $value['options']) {
                $value['options'] = parse_attr($value['options']);
                }*/
                if ($value['type'] == 'checkbox') {
                    $value['value'] = empty($value['value']) ? [] : explode(',', $value['value']);
                }
                if ($value['type'] == 'datetime') {
                    $value['value'] = empty($value['value']) ? date('Y-m-d H:i:s') : date('Y-m-d H:i:s', $value['value']);
                }
                if ($value['type'] == 'date') {
                    $value['value'] = empty($value['value']) ? '' : date('Y-m-d', $value['value']);
                }
                if ($value['type'] == 'editor' || $value['type'] == 'markdown') {
                    $value['value'] = isset($value['value']) ? htmlspecialchars_decode($value['value']) : '';
                }
            }
        }
        return $list;
    }

    //处理post提交的模型数据
    public static function dealModelPostData($modeId, $data, $dataExt = [], $ignoreField = [])
    {
        //字段类型
        $query = ModelField::where('modelid', $modeId)->where('status', 1);
        if ([] != $ignoreField) {
            $query = $query->where('name', 'not in', $ignoreField);
        }
        $filedTypeList = $query->order('listorder DESC, id DESC')->column('title,type,ifsystem,ifrequire,pattern,errortips', 'name');

        foreach ($filedTypeList as $name => $vo) {
            $arr = $vo['ifsystem'] ? 'data' : 'dataExt';
            if (!isset(${$arr}[$name])) {
                switch ($vo['type']) {
                    // 开关
                    case 'switch':
                        ${$arr}[$name] = 0;
                        break;
                    case 'checkbox':
                        ${$arr}[$name] = '';
                        break;
                    case 'radio':
                        ${$arr}[$name] = '';
                        break;
                }
            } else {
                if (is_array(${$arr}[$name])) {
                    ${$arr}[$name] = implode(',', ${$arr}[$name]);
                }
                switch ($vo['type']) {
                    // 开关
                    case 'switch':
                        ${$arr}[$name] = 1;
                        break;
                    // 日期+时间
                    case 'datetime':
                        //if ($vo['ifeditable']) {
                        ${$arr}[$name] = strtotime(${$arr}[$name]);
                        //}
                        break;
                    // 日期
                    case 'date':
                        ${$arr}[$name] = strtotime(${$arr}[$name]);
                        break;
                    // 编辑器
                    case 'markdown':
                    case 'editor':
                        ${$arr}[$name] = htmlspecialchars(stripslashes(${$arr}[$name]));
                        break;
                }
            }
            //数据必填验证
            if ($vo['ifrequire'] && (!isset(${$arr}[$name]) || ${$arr}[$name] == '')) {
                throw new \Exception("'" . $vo['title'] . "'必须填写~");
            }
            //正则校验
            if (isset(${$arr}[$name]) && ${$arr}[$name] && $vo['pattern'] && !Validate::regex(${$arr}[$name], $vo['pattern'])) {
                throw new \Exception("'" . $vo['title'] . "'" . (!empty($vo['errortips']) ? $vo['errortips'] : '正则校验失败') . "");
            }
            //数据格式验证
            if (!empty(${$arr}[$name]) && in_array($vo['type'], ['number']) && !Validate::isNumber(${$arr}[$name])) {
                throw new \Exception("'" . $vo['title'] . "'格式错误~");
                //安全过滤
            } else {

            }
        }
        return [$data, $dataExt];
    }

    /**
     * 数据处理 前端显示
     * @param  $fieldinfo
     * @param  $data
     */
    public static function dealModelShowData($fieldinfo, $data)
    {
        $newdata = [];
        foreach ($data as $key => $value) {
            if (isset($fieldinfo[$key])) {
                switch ($fieldinfo[$key]['type']) {
                    case 'array':
                        $newdata[$key] = (array) json_decode($value, true);
                        break;
                    case 'radio':
                    case 'select':
                        if (!empty($value)) {
                            if (!empty($fieldinfo[$key]['options'])) {
                                $optionArr               = parse_attr($fieldinfo[$key]['options']);
                                $newdata[$key . '_text'] = isset($optionArr[$value]) ? $optionArr[$value] : $value;
                            }
                        }
                        $newdata[$key] = $value;
                        break;
                    case 'selects':
                    case 'checkbox':
                        if (!empty($value)) {
                            if (!empty($fieldinfo[$key]['options'])) {
                                $optionArr = parse_attr($fieldinfo[$key]['options']);
                                $valueArr  = explode(',', $value);
                                foreach ($valueArr as $v) {
                                    if (isset($optionArr[$v])) {
                                        $newdata[$key][$v] = $optionArr[$v];
                                    } elseif ($v) {
                                        $newdata[$key][$v] = $v;
                                    }
                                }
                                //其他表关联
                            } else {
                                $newdata[$key] = [];
                            }
                        }
                        break;
                    case 'files':
                    case 'images':
                        $newdata[$key] = empty($value) ? [] : explode(',', $value);
                        break;
                    /*case 'tags':
                    $newdata[$key] = empty($value) ? [] : explode(',', $value);
                    break;*/
                    case 'markdown':
                        $parser        = new \util\Parser;
                        $newdata[$key] = $parser->makeHtml(htmlspecialchars_decode($value));
                        break;
                    case 'editor':
                        $newdata[$key] = htmlspecialchars_decode($value);
                        break;
                    default:
                        $newdata[$key] = $value;
                        break;
                }
            }
            if (!isset($newdata[$key])) {
                $newdata[$key] = '';
            }
        }
        return $newdata;
    }

    /**
     * 文本处理
     */
    public static function getAfterText(&$data, &$dataExt)
    {
        //自动提取摘要，如果有设置自动提取，且description为空，且有内容字段才执行
        if (isset($data['get_introduce']) && $data['description'] == '' && (isset($dataExt['content']) || isset($data['content']))) {
            $content             = isset($dataExt['content']) ? $dataExt['content'] : (isset($data['content']) ? $data['content'] : '');
            $data['description'] = mb_substr(str_replace(["\r\n", "\t", '&ldquo;', '&rdquo;', '&nbsp;'], '', strip_tags($content)), 0, 200);
        }
        //自动提取缩略图
        if (isset($data['auto_thumb']) && empty($data['thumb']) && (isset($dataExt['content']) || isset($data['content']))) {
            $thumb         = isset($dataExt['content'])?\util\GetImgSrc::src($dataExt['content']) : (isset($data['content'])?\util\GetImgSrc::src($data['content']) : false);
            $data['thumb'] = $thumb ? $thumb : '';
        }
        //关键词加链接
        $autolinks = get_addon_config('cms')['autolinks'];
        if (!empty($autolinks) && isset($dataExt['content'])) {
            if (strpos($autolinks, '|')) {
                //解析关键词数组
                $kwsets = array_filter(preg_split("/(\r|\n|\r\n)/", $autolinks));
                foreach ($kwsets as $kwset) {
                    $kwarray[] = explode('|', $kwset);
                }
            }
            foreach ($kwarray as $i => $row) {
                $txt  = isset($row[0]) ? trim($row[0]) : '';
                $link = isset($row[1]) ? trim($row[1]) : '';
                $set  = isset($row[2]) ? trim($row[2]) : '';
                if ($txt && $link) {
                    $rel  = '';
                    $open = '_blank';

                    //处理标记与打开方式
                    if ($set) {
                        if (false !== stripos($set, 'e')) {
                            $rel = ' rel="external nofollow"';
                        } elseif (false !== stripos($set, 'n')) {
                            $rel = ' rel="nofollow"';
                        }
                        $open = false !== stripos($set, 'b') ? '_self' : $open;
                    }

                    $dataExt['content'] = false !== strpos($dataExt['content'], $txt)
                    //正则排除参数和链接
                    ? preg_replace('/(?!<[^>]*)' . $txt . '(?![^<]*(>|<\/[a|sc]))/s'
                        , '<a href="' . $link . '"' . $rel . 'target="' . $open . '" title="' . $txt . '">' . $txt . '</a>', $dataExt['content']) : $dataExt['content'];
                }
            }
        }
        unset($data['get_introduce']);
        unset($data['auto_thumb']);
    }

    /**
     * 获取缓存标签和时长
     */
    public static function getCacheConfig(string $type): array
    {

        $config = get_addon_config('cms');

        if ($config['site_cache_time'] === true || $config['site_cache_time'] === 'true') {
            $cacheDuration = 0;
        } elseif ($config['site_cache_time'] === false || $config['site_cache_time'] === 'false') {
            $cacheDuration = -1;
        } else {
            $cacheDuration = (int) $config['site_cache_time'];
        }

        $cacheKey    = $cacheDuration !== -1 ? "cms-{$type}" : false;
        $cacheExpire = $cacheDuration !== -1 ? $cacheDuration : null;

        return [$cacheKey, $cacheExpire];

    }
}
