<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 订单管理
// +----------------------------------------------------------------------
namespace app\index\controller\cms;

use addons\cms\model\Order as OrderModel;
use app\common\controller\Frontend;

class Order extends Frontend
{

    protected $noNeedRight = [];

    //订单列表
    public function index()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 1);

            $_list  = OrderModel::where('user_id', $this->auth->id)->page($page, $limit)->order('id DESC')->select();
            $total  = OrderModel::where('user_id', $this->auth->id)->count();
            $result = ["code" => 0, "count" => $total, "data" => $_list];
            return json($result);
        } else {
            $this->assign('title', '订单记录');
            return $this->fetch('order_list');
        }

    }
}
