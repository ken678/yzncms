<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 会员投稿管理
// +----------------------------------------------------------------------
namespace app\index\controller\cms;

use addons\cms\library\Service;
use addons\cms\model\Category as CategoryModel;
use addons\cms\model\CategoryPriv;
use addons\cms\model\CmsContent as CmsContentModel;
use app\admin\model\cms\Cms as CmsModel;
use app\common\controller\Frontend;
use think\exception\ValidateException;
use think\facade\Db;

class Content extends Frontend
{
    protected $CmsModel = null;

    public function initialize()
    {
        parent::initialize();
        $this->CmsModel = new CmsModel;
    }

    public function publish()
    {
        $config    = get_addon_config("cms");
        $groupinfo = $this->check_group_auth($this->auth->group_id);
        //没有认证用户不得投稿
        if ($config['web_contribute_verify'] && (!$this->auth->ischeck_email && !$this->auth->ischeck_mobile)) {
            $this->error("投稿必须激活邮箱或手机！");
        }
        //判断每日投稿数
        $allowpostnum = CmsContentModel::where('user_id', $this->auth->id)->whereTime('create_time', 'd')->count();
        if ($groupinfo['allowpostnum'] > 0 && $allowpostnum >= $groupinfo['allowpostnum']) {
            $this->error("今日投稿数量已达上限！");
        }
        if ($this->request->isPost()) {
            $param = $this->request->param('', '', 'trim,xss_clean');
            // 验证数据
            $rule = [
                'modelField.title|标题' => 'require|length:3,100',
                'modelField.catid|栏目' => 'require|integer',
                '__token__'           => 'require|token',
            ];
            try {
                $this->validate($param, $rule);
            } catch (ValidateException $e) {
                // 验证失败 输出错误信息
                $this->error($e->getError(), null, ['token' => $this->request->buildToken()]);
            }

            $catid = intval($param['modelField']['catid']);
            if (empty($catid)) {
                $this->error("请指定栏目ID！", null, ['token' => $this->request->buildToken()]);
            }
            $catidPrv = CategoryPriv::where(["catid" => $catid, "roleid" => $this->auth->group_id, "is_admin" => 0, "action" => "add"])->find();
            if (empty($catidPrv)) {
                $this->error("您没有该栏目投稿权限！", null, ['token' => $this->request->buildToken()]);
            }
            $category = CategoryModel::find($catid);
            if (empty($category)) {
                $this->error('该栏目不存在！', null, ['token' => $this->request->buildToken()]);
            }
            $fields = Db::name('model_field')->where('modelid', $category['modelid'])->where('isadd', 1)->column('ifsystem', 'name');
            $data   = [];
            foreach ($fields as $k => $v) {
                if (1 == $v && isset($param['modelField'][$k])) {
                    $data['modelField'][$k] = $param['modelField'][$k];
                } elseif (0 == $v && isset($param['modelFieldExt'][$k])) {
                    $data['modelFieldExt'][$k] = $param['modelFieldExt'][$k];
                }
            }
            $data['modelField']['user_id'] = $this->auth->id;
            $data['modelField']['sysadd']  = 0;

            //判断会员组投稿是否需要审核
            if ($groupinfo['allowpostverify']) {
                $data['modelField']['status'] = 1;
            } else {
                $data['modelField']['status'] = 0;
            }
            $id = 0;

            if ($category['type'] == 2) {
                $data['modelFieldExt'] = isset($data['modelFieldExt']) ? $data['modelFieldExt'] : [];
                try {
                    $id = $this->CmsModel->addModelData($data['modelField'], $data['modelFieldExt']);
                } catch (\Exception $ex) {
                    $this->error($ex->getMessage(), null, ['token' => $this->request->buildToken()]);
                }
            }
            //添加投稿记录
            if ($id) {
                CmsContentModel::create([
                    'catid'      => $catid,
                    'content_id' => $id,
                    'user_id'    => $this->auth->id,
                    'username'   => $this->auth->username,
                    'status'     => $data['modelField']['status'],
                ]);
            }
            if ($data['modelField']['status'] == 1) {
                $this->success('操作成功，内容已通过审核！', url('published'));
            } else {
                $this->success('操作成功，等待管理员审核！', url('published'));
            }
        } else {
            $step = $this->request->param('step/d', 1);
            if ($step == 1) {
                return $this->fetch('content_declaration');
            }
            $catid = $this->request->param('catid/d', 0);
            $tree  = new \util\Tree();
            $str   = "<option value=@catidurl @selected @disabled>@spacer @catname</option>";
            $array = CategoryModel::order('listorder DESC, id DESC')->column('*', 'id');
            foreach ($array as $k => $v) {
                if ($v['id'] == $catid) {
                    $array[$k]['selected'] = "selected";
                }
                //含子栏目和单页不可以发表
                if ($v['child'] == 1 || $v['type'] == 1) {
                    $array[$k]['disabled'] = "disabled";
                    $array[$k]['catidurl'] = url('publish', ['step' => 2]);
                } else {
                    $array[$k]['disabled'] = "";
                    $array[$k]['catidurl'] = url('publish', ['step' => 2, 'catid' => $v['id']]);
                }
            }
            $tree->init($array);
            $categoryselect = $tree->getTree(0, $str);
            //如果有选择栏目的情况下
            if ($catid) {
                $category = CategoryModel::find($catid);
                if (empty($category)) {
                    $this->error('该栏目不存在！');
                }
                if ($category['type'] == 2) {
                    $modelid   = $category['modelid'];
                    $fieldList = Service::getFieldList($modelid);
                    $this->assign([
                        'catid'     => $catid,
                        'fieldList' => $fieldList,
                    ]);
                }
            }
            $this->assign('title', '在线投稿');
            $this->assign("categoryselect", $categoryselect);
            return $this->fetch('content_publish');
        }
    }

    /**
     * 编辑内容
     */
    public function edit()
    {
        $groupinfo = $this->check_group_auth($this->auth->group_id);
        if ($this->request->isPost()) {
            $param = $this->request->param('', '', 'trim,xss_clean');
            // 验证数据
            $rule = [
                'modelField.title|标题' => 'require|length:3,100',
                'modelField.catid|栏目' => 'require|integer',
                '__token__'           => 'require|token',
            ];

            try {
                $this->validate($param, $rule);
            } catch (ValidateException $e) {
                // 验证失败 输出错误信息
                $this->error($e->getError(), null, ['token' => $this->request->buildToken()]);
            }

            $id    = intval($param['modelField']['id']);
            $catid = intval($param['modelField']['catid']);
            if (empty($id) || empty($catid)) {
                $this->error("请指定栏目ID！");
            }
            $category = Db::name('Category')->find($catid);
            if (empty($category)) {
                $this->error('该栏目不存在！');
            }
            $catidPrv = Db::name('category_priv')->where(["catid" => $catid, "roleid" => $this->auth->group_id, "is_admin" => 0, "action" => "add"])->find();
            if (empty($catidPrv)) {
                $this->error("您没有该栏目投稿权限！");
            }
            $fields = Db::name('model_field')->where('modelid', $category['modelid'])->where('isadd', 1)->column('name,ifsystem');
            $data   = [];
            foreach ($fields as $k => $v) {
                if (1 == $v && isset($param['modelField'][$k])) {
                    $data['modelField'][$k] = $param['modelField'][$k];
                } elseif (0 == $v && isset($param['modelFieldExt'][$k])) {
                    $data['modelFieldExt'][$k] = $param['modelFieldExt'][$k];
                }
            }
            //判断会员组投稿是否需要审核
            if ($groupinfo['allowpostverify']) {
                $data['modelField']['status'] = 1;
            } else {
                $data['modelField']['status'] = 0;
            }

            if ($category['type'] == 2) {
                $data['modelFieldExt'] = isset($data['modelFieldExt']) ? $data['modelFieldExt'] : [];
                try {
                    $this->CmsModel->editModelData($data['modelField'], $data['modelFieldExt']);
                } catch (\Exception $ex) {
                    $this->error($ex->getMessage());
                }
            }
            if ($data['modelField']['status'] == 1) {
                CmsContentModel::where(['content_id' => $id, 'catid' => $catid])->update(['status' => 1]);
                $this->success('编辑成功，内容已通过审核！', url('published'));
            } else {
                CmsContentModel::where(['content_id' => $id, 'catid' => $catid])->update(['status' => 0]);
                $this->success('编辑成功，等待管理员审核！', url('published'));
            }
        } else {
            $id   = $this->request->param('id/d', 0);
            $info = CmsContentModel::where(['user_id' => $this->auth->id, 'id' => $id])->find();
            if (empty($info)) {
                $this->error('稿件不存在！');
            }
            $catid = $info['catid'];
            //取得栏目数据
            $category = getCategory($catid);
            if (empty($category)) {
                $this->error('该栏目不存在！', url('publish', ['step' => 2]));
            }
            //模型ID
            $modelid = (int) $category['modelid'];
            //判断是否终极栏目
            if ($category['child'] || $category['type'] == 0) {
                $this->error("该栏目不允许投稿！", url('publish', ['step' => 2]));
            }
            $fieldList = Service::getFieldList($modelid, $info['content_id']);
            $this->assign([
                'catid'     => $catid,
                'fieldList' => $fieldList,
            ]);
            return $this->fetch('content_edit');
        }

    }

    public function published()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 10);
            $type  = $this->request->param('type/s', "");
            $where = ['user_id' => $this->auth->id];
            if ('check' == $type) {
                $where['status'] = 1;
            }
            if ('checking' == $type) {
                $where['status'] = 0;
            }
            $total = CmsContentModel::where($where)->count();
            $list  = CmsContentModel::where($where)->page($page, $limit)->order("id DESC")->select();
            foreach ($list as $k => $v) {
                $modelid = getCategory($v['catid'], 'modelid');
                $info    = Db::name(getModel($modelid, 'tablename'))->where(["id" => $v['content_id'], "sysadd" => 0])->find();
                if ($info) {
                    $list[$k]['url']     = buildContentUrl($v['catid'], $v['content_id'], $info['url']);
                    $list[$k]['title']   = $info['title'];
                    $list[$k]['catname'] = getCategory($v['catid'], 'catname');
                }
            }
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        $this->assign('title', '我的投稿');
        return $this->fetch('content_published');
    }

    //删除
    public function del()
    {
        $ids = $this->request->param('id/a', null);
        if (empty($ids)) {
            $this->error('请指定需要删除的信息！');
        }
        if (!is_array($ids)) {
            $ids = [0 => $ids];
        }
        foreach ($ids as $id) {
            //信息
            $row = CmsContentModel::where('id', $id)->find();
            //只能删除自己的 且 未通过审核的
            if ($row && $row['user_id'] == $this->auth->id && $row['status'] != 1) {
                try {
                    $this->CmsModel->deleteModelData($row['catid'], $row['content_id']);
                    $row->delete();
                } catch (\Exception $e) {
                    $this->error($e->getMessage());
                }

            } else {
                $this->error('对不起，你无权删除！');
            }
        }
        $this->success('删除成功！');
    }

    //检查会员组权限
    private function check_group_auth($group_id)
    {
        $grouplist = Db::name('user_group')->column('*', 'id'); //会员模型
        if (!$grouplist[$group_id]['allowpost']) {
            $this->error('你没有权限投稿，请升级会员组！');
        }
        return $grouplist[$group_id];
    }

}
