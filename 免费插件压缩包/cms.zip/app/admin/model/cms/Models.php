<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 模型模型
// +----------------------------------------------------------------------
namespace app\admin\model\cms;

use think\Exception;
use think\facade\Cache;
use think\facade\Config;
use think\facade\Db;
use think\Model;

/**
 * 模型
 */
class Models extends Model
{

    protected $name               = 'model';
    protected $autoWriteTimestamp = true;

    protected static $ext_table = '_data';

    public function getSettingAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['setting'], true);
    }

    public function setSettingAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }

    public static function onBeforeInsert($row)
    {
        $row['module'] = 'cms';
        $info          = null;
        try {
            $info = Db::name($row['tablename'])->getPk();
        } catch (\Exception $e) {
        }
        if ($info) {
            throw new Exception("数据表已经存在");
        }
    }

    public static function onAfterInsert($row)
    {
        cache::set("Model", null);
        cache::set('ModelField', null);
        //创建模型表和模型字段
        if (self::createTable($row)) {
            self::addFieldRecord($row['id'], $row['type']);
        }
    }

    public static function onBeforeUpdate($row)
    {
        //编辑
        $changedData = $row->getChangedData();
        if (isset($changedData['category_template'])) {
            $row['setting']['category_template'] = $row->category_template;
        }
        if (isset($changedData['list_template'])) {
            $row['setting']['list_template'] = $row->list_template;
        }
        if (isset($changedData['show_template'])) {
            $row['setting']['show_template'] = $row->show_template;
        }
        if (isset($changedData['tablename'])) {
            $info = null;
            try {
                $info = Db::name($row['tablename'])->getPk();
            } catch (\Exception $e) {
            }
            if ($info) {
                throw new Exception("数据表已经存在");
            }
            try {
                $info = Db::name($row['tablename'] . self::$ext_table)->getPk();
            } catch (\Exception $e) {
            }
            if ($info) {
                throw new Exception("数据表已经存在");
            }
        }
    }

    public static function onAfterUpdate($row)
    {
        //更新缓存
        cache::set("Model", null);
        cache::set('ModelField', null);
        Cache::set('getModel_' . $row['id'], '');
        $changedData = $row->getChangedData();
        if (isset($changedData['tablename'])) {
            //表前缀
            $dbPrefix = Config::get("database.connections.mysql.prefix");
            //表名更改
            Db::execute("RENAME TABLE  `{$dbPrefix}{$row->getOrigin('tablename')}` TO  `{$dbPrefix}{$changedData['tablename']}` ;");
            //修改副表
            if ($row['type'] == 2) {
                Db::execute("RENAME TABLE  `{$dbPrefix}{$row->getOrigin('tablename')}_data` TO  `{$dbPrefix}{$changedData['tablename']}_data` ;");
            }
        }
    }

    public static function onBeforeDelete($row)
    {
        //删除
        $exist = Category::where('modelid', $row['id'])->find();
        if ($exist) {
            throw new Exception("该模型使用中，删除栏目后再删除！");
        }
    }

    public static function onAfterDelete($row)
    {
        cache::set("Model", null);
        cache::set('ModelField', null);
        //删除所有和这个模型相关的字段
        ModelField::where("modelid", $row['id'])->delete();
        //删除主表
        $table_name = Config::get("database.connections.mysql.prefix") . $row['tablename'];
        Db::execute("DROP TABLE IF EXISTS `{$table_name}`");
        if ((int) $row['type'] == 2) {
            //删除副表
            $table_name .= self::$ext_table;
            Db::execute("DROP TABLE IF EXISTS `{$table_name}`");
        }
    }

    /**
     * 创建内容模型
     */
    public static function createTable($data)
    {
        $data['tablename'] = strtolower($data['tablename']);
        $table             = Config::get("database.connections.mysql.prefix") . $data['tablename'];
        $sql               = <<<EOF
                CREATE TABLE `{$table}` (
                `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
                `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
                `title` varchar(255) DEFAULT '' COMMENT '标题',
                `thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
                `flag` varchar(32) DEFAULT '' COMMENT '属性',
                `keywords` varchar(255) DEFAULT '' COMMENT 'SEO关键词',
                `description` varchar(255) DEFAULT '' COMMENT 'SEO描述',
                `tags` varchar(255) DEFAULT '' COMMENT 'Tags标签',
                `listorder` smallint(5) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
                `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
                `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '管理员id',
                `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否后台添加',
                `hits` mediumint(8) UNSIGNED DEFAULT 0 COMMENT '点击量' ,
                `publish_time` int(10) unsigned DEFAULT NULL COMMENT '发布时间',
                `create_time` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
                `update_time` int(10) unsigned DEFAULT NULL COMMENT '更新时间',
                `url` varchar(100) NOT NULL DEFAULT '' COMMENT '链接地址',
                `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
                PRIMARY KEY (`id`),
                KEY `status` (`catid`,`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='{$data['name']}模型表';
EOF;

        $res = Db::execute($sql);
        if ($data['type'] == 2) {
            $table = $table . self::$ext_table;
            // 新建附属表
            $sql = <<<EOF
                CREATE TABLE `{$table}` (
                `did` mediumint(8) unsigned NOT NULL DEFAULT '0',
                `content` mediumtext COMMENT '内容',
                PRIMARY KEY (`did`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='{$data['name']}模型表';
EOF;
            $res = Db::execute($sql);
        }
        return true;
    }

    /**
     * 添加默认字段
     */
    public static function addFieldRecord($modelid, $type)
    {
        $fieldsArr = [];
        $default   = [
            'modelid'     => $modelid,
            'pattern'     => '',
            'errortips'   => '',
            'create_time' => time(),
            'update_time' => time(),
            'ifsystem'    => 1,
            'status'      => 1,
            'listorder'   => 100,
            'ifsearch'    => 0,
            'iffixed'     => 1,
            'remark'      => '',
            'isadd'       => 0,
            'iscore'      => 0,
            'ifrequire'   => 0,
            'setting'     => '[]',
        ];
        $data = [
            [
                'name'    => 'id',
                'title'   => '文档id',
                'type'    => 'hidden',
                'isadd'   => 1,
                'setting' => '[]',
            ],
            [
                'name'    => 'catid',
                'title'   => '栏目id',
                'type'    => 'hidden',
                'isadd'   => 1,
                'setting' => '[]',
            ],
            [
                'name'    => 'user_id',
                'title'   => '用户id',
                'type'    => 'number',
                'iscore'  => 1,
                'setting' => '[]',
            ],
            [
                'name'    => 'admin_id',
                'title'   => '用户id',
                'type'    => 'number',
                'iscore'  => 1,
                'setting' => '[]',
            ],
            [
                'name'    => 'sysadd',
                'title'   => '是否后台添加',
                'type'    => 'number',
                'iscore'  => 1,
                'setting' => '[]',
            ],
            [
                'name'      => 'title',
                'title'     => '标题',
                'type'      => 'text',
                'ifsearch'  => 1,
                'ifrequire' => 1,
                'setting'   => '{"define":"varchar(255) NOT NULL DEFAULT \'\'"}',
                'isadd'     => 1,
                'listorder' => 300,
            ],
            [
                'name'      => 'flag',
                'title'     => '属性',
                'type'      => 'checkbox',
                'setting'   => '{"define":"varchar(32) NOT NULL DEFAULT \'\'","options":"1:\u7f6e\u9876[1]\r\n2:\u5934\u6761[2]\r\n3:\u7279\u8350[3]\r\n4:\u63a8\u8350[4]\r\n5:\u70ed\u70b9[5]\r\n6:\u5e7b\u706f[6]"}',
                'listorder' => 295,
            ],
            [
                'name'      => 'keywords',
                'title'     => 'SEO关键词',
                'type'      => 'tags',
                'iffixed'   => 0,
                'remark'    => '关键词用回车确认',
                'setting'   => '{"define":"varchar(255) NOT NULL DEFAULT \'\'"}',
                'isadd'     => 1,
                'listorder' => 290,
            ],
            [
                'name'      => 'description',
                'title'     => 'SEO摘要',
                'type'      => 'textarea',
                'iffixed'   => 0,
                'remark'    => '如不填写，则自动截取附表中编辑器的200字符',
                'setting'   => '{"define":"varchar(255) NOT NULL DEFAULT \'\'"}',
                'isadd'     => 1,
                'listorder' => 285,
            ],
            [
                'name'      => 'tags',
                'title'     => 'Tags标签',
                'type'      => 'tags',
                'iffixed'   => 0,
                'remark'    => '关键词用回车确认',
                'setting'   => '{"define":"varchar(255) NOT NULL DEFAULT \'\'"}',
                'listorder' => 280,
            ],
            [
                'name'      => 'thumb',
                'title'     => '缩略图',
                'type'      => 'image',
                'ifrequire' => 0,
                'iffixed'   => 0,
                'setting'   => '{"define":"text NOT NULL"}',
                'isadd'     => 1,
                'listorder' => 275,
            ],
            [
                'name'      => 'hits',
                'title'     => '点击量',
                'type'      => 'number',
                'listorder' => 265,
                'setting'   => '{"define":"mediumint(8) UNSIGNED NOT NULL DEFAULT \'0\'"}',
            ],
            [
                'name'      => 'listorder',
                'title'     => '排序',
                'type'      => 'number',
                'setting'   => '{"define":"tinyint(3) UNSIGNED NOT NULL","value":100}',
                'listorder' => 260,
            ],
            [
                'name'      => 'url',
                'title'     => '链接地址',
                'type'      => 'text',
                'listorder' => 255,
                'setting'   => '{"define":"varchar(100) NOT NULL DEFAULT \'\'"}',
                'remark'    => '有值时生效，内部链接格式:模块/控制器/操作?参数=参数值&...，外部链接则必须http://开头',
            ],
            [
                'name'      => 'publish_time',
                'title'     => '发布时间',
                'type'      => 'datetime',
                'listorder' => 250,
                'setting'   => '{"define":"int(10) UNSIGNED DEFAULT NULL"}',
            ],
            [
                'name'      => 'create_time',
                'title'     => '创建时间',
                'type'      => 'datetime',
                'listorder' => 250,
                'setting'   => '{"define":"int(10) UNSIGNED DEFAULT NULL"}',
                'iscore'    => 1,
            ],
            [
                'name'      => 'update_time',
                'title'     => '更新时间',
                'type'      => 'datetime',
                'listorder' => 245,
                'setting'   => '{"define":"int(10) UNSIGNED DEFAULT NULL"}',
                'iscore'    => 1,
            ],
            [
                'name'      => 'status',
                'title'     => '状态',
                'type'      => 'radio',
                'setting'   => '{"define":"tinyint(1) UNSIGNED NOT NULL DEFAULT \'0\'","options":"0:\u7981\u7528\r\n1:\u542f\u7528","value":1}',
                'listorder' => 240,
            ],
        ];
        if ($type == 2) {
            array_push($data, [
                'name'     => 'did',
                'title'    => '附表文档id',
                'type'     => 'hidden',
                'iscore'   => 1,
                'ifsystem' => 0,
                'setting'  => '[]',
            ],
                [
                    'name'      => 'content',
                    'title'     => '内容',
                    'type'      => 'editor',
                    'ifsystem'  => 0,
                    'iffixed'   => 0,
                    'setting'   => '{"define":"text NOT NULL"}',
                    'isadd'     => 1,
                    'listorder' => 270,
                ]);

        }
        foreach ($data as $item) {
            $fieldsArr[] = array_merge($default, $item);
        }
        Db::name('ModelField')->insertAll($fieldsArr);
        return true;
    }

}
