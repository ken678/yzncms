<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 单页模型
// +----------------------------------------------------------------------
namespace app\admin\model\cms;

use think\Exception;
use think\Model;

class Page extends Model
{
    protected $name               = 'cms_page';
    protected $autoWriteTimestamp = true;

    // 追加属性
    protected $append = [
        'publish_time_text',
    ];

    public function getPublishTimeTextAttr($value, $data)
    {
        $value = $value ? $value : $data['publish_time'];
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setPublishTimeAttr($value)
    {
        return $value && !is_numeric($value) ? strtotime($value) : ($value ? $value : null);
    }

    /**
     * 更新单页内容
     *
     * @param $data
     *
     * @return boolean
     */
    public function savePage($data)
    {
        if (empty($data)) {
            throw new Exception('内容不能为空！');
        }
        $row = Page::where('catid', $data['catid'])->find();
        if ($row) {
            //更新
            $row->data($data)->save();
        } else {
            $data['publish_time'] = time();
            //新增
            Page::create($data);
        }
        return true;
    }

    public function category()
    {
        return $this->belongsTo('Category', 'catid', 'id');
    }

}
