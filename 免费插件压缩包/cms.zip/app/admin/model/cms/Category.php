<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 栏目模型
// +----------------------------------------------------------------------
namespace app\admin\model\cms;

use app\admin\model\cms\CategoryPriv;
use think\Exception;
use think\facade\Cache;
use think\facade\Db;
use think\Model;

/**
 * 模型
 */
class Category extends Model
{
    protected $name = 'cms_category';
    protected static $arrparent;
    protected static $arrchild;

    public function getSettingAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['setting'], true);
    }

    public function setSettingAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }

    public static function onAfterWrite($row)
    {
        $cmsConfig = get_addon_config("cms");
        if (isset($cmsConfig['web_site_weburlpush']) && $cmsConfig['web_site_weburlpush']) {
            hook("weburlpush", buildCatUrl($row->id, '', true, true));
        }
        //勾选会员权限
        if (isset($row['priv_groupid'])) {
            CategoryPriv::update_priv($row->id, $row->priv_groupid, 0);
        }
        cache::set("Category", null);
    }

    public static function onAfterInsert($row)
    {
        if ($row['type'] == 1) {
            //增加默认单页
            (new Page)->savePage([
                'catid' => $row->id,
                'title' => $row->catname,
            ]);
        }
    }

    public static function onBeforeUpdate($row)
    {
        //应用模板到所有子栏目
        if (isset($row['template_child']) && $row['template_child']) {
            $setting['category_template'] = $row['setting']['category_template'] ?? '';
            $setting['list_template']     = $row['setting']['list_template'] ?? '';
            $setting['show_template']     = $row['setting']['show_template'] ?? '';
            $setting['page_template']     = $row['setting']['page_template'] ?? '';
            $idstr                        = self::get_arrchildid($row->id);
            $children                     = Category::where('id', 'in', $idstr)->select();
            foreach ($children as $child) {
                $child->setting = array_merge($child->setting, $setting);
                $child->save();
            }
        }
    }

    public static function onAfterUpdate($row)
    {
        $changedData = $row->getChangedData();
        //其他类型改为单页也要新增单页
        if ($row['type'] == 1 && isset($changedData['type'])) {
            //增加默认单页
            (new Page)->savePage([
                'catid' => $row->id,
                'title' => $row->catname,
            ]);
        }
        getCategory($row->id, '', true);
    }

    public static function onBeforeDelete($row)
    {
        //是否存在子栏目
        if (self::where('parentid', $row->id)->find()) {
            throw new Exception("栏目含有子栏目，不得删除！");
        }
        $catInfo = self::find($row->id);
        //检查是否存在数据，存在数据不执行删除
        if ($catInfo['modelid'] && $catInfo['type'] == 2) {
            $tbname = getModel($catInfo['modelid'], 'tablename');
            if ($tbname && Db::name($tbname)->where(['catid' => $row->id])->find()) {
                throw new Exception("栏目含有信息，不得删除！");
            }
        } else {
            //这边外链也有可能以前是单页
            Page::where(['catid' => $row->id])->delete();
        }
        cache::set("Category", null);
    }

    /**
     * 获取父栏目ID列表
     */
    public static function get_arrparentid($catid, $withself = false)
    {
        static $tree;
        if (!$tree) {
            $tree = \util\Tree::instance();
            $tree->init(Category::order('id asc')->field('id,parentid,catname')->select()->toArray(), 'parentid');
        }
        $parentIds = $tree->getParentsIds($catid, $withself);
        return implode(',', $parentIds);
    }

    /**
     * 获取子栏目ID列表
     */
    public static function get_arrchildid($catid, $withself = false)
    {
        static $tree;
        if (!$tree) {
            $tree = \util\Tree::instance();
            $tree->init(Category::order('id asc')->field('id,parentid,catname')->select()->toArray(), 'parentid');
        }
        $childIds = $tree->getChildrenIds($catid, $withself);
        return implode(',', $childIds);
    }

}
