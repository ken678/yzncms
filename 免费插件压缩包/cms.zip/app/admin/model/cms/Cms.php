<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | CMS模型
// +----------------------------------------------------------------------
namespace app\admin\model\cms;

use addons\cms\library\FulltextSearch;
use addons\cms\library\Service;
use think\facade\Db;
use think\Model;

/**
 * 模型
 */
class Cms extends Model
{
    protected $autoWriteTimestamp = true;
    protected $ext_table          = '_data';
    protected $name               = 'ModelField';

    protected static $config = [];

    protected static function init()
    {
        self::$config = get_addon_config('cms');
    }

    //添加模型内容
    public function addModelData($data, $dataExt = [])
    {
        $catid    = (int) $data['catid'];
        $category = Category::find($catid);
        $modelid  = $category['modelid'];

        //完整表名获取
        $tablename = Models::where('id', $modelid)->value('tablename');

        Service::getAfterText($data, $dataExt);

        //添加用户名
        $data['admin_id'] = session('admin.id') ?: 0;

        //处理数据
        [$data, $dataExt] = Service::dealModelPostData($modelid, $data, $dataExt);

        if (!isset($data['publish_time'])) {
            $data['publish_time'] = request()->time();
        }

        $data['create_time'] = request()->time();
        $data['update_time'] = request()->time();

        try {
            //主表
            $id = Db::name($tablename)->insertGetId($data);
            //TAG标签处理
            if (!empty($data['tags'])) {
                $this->tagDispose($data['tags'], $id, $catid, $modelid);
            }
            //附表
            if (!empty($dataExt)) {
                $dataExt['did'] = $id;
                Db::name($tablename . $this->ext_table)->insert($dataExt);
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
        //更新栏目统计数据
        $category->setInc('items');

        //推送到站点聚合插件
        if (self::$config['web_site_weburlpush']) {
            hook("weburlpush", buildContentUrl($catid, $id, $data['url'], true, true));
        }
        //新增讯搜索引
        if (self::$config['web_site_searchtype'] === 'xunsearch') {
            FulltextSearch::update($modelid, $catid, $id, $data, $dataExt);
        }
        return $id;
    }

    //编辑模型内容
    public function editModelData($data, $dataExt = [])
    {
        $catid = (int) $data['catid'];
        $id    = (int) $data['id'];

        $category = Category::find($catid);
        $modelid  = $category['modelid'];

        //完整表名获取
        $tablename = Models::where('id', $modelid)->value('tablename');

        Service::getAfterText($data, $dataExt);
        //TAG标签处理
        if (!empty($data['tags'])) {
            $this->tagDispose($data['tags'], $id, $catid, $modelid);
        } else {
            $this->tagDispose([], $id, $catid, $modelid);
        }
        [$data, $dataExt] = Service::dealModelPostData($modelid, $data, $dataExt);

        if (!isset($data['update_time'])) {
            $data['update_time'] = request()->time();
        }
        $info = Db::name($tablename)->where('id', $id)->find();
        if (empty($info)) {
            throw new \Exception("该信息不存在！");
        }
        //主表
        Db::name($tablename)->where('id', $id)->update($data);
        //附表
        if (!empty($dataExt)) {
            //查询是否存在ID 不存在则新增
            if (Db::name($tablename . $this->ext_table)->where('did', $id)->find()) {
                Db::name($tablename . $this->ext_table)->where('did', $id)->update($dataExt);
            } else {
                $dataExt['did'] = $id;
                Db::name($tablename . $this->ext_table)->insert($dataExt);
            };
        }
        //更新投稿
        if ($info['sysadd'] == 0) {
            CmsContent::where('catid', $catid)->where('content_id', $id)->update(['status' => $data['status']]);
        }
        //更新讯搜索引
        if (self::$config['web_site_searchtype'] === 'xunsearch') {
            FulltextSearch::update($modelid, $catid, $id, $data, $dataExt);
        }
    }

    //删除模型内容
    public function deleteModelData($catid, $id, $no_delete = false)
    {
        $category = Category::find($catid);
        if (empty($category)) {
            throw new \Exception("栏目不存在！");
        }
        $modelid = $category['modelid'];

        $model = Models::where('id', $modelid)->find();

        $data = Db::name($model['tablename'])->where('id', $id)->find();
        if (empty($data)) {
            throw new \Exception("该信息不存在！");
        }
        //处理tags
        if (!empty($data['tags'])) {
            $this->tagDispose([], $data['id'], $data['catid'], $modelid);
        }

        if ($no_delete) {
            Db::name($model['tablename'])->where('id', $id)->update(['status' => -1]);
        } else {
            Db::name($model['tablename'])->where('id', $id)->delete();
            if (2 == $model['type']) {
                Db::name($model['tablename'] . $this->ext_table)->where('did', $id)->delete();
            }
            //更新栏目统计
            if ($category['items']) {
                $category->setDec('items');
            }
        }
        //删除会员投稿
        if ($data['sysadd'] == 0) {
            CmsContent::where('catid', $data['catid'])->where('content_id', $data['id'])->delete();
        }

        //更新讯搜索引
        if (self::$config['web_site_searchtype'] === 'xunsearch') {
            FulltextSearch::del($data['catid'], $id);
        }
    }

    /**
     * TAG标签处理
     */
    private function tagDispose($tags, $id, $catid, $modelid)
    {
        if (!empty($tags)) {
            if (strpos($tags, ',') === false) {
                $keyword = explode(' ', $tags);
            } else {
                $keyword = explode(',', $tags);
            }
            $keyword = array_unique($keyword);
            if ('add' == request()->action()) {
                (new Tags)->addTag($keyword, $id, $catid);
            } else {
                (new Tags)->updata($keyword, $id, $catid);
            }
        } else {
            //直接清除已有的tags
            (new Tags)->deleteAll($id, $catid);
        }
    }
}
