<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 字段模型
// +----------------------------------------------------------------------
namespace app\admin\model\cms;

use think\Exception;
use think\facade\Db;
use think\Model;

/**
 * 字段模型
 */
class ModelField extends Model
{
    protected $autoWriteTimestamp = true;

    public function getSettingAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['setting'], true);
    }

    public function setSettingAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }

    public static function onBeforeWrite($row)
    {
        if ($row['ifrequire'] && 0 == $row['isadd']) {
            throw new Exception("必填字段不可以设置为隐藏！");
        }
        if (!$row['isadd'] && $row['ifrequire']) {
            throw new Exception("隐藏字段不可以设置为必填！");
        }
        $changedData = $row->getChangedData();
        if (isset($changedData['setting']) || isset($changedData['name']) || isset($changedData['title'])) {
            //判断字段名唯一性
            if (ModelField::where('name', $row['name'])->where('modelid', $row['modelid'])->where('id', '<>', $row['id'])->find()) {
                throw new Exception("字段'" . $row['name'] . "`已经存在");
            }
        }
        cms_cache('ModelField', null);
    }

    //更新前
    public static function onBeforeUpdate($row)
    {
        $changedData = $row->getChangedData();
        if (isset($changedData['name'])) {
            if ($row['setting']['value'] === '') {
                $default = '';
            } elseif (strstr(strtolower($row['setting']['define']), 'text') || strstr(strtolower($row['setting']['define']), 'blob')) {
                $default = '';
            } else {
                $default = " DEFAULT '{$row['setting']['value']}'";
            }

            $tablename = self::getModelTableName($row['modelid'], $row['ifsystem']);
            $sql       = <<<EOF
            ALTER TABLE `{$tablename}`
            CHANGE COLUMN `{$row->getOrigin('name')}` `{$row['name']}` {$row['setting']['define']} {$default} COMMENT '{$row['title']}';
EOF;
            try {
                Db::execute($sql);
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
        }
    }

    //新增前
    public static function onBeforeInsert($row)
    {
        if ($row['setting']['value'] === '') {
            $default = '';
        } elseif (strstr(strtolower($row['setting']['define']), 'text') || strstr(strtolower($row['setting']['define']), 'blob')) {
            $default = '';
        } else {
            $default = " DEFAULT '{$row['setting']['value']}'";
        }

        $tablename = self::getModelTableName($row['modelid'], $row['ifsystem']);

        $sql = <<<EOF
            ALTER TABLE `{$tablename}`
            ADD COLUMN `{$row['name']}` {$row['setting']['define']} {$default} COMMENT '{$row['title']}';
EOF;
        try {
            Db::execute($sql);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public static function onBeforeDelete($row)
    {
        $tablename = self::getModelTableName($row['modelid'], $row['ifsystem']);

        //判断是否允许删除
        $sql = <<<EOF
            ALTER TABLE `{$tablename}`
            DROP COLUMN `{$row['name']}`;
EOF;
        Db::execute($sql);
        cms_cache('ModelField', null);
    }

    /**
     * 根据模型ID，返回表名
     * @param type $modelid
     * @param type $modelid
     * @return string
     */
    protected static function getModelTableName($modelid, $ifsystem = 1)
    {
        $model = Models::find($modelid);
        if (!$model) {
            throw new Exception("未找到指定模型表");
        }
        //完整表名获取 判断主表 还是副表
        $tablename = self::getConfig('prefix') . ($ifsystem ? $model['tablename'] : $model['tablename'] . "_data");
        return $tablename;
    }
}
