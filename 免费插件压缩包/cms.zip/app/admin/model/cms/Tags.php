<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | Tag模型
// +----------------------------------------------------------------------
namespace app\admin\model\cms;

use think\Model;

class Tags extends Model
{
    protected $name               = 'cms_tags';
    protected $autoWriteTimestamp = true;

    public static function onBeforeDelete($row)
    {
        TagsContent::where('tag_id', $row['id'])->delete();
    }

    /**
     * 添加tags
     */
    public function addTag($tagname, $id, $catid)
    {
        if (!$tagname || !$id || !$catid) {
            return false;
        }
        $newdata = [];
        if (is_array($tagname)) {
            foreach ($tagname as $v) {
                if (empty($v) || $v == '') {
                    continue;
                }
                $row = $this->where("tag", $v)->find();
                if ($row) {
                    $row->setInc('usetimes');
                } else {
                    $row = self::create([
                        "tag"      => $v,
                        "usetimes" => 1,
                    ]);
                }
                $newdata[] = [
                    'tag_id'     => $row->id,
                    "content_id" => $id,
                    "catid"      => $catid,
                ];
            }
            (new TagsContent())->saveAll($newdata);
        }
    }

    /**
     * 根据指定的条件更新tags数据
     */
    public function updata($tagname, $id, $catid)
    {
        if (!$tagname || !$id || !$catid) {
            return false;
        }
        $tags = TagsContent::where([
            "content_id" => $id,
            "catid"      => $catid,
        ])->select();
        foreach ($tags as $key => $val) {
            //如果在新的关键字数组找不到，说明已经去除
            if (!in_array($val->tags->tag, $tagname)) {
                if ($val->tags->usetimes > 1) {
                    $val->tags->setDec('usetimes');
                } else {
                    $val->tags->delete();
                }
                $val->delete();
            } else {
                foreach ($tagname as $k => $v) {
                    if ($val->tags->tag == $v) {
                        unset($tagname[$k]);
                    }
                }
            }
        }
        //新增的tags
        if (count($tagname) > 0) {
            $this->addTag($tagname, $id, $catid);
        }
    }

    /**
     * 根据信息id删除全部的tags记录
     */
    public function deleteAll($id, $catid)
    {
        if (!$id || !$catid) {
            return false;
        }
        //取得对应tag数据
        $tagslist = TagsContent::where(['content_id' => $id, "catid" => $catid])->select();
        //全部-1
        foreach ($tagslist as $k => $value) {
            $row = Tags::find($value['tag_id']);
            if ($row) {
                if ($row->usetimes > 1) {
                    $row->setDec('usetimes');
                } else {
                    $row->delete();
                }
            }
            $value->delete();
        }
        return true;
    }

}
