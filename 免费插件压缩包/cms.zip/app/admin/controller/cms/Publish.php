<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 稿件管理
// +----------------------------------------------------------------------
namespace app\admin\controller\cms;

use app\admin\model\cms\Cms as CmsModel;
use app\admin\model\cms\CmsContent as CmsContentModel;
use app\common\controller\Backend;
use think\facade\Db;

class Publish extends Backend
{
    protected $CmsModel = null;

    protected function initialize()
    {
        parent::initialize();
        $this->CmsModel = new CmsModel;
    }

    public function index()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page  = $this->request->param('page/d', 10);

            $total = CmsContentModel::count();
            $list  = CmsContentModel::page($page, $limit)->order("id DESC")->select();

            foreach ($list as $k => $v) {
                $modelid = getCategory($v['catid'], 'modelid');
                $info    = Db::name(getModel($modelid, 'tablename'))->where(["id" => $v['content_id'], "sysadd" => 0])->find();
                if ($info) {
                    $list[$k]['url']     = buildContentUrl($v['catid'], $v['content_id'], $info['url']);
                    $list[$k]['title']   = $info['title'];
                    $list[$k]['catname'] = getCategory($v['catid'], 'catname');
                }
            }
            $result = ["code" => 0, "count" => $total, "data" => $list];

            return json($result);
        }
        return $this->fetch();
    }

    //删除
    public function del()
    {
        $ids = $this->request->param('id/a', null);
        if (empty($ids)) {
            $this->error('请指定需要删除的信息！');
        }
        if (!is_array($ids)) {
            $ids = [0 => $ids];
        }
        foreach ($ids as $id) {
            //信息
            $row = CmsContentModel::where('id', $id)->find();
            try {
                $this->CmsModel->deleteModelData($row['catid'], $row['content_id']);
                $row->delete();
            } catch (\Exception $e) {
                $this->error($e->getMessage());
            }
        }
        $this->success('删除成功！');
    }

    /**
     * 批量更新
     */
    public function multi()
    {
        if (false === $this->request->isPost()) {
            $this->error('未知参数');
        }
        $ids = $this->request->param('id/a', null);
        if (empty($ids)) {
            $this->error('参数错误！');
        }
        if (!is_array($ids)) {
            $ids = [0 => $ids];
        }
        if ($this->request->has('param')) {
            parse_str($this->request->param('param/s'), $values);
            $values = $this->auth->isAdministrator() ? $values : array_intersect_key($values, array_flip(is_array($this->multiFields) ? $this->multiFields : explode(',', $this->multiFields)));
            if (empty($values) && !isset($values['status'])) {
                $this->error('你没有权限操作！');
            }
            $adminIds = $this->getDataLimitAdminIds();
            $where    = [];
            if (is_array($adminIds)) {
                $where[] = [$this->dataLimitField, 'in', $adminIds];
            }
            $where[] = ['id', 'in', $ids];
            $count   = 0;
            Db::startTrans();
            try {
                $list = CmsContentModel::where($where)->select();
                foreach ($list as $item) {
                    $count += $item->save($values);
                    $modelid          = getCategory($item['catid'], 'modelid');
                    $values['status'] = $values['status'] == '-1' ? 0 : 1;
                    Db::name(cms_cache("Model")[$modelid]['tablename'])->where('id', $item['content_id'])->update($values);
                }
                Db::commit();
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($count) {
                $this->success("操作成功！");
            }
            $this->error('未更新任何行');

        }
        $this->error('Param参数不能为空');
    }

}
