<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 模型管理
// +----------------------------------------------------------------------
namespace app\admin\controller\cms;

use app\admin\model\cms\Models as ModelsModel;
use app\common\controller\Backend;

class Models extends Backend
{
    protected $modelClass    = null;
    protected $modelValidate = true;
    protected $filepath      = '';
    protected $noNeedRight   = ['get_tpl_list'];

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new ModelsModel;
        //取得当前内容模型模板存放目录
        $this->filepath = TEMPLATE_PATH . (empty(config('site.theme')) ? "default" : config('site.theme')) . DS . "cms" . DS;
    }

    //模型列表
    public function index()
    {
        if ($this->request->isAjax()) {
            $data = $this->modelClass->where('module', 'cms')->select();
            return json(["code" => 0, "data" => $data]);
        }
        return $this->fetch();
    }

    /**
     * 获取模板列表
     */
    public function get_tpl_list()
    {
        $type     = $this->request->param('type', 'category');
        $keyValue = $this->request->param('keyValue');

        $path = $this->filepath . $type;

        $list = str_replace($this->filepath, '', glob($path . '*.html'));

        $arr = [];
        foreach ($list as $key => $value) {
            if (!empty($keyValue) && $value != $keyValue) {
                continue;
            }
            $arr[]['name'] = $value;
        }
        return json(['count' => count($arr), 'data' => $arr]);
    }
}
