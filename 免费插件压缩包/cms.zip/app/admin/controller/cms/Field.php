<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 字段管理
// +----------------------------------------------------------------------
namespace app\admin\controller\cms;

use app\admin\model\cms\ModelField as ModelField;
use app\admin\model\cms\Models;
use app\common\controller\Backend;
use think\facade\Db;

class Field extends Backend
{
    protected $ext_table     = '_data';
    protected $multiFields   = 'isadd,ifrequire,ifsearch,ifrequire';
    protected $modelClass    = null;
    protected $modelValidate = true;

    //初始化
    protected function initialize()
    {
        parent::initialize();
        $filepath = app()->getAppPath() . 'admin' . DS . "view" . DS . 'custom' . DS;
        $custom   = str_replace($filepath . DS, '', glob($filepath . DS . 'custom*'));
        $this->assign('custom', $custom);
        $this->modelClass = new ModelField;

    }

    /**
     * 显示字段列表
     */
    public function index()
    {
        $modelid = $this->request->param('id/d', '');
        if (empty($modelid)) {
            $this->error('参数错误！');
        }
        $model = Models::find($modelid);
        if (empty($model)) {
            $this->error('该模型不存在！');
        }
        if ($this->request->isAjax()) {
            //根据模型读取字段列表
            $banFields                  = ['id', 'catid', 'did', 'user_id', 'admin_id'];
            list($page, $limit, $where) = $this->buildTableParames();
            $total                      = $this->modelClass
                ->where($where)
                ->where('modelid', $modelid)
                ->whereNotIn('name', $banFields)
                ->count();
            $data = $this->modelClass
                ->where($where)
                ->where('modelid', $modelid)
                ->whereNotIn('name', $banFields)
                ->order('listorder DESC, id DESC')
                ->page($page, $limit)
                ->select();
            $result = ["code" => 0, "count" => $total, "data" => $data];
            return json($result);
        }
        $this->assign([
            "modelid" => $modelid,
            "name"    => $model['name'],
        ]);
        $this->assignconfig("modelid", $modelid);
        return $this->fetch();
    }

    /**
     * 增加字段
     */
    public function add()
    {
        $modelid   = $this->request->param('modelid/d', '');
        $fieldType = Db::name('field_type')->order('listorder')->column('name,title,default_define,ifstring');
        $modelInfo = Models::find($modelid);
        $this->assign(
            [
                'modelType' => $modelInfo['type'],
                "modelid"   => $modelid,
                'fieldType' => $fieldType,
            ]
        );
        return parent::add();
    }

    /**
     * 修改字段
     */
    public function edit()
    {
        $fieldType = Db::name('field_type')->order('listorder')->column('name,title,default_define,ifstring');
        $this->assign('fieldType', $fieldType);
        return parent::edit();
    }
}
