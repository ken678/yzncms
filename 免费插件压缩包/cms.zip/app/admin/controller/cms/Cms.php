<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | cms管理
// +----------------------------------------------------------------------
namespace app\admin\controller\cms;

use addons\cms\library\Service;
use app\admin\model\cms\Category as CategoryModel;
use app\admin\model\cms\CategoryPriv as CategoryPrivModel;
use app\admin\model\cms\Cms as CmsModel;
use app\admin\model\cms\CmsContent;
use app\admin\model\cms\Models;
use app\admin\model\cms\Tags as TagsModel;
use app\common\controller\Backend;
use think\facade\Db;

class Cms extends Backend
{
    protected $searchFields = 'id,title';
    protected $noNeedRight  = ['check_title', 'panl', 'classlist'];
    protected $CmsModel     = null;
    protected $cmsConfig    = [];

    protected function initialize()
    {
        parent::initialize();
        $this->CmsModel  = new CmsModel;
        $this->cmsConfig = get_addon_config("cms");
        $this->assign("cmsConfig", $this->cmsConfig);
    }

    public function index()
    {
        $isAdministrator = $this->auth->isAdministrator();
        $categoryList    = $priv_catids    = [];

        if (0 !== (int) $this->cmsConfig['site_category_auth']) {
            //栏目权限 超级管理员例外
            if ($isAdministrator !== true) {
                $role_id     = $this->auth->roleid;
                $priv_result = CategoryPrivModel::where(['roleid' => $role_id, 'action' => 'init'])->select()->toArray();
                foreach ($priv_result as $_v) {
                    $priv_catids[] = $_v['catid'];
                }
            }
        }
        $categorys = CategoryModel::order('listorder DESC, id DESC')->select()->toArray();
        foreach ($categorys as $rs) {
            $state = ['opened' => true, 'disabled' => false];
            $icon  = "iconfont icon-list-check";

            if (0 !== (int) $this->cmsConfig['site_category_auth']) {
                //只显示有init权限的，超级管理员除外
                if ($isAdministrator !== true && !in_array($rs['id'], $priv_catids)) {
                    $arrchildid      = explode(',', $rs['arrchildid']);
                    $array_intersect = array_intersect($priv_catids, $arrchildid);
                    if (empty($array_intersect)) {
                        continue;
                    }
                }
            }
            if ($rs['type'] == 3) {
                $state['disabled'] = true;
                $icon              = "iconfont icon-links-line";
            } elseif ($rs['type'] == 1) {
                $state['disabled'] = true;
                $icon              = "iconfont icon-file-line";
            }
            $data = [
                'id'     => $rs['id'],
                'parent' => $rs['parentid'] ?: '#',
                'text'   => $rs['catname'],
                'icon'   => $icon,
                'state'  => $state,
            ];
            if ($rs['type'] == 2) {
                $data['url'] = (string) url('classlist', ['catid' => $rs['id']]);
            }
            $categoryList[] = $data;
        }
        $this->assignconfig('categoryList', $categoryList);
        return $this->fetch();
    }

    //栏目信息列表
    public function classlist()
    {
        $catid = $this->request->param('catid/d', 0);
        //当前栏目信息
        $catInfo = CategoryModel::find($catid);
        if (empty($catInfo)) {
            $this->error('该栏目不存在！');
        }
        //栏目所属模型
        $modelid = $catInfo['modelid'];
        if ($this->request->isAjax()) {

            $model = Models::find($modelid);
            if (!$model['status']) {
                $this->error('模型被禁用！');
            }

            $this->modelClass = Db::name($model['tablename']);
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($page, $limit, $where) = $this->buildTableParames();

            $conditions = [
                ['catid', '=', $catid],
                ['status', 'in', [0, 1]],
            ];
            $total = Db::name($model['tablename'])->where($where)->where($conditions)->count();
            $list  = Db::name($model['tablename'])->page($page, $limit)->where($where)->where($conditions)->order('listorder DESC, id DESC')->select();
            $_list = [];
            foreach ($list as $k => $v) {
                $v['update_time'] = date('Y-m-d H:i:s', $v['update_time']);
                $v['url']         = buildContentUrl($v['catid'], $v['id'], $v['url']);
                $_list[]          = $v;
            }
            $result = ["code" => 0, "count" => $total, "data" => $_list];
            return json($result);
        }
        /*移动栏目 复制栏目*/
        $tree       = new \util\Tree();
        $tree->icon = ['&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ '];
        $tree->nbsp = '&nbsp;&nbsp;&nbsp;';
        $categorys  = [];
        $result     = CategoryModel::order('listorder DESC, id DESC')->select()->toArray();
        foreach ($result as $k => $v) {
            if ($v['type'] != 2) {
                $v['disabled'] = 'disabled';
            }
            if ($modelid && $modelid != $v['modelid']) {
                $v['disabled'] = 'disabled';
            }
            //$v['disabled'] = $v['child'] ? 'disabled' : '';
            $v['selected'] = $v['id'] == $catid ? 'selected' : '';
            $categorys[$k] = $v;
        }
        $str = "<option value=@id @selected @disabled>@spacer @catname</option>";
        $tree->init($categorys);
        $string = $tree->getTree(0, $str, $catid);

        $this->assign('string', $string);
        $this->assign('catid', $catid);
        $this->assignconfig('catid', $catid);
        return $this->fetch();
    }

    //移动文章
    public function remove()
    {
        $this->check_priv('remove');
        if ($this->request->isPost()) {
            $catid = $this->request->param('catid/d', 0);
            if (!$catid) {
                $this->error("请指定栏目！");
            }
            //需要移动的信息ID集合
            $ids = $this->request->param('ids/a');
            //目标栏目
            $tocatid = $this->request->param('tocatid/d', 0);
            if ($ids) {
                if ($tocatid == $catid) {
                    $this->error('目标栏目和当前栏目是同一个栏目！');
                }
                //当前栏目信息
                $catInfo = CategoryModel::find($catid);
                if (empty($catInfo)) {
                    $this->error('该栏目不存在！');
                }
                $model = Models::find($catInfo['modelid']);
                if (!$model['status']) {
                    $this->error('模型被禁用！');
                }
                Db::name($model['tablename'])->where('id', 'in', $ids)->update(['catid' => $tocatid]);
                $row = CategoryModel::find($catid);
                if ($row['items'] >= count($ids)) {
                    $row->setDec('items', count($ids));
                }
                CategoryModel::where('id', $tocatid)->setInc('items', count($ids));
                $this->success('移动成功~');
            } else {
                $this->error('请选择需要移动的信息！');
            }
        }
    }

    //添加信息
    public function add()
    {
        $this->check_priv('add');
        if ($this->request->isPost()) {
            $data  = $this->request->post();
            $catid = intval($data['modelField']['catid']);
            if (empty($catid)) {
                $this->error("请指定栏目ID！");
            }
            $data['modelFieldExt'] = $data['modelFieldExt'] ?? [];
            try {
                $data['modelField']['sysadd'] = 1;
                $this->CmsModel->addModelData($data['modelField'], $data['modelFieldExt']);
            } catch (\Exception $ex) {
                $this->error($ex->getMessage());
            }
            $this->success('操作成功！');
        } else {
            $catid    = $this->request->param('catid/d', 0);
            $category = CategoryModel::find($catid);
            if (empty($category)) {
                $this->error('该栏目不存在！');
            }

            $modelid   = $category['modelid'];
            $fieldList = Service::getFieldList($modelid);
            $this->assign([
                'catid'     => $catid,
                'fieldList' => $fieldList,
            ]);
            $this->assignconfig('catid', $catid);
            return $this->fetch();

        }
    }

    //编辑信息
    public function edit()
    {
        $this->check_priv('edit');
        if ($this->request->isPost()) {
            $data                  = $this->request->post();
            $data['modelFieldExt'] = $data['modelFieldExt'] ?? [];
            try {
                $this->CmsModel->editModelData($data['modelField'], $data['modelFieldExt']);
            } catch (\Exception $ex) {
                $this->error($ex->getMessage());
            }
            $this->success('编辑成功！');

        } else {
            $catid    = $this->request->param('catid/d', 0);
            $id       = $this->request->param('id/d', 0);
            $category = CategoryModel::find($catid);
            if (empty($category)) {
                $this->error('该栏目不存在！');
            }

            $modelid   = $category['modelid'];
            $fieldList = Service::getFieldList($modelid, $id);
            $this->assign([
                'catid'     => $catid,
                'id'        => $id,
                'fieldList' => $fieldList,
            ]);
            $this->assignconfig('id', $id);
            $this->assignconfig('catid', $catid);
            return $this->fetch();

        }
    }

    //删除
    public function del()
    {
        $this->check_priv('delete');
        $catid = $this->request->param('catid/d', 0);
        $ids   = $this->request->param('id/a', null);
        if (empty($ids) || !$catid) {
            $this->error('参数错误！');
        }
        if (!is_array($ids)) {
            $ids = [0 => $ids];
        }
        try {
            foreach ($ids as $id) {
                $this->CmsModel->deleteModelData($catid, $id, $this->cmsConfig['web_site_recycle']);
            }
        } catch (\Exception $ex) {
            $this->error($ex->getMessage());
        }

        $this->success('删除成功！');
    }

    //面板
    public function panl()
    {
        if ($this->request->isPost()) {
            $date                         = $this->request->post('date');
            list($xAxisData, $seriesData) = $this->getAdminPostData($date);
            $this->success('', '', ['xAxisData' => $xAxisData, 'seriesData' => $seriesData]);
        } else {
            $info['category'] = CategoryModel::count();
            $info['model']    = Db::name('Model')->where('module', 'cms')->count();
            $info['tags']     = TagsModel::count();
            $info['doc']      = CategoryModel::where('type', 2)->sum('items');

            list($xAxisData, $seriesData) = $this->getAdminPostData();
            $this->assignconfig('xAxisData', $xAxisData);
            $this->assignconfig('seriesData', $seriesData);

            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    protected function getAdminPostData($date = '')
    {
        if ($date) {
            list($start, $end) = explode(' - ', $date);
            $start_time        = strtotime($start);
            $end_time          = strtotime($end);
        } else {
            $start_time = \util\Date::unixtime('day', 0, 'begin');
            $end_time   = \util\Date::unixtime('day', 0, 'end');
        }
        $diff_time = $end_time - $start_time;
        $format    = '%Y-%m-%d';
        if ($diff_time > 86400 * 30 * 2) {
            $format = '%Y-%m';
        } else {
            if ($diff_time > 86400) {
                $format = '%Y-%m-%d';
            } else {
                $format = '%H:00';
            }
        }
        //获取所有表名
        $models = Db::name('model')->where(['module' => 'cms', 'status' => 1])->select();
        $list   = $xAxisData   = $seriesData   = [];
        if (count($models) > 0) {
            $table1 = $models[0]['tablename'];
            unset($models[0]);
            $field = 'a.username,admin_id,FROM_UNIXTIME(b.create_time, "' . $format . '") as create_times,COUNT(*) AS num';
            $dbObj = Db::name($table1)->alias('b')->field($field)->where('b.create_time', 'between time', [$start_time, $end_time])->join('admin a', 'a.id = b.admin_id');
            foreach ($models as $k => $v) {
                $dbObj->union(function ($query) use ($field, $start_time, $end_time, $v) {
                    $query->name($v['tablename'])->alias('b')->field($field)->where('b.create_time', 'between time', [$start_time, $end_time])->join('admin a', 'a.id = b.admin_id')->group('admin_id,create_times');
                });
            };
            $res = $dbObj->group('admin_id,create_times')->select();
            if ($diff_time > 84600 * 30 * 2) {
                $start_time = strtotime('last month', $start_time);
                while (($start_time = strtotime('next month', $start_time)) <= $end_time) {
                    $column[] = date('Y-m', $start_time);
                }
            } else {
                if ($diff_time > 86400) {
                    for ($time = $start_time; $time <= $end_time;) {
                        $column[] = date("Y-m-d", $time);
                        $time += 86400;
                    }
                } else {
                    for ($time = $start_time; $time <= $end_time;) {
                        $column[] = date("H:00", $time);
                        $time += 3600;
                    }
                }
            }
            $xAxisData = array_fill_keys($column, 0);
            foreach ($res as $k => $v) {
                if (!isset($list[$v['username']])) {
                    $list[$v['username']] = $xAxisData;
                }
                $list[$v['username']][$v['create_times']] = $v['num'];
            }
            foreach ($list as $index => $item) {
                $seriesData[] = [
                    'name'      => $index,
                    'type'      => 'line',
                    'smooth'    => true,
                    'areaStyle' => [],
                    'data'      => array_values($item),
                ];
            }
        }
        return [array_keys($xAxisData), $seriesData];
    }

    //回收站
    public function recyclebin()
    {
        $catid = $this->request->param('catid/d', 0);
        //当前栏目信息
        $catInfo = CategoryModel::find($catid);
        if (empty($catInfo)) {
            $this->error('该栏目不存在！');
        }
        //栏目所属模型
        $modelid = $catInfo['modelid'];
        if ($this->request->isAjax()) {
            $model = Models::find($modelid);
            if (!$model['status']) {
                $this->error('模型被禁用！');
            }
            $this->modelClass           = Db::name($model['tablename']);
            list($page, $limit, $where) = $this->buildTableParames();
            $conditions                 = [
                ['catid', '=', $catid],
                ['status', '=', -1],
            ];
            $total = Db::name($model['tablename'])
                ->where($where)
                ->where($conditions)
                ->count();
            $list = Db::name($model['tablename'])
                ->where($where)
                ->page($page, $limit)
                ->where($conditions)
                ->order('listorder DESC, id DESC')
                ->select();
            $_list = [];
            foreach ($list as $k => $v) {
                $v['update_time'] = date('Y-m-d H:i:s', $v['update_time']);
                $_list[]          = $v;
            }
            $result = ["code" => 0, "count" => $total, "data" => $_list];

            $result = ["code" => 0, "count" => $total, "data" => $_list];
            return json($result);
        }
        $this->assignconfig('catid', $catid);
        return $this->fetch();
    }

    //还原回收站
    public function restore()
    {
        $catid = $this->request->param('catid/d', 0);
        //当前栏目信息
        $catInfo = CategoryModel::find($catid);
        if (empty($catInfo)) {
            $this->error('该栏目不存在！');
        }
        //栏目所属模型
        $modelid = $catInfo['modelid'];
        $ids     = $this->request->param('id/a');

        $model = Models::find($modelid);
        if (!$model['status']) {
            $this->error('模型被禁用！');
        }
        if ($ids) {
            if (!is_array($ids)) {
                $ids = [0 => $ids];
            }
            Db::name($model['tablename'])->where('id', 'in', $ids)->update(['status' => 1]);
        }
        $this->success('还原成功！');
    }

    //清空回收站
    public function destroy()
    {
        $catid = $this->request->param('catid/d', 0);
        $ids   = $this->request->param('id/a', null);
        if (empty($ids) || !$catid) {
            $this->error('参数错误！');
        }
        if (!is_array($ids)) {
            $ids = [0 => $ids];
        }
        try {
            foreach ($ids as $id) {
                $this->CmsModel->deleteModelData($catid, $id);
            }
        } catch (\Exception $ex) {
            $this->error($ex->getMessage());
        }

        $this->success('销毁成功！');
    }

    //批理操作
    public function multi()
    {
        $this->check_priv('status');
        $catid = $this->request->param('catid/d', 0);
        $id    = $this->request->param('id/d', 0);

        parse_str($this->request->param('param/s'), $values);
        $values = $this->auth->isAdministrator() ? $values : array_intersect_key($values, array_flip(is_array($this->multiFields) ? $this->multiFields : explode(',', $this->multiFields)));
        if (empty($values)) {
            $this->error('你没有权限操作！');
        }
        $catInfo = getCategory($catid);
        if (empty($catInfo)) {
            $this->error('该栏目不存在！');
        }
        $tableName = Models::where('id', $catInfo['modelid'])->value('tablename');

        Db::name($tableName)->where('id', $id)->update($values);
        //更新栏目缓存
        getCategory($id, '', true);
        cms_cache('Category', null);
        $data = Db::name($tableName)->where('id', $id)->find();
        //更新投稿
        if ($data['sysadd'] == 0 && isset($values['status'])) {
            CmsContent::where('catid', $catid)->where('content_id', $id)->update(['status' => $values['status']]);
        }
        $this->success('操作成功！');

    }

    public function check_title()
    {
        $title = $this->request->param('data/s', '');
        $catid = $this->request->param('catid/d', 0);
        $id    = $this->request->param('id/d', 0);
        if (empty($title)) {
            $this->success('标题没有重复！');
            return false;
        }
        $catInfo = getCategory($catid);
        if (empty($catInfo)) {
            $this->error('该栏目不存在！');
        }
        $tableName = Models::where('id', $catInfo['modelid'])->value('tablename');

        $repeat = Db::name($tableName)->where('title', $title);
        empty($id) ?: $repeat->where('id', '<>', $id);
        if ($repeat->find()) {
            $this->error('标题有重复！');
        } else {
            $this->success('标题没有重复！');
        }
    }

    protected function check_priv($action)
    {
        if (!$this->auth->isAdministrator()) {
            if (0 !== (int) $this->cmsConfig['site_category_auth']) {
                $catid   = $this->request->param('catid/d', 0);
                $catInfo = CategoryModel::find($catid);

                $action     = $catInfo['type'] == 1 ? 'init' : $action;
                $priv_datas = CategoryPrivModel::where(['catid' => $catid, 'is_admin' => 1, 'roleid' => $this->auth->roleid, 'action' => $action])->find();
                if (empty($priv_datas)) {
                    $this->error('您没有操作该项的权限！');
                }
            }
        }
    }

}
