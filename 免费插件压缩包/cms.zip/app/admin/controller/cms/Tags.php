<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | tags管理
// +----------------------------------------------------------------------
namespace app\admin\controller\cms;

use app\admin\model\cms\Models;
use app\admin\model\cms\Tags as TagsModel;
use app\admin\model\cms\TagsContent;
use app\common\controller\Backend;
use think\facade\Db;

class Tags extends Backend
{
    protected $modelClass = null;

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new TagsModel;
    }

    /**
     * tags列表
     */
    public function index()
    {
        if ($this->request->isAjax()) {
            list($page, $limit, $where) = $this->buildTableParames();
            $list                       = $this->modelClass
                ->where($where)
                ->order(['listorder' => 'desc', 'id' => 'desc'])
                ->page($page, $limit)
                ->select();
            foreach ($list as $k => &$v) {
                $v['url'] = addon_url('cms/tags/index', [':tag' => $v['tag']]);
            }
            unset($v);
            $total  = $this->modelClass->where($where)->count();
            $result = ["code" => 0, "count" => $total, "data" => $list];
            return json($result);
        }
        return $this->fetch();

    }

    //tags数据重建
    public function create()
    {
        if ($this->request->isPost() || $this->request->param('modelid/d')) {
            $_GET['modelid'] = $modelid = $this->request->param('modelid/d', 0);
            $lun             = $this->request->param('lun/d', 0); //第几轮 0=>1
            $_GET['zlun']    = $zlun    = $this->request->param('zlun/d', 0); //总轮数
            $_GET['mo']      = $this->request->param('mo/d', null); //是否全部模型
            if ($lun > (int) $_GET['zlun'] - 1) {
                $lun = (int) $_GET['zlun'] - 1;
            }
            $lun      = $lun < 0 ? 0 : $lun;
            $mlun     = 100;
            $firstRow = $mlun * ($lun < 0 ? 0 : $lun);
            if (0 !== (int) $this->request->param('delete/d')) {
                //清空
                Db::name('cms_tags')->delete(true);
                Db::name('cms_tags_content')->delete(true);
            }
            unset($_GET['delete']);
            $model = Models::where('type', 2)->column('name,tablename', 'id');
            //当全部模型重建时处理
            if ($modelid == 0) {
                $modelDATA       = Models::where('type', 2)->order('id', 'ASC')->find();
                $modelid         = $modelDATA['id'];
                $_GET['mo']      = 1;
                $_GET['modelid'] = $modelid;
            }
            $models_v = $model[$modelid];
            if (!is_array($models_v)) {
                $this->error("该模型不存在！");
            }
            $tableName = $models_v['tablename'];
            $count     = Db::name($tableName)->count();
            if ($count == 0) {
                //结束
                if (isset($_GET['mo'])) {
                    $modelDATA = Models::where([
                        ['type', '=', 2],
                        ['id', '>', $modelid],
                    ])->order('id', 'ASC')->find();
                    if (!$modelDATA) {
                        $this->success("Tags重建结束！", url('index'));
                    }
                    unset($_GET['zlun']);
                    unset($_GET['lun']);
                    $modelid         = $modelDATA['id'];
                    $_GET['modelid'] = $modelid;
                    $this->success("模型：{$models_v['name']}，第 " . ($lun + 1) . "/{$zlun} 轮更新成功，进入下一轮更新中...", url('create', $_GET), '', 1);
                } else {
                    $this->error('该模型下没有信息！');
                }
            }
            //总轮数
            $zlun         = ceil($count / $mlun);
            $_GET['zlun'] = $zlun;
            $this->createUP($models_v, $firstRow, $mlun);
            if ($lun == (int) $_GET['zlun'] - 1) {
                if (isset($_GET['mo'])) {
                    $modelDATA = Db::name('Model')->where([
                        ['type', '=', 2],
                        ['id', '>', $modelid],
                    ])->order('id', 'ASC')->find();
                    if (!$modelDATA) {
                        $this->success("Tags重建结束！", url('index'));
                    }
                    unset($_GET['zlun']);
                    unset($_GET['lun']);
                    $modelid         = $modelDATA['id'];
                    $_GET['modelid'] = $modelid;
                } else {
                    $this->success("Tags重建结束！", url('index'));
                }
            } else {
                $_GET['lun'] = $lun + 1;
            }
            $this->success("模型：" . $models_v['name'] . "，第 " . ($lun + 1) . "/$zlun 轮更新成功，进入下一轮更新中...", url('create', $_GET), '', 1);
        } else {
            $model = Models::where('type', 2)->column('name', 'id');
            $this->assign('model', $model);
            return $this->fetch();

        }
    }

    //数据重建
    protected function createUP($models_v, $firstRow, $mlun)
    {
        $keywords = Db::name(ucwords($models_v['tablename']))->where([
            ["status", '=', 1],
            ['tags', '<>', ''],
        ])->order("id", "ASC")->limit($firstRow, $mlun)->column('id,catid,tags');
        foreach ($keywords as $keyword) {
            $data = [];
            $time = time();
            $key  = strpos($keyword['tags'], ',') !== false ? explode(',', $keyword['tags']) : explode(' ', $keyword['tags']);
            foreach ($key as $key_v) {
                if (empty($key_v) || $key_v == "") {
                    continue;
                }
                $key_v = trim($key_v);
                $row   = TagsModel::where('tag', $key_v)->find();
                if ($row) {
                    $row->setInc('usetimes');
                } else {
                    $row = TagsModel::create([
                        "tag"         => $key_v,
                        "usetimes"    => 1,
                        "create_time" => $time,
                        "update_time" => $time,
                    ]);
                }
                $data = [
                    'tag_id'     => $row->id,
                    "content_id" => $keyword['id'],
                    "catid"      => $keyword['catid'],
                ];
                TagsContent::create($data);
            }
        }
        return true;
    }

}
