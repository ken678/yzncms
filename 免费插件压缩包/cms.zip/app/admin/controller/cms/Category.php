<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 栏目管理
// +----------------------------------------------------------------------
namespace app\admin\controller\cms;

use app\admin\model\cms\Category as CategoryModel;
use app\admin\model\cms\CategoryPriv as CategoryPrivModel;
use app\admin\model\cms\Models;
use app\admin\model\user\UserGroup;
use app\common\controller\Backend;
use think\exception;
use think\exception\ValidateException;
use think\facade\Cache;
use think\facade\Db;

class Category extends Backend
{

    private $categoryTemplate;
    private $listTemplate;
    private $showTemplate;
    private $pageTemplate;
    protected $noNeedRight = ['count_items', 'public_cache', 'public_tpl_file_list'];

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new CategoryModel;
        //取得当前内容模型模板存放目录
        $themePath = TEMPLATE_PATH . (config('site.theme') ?: "default") . DS . "cms" . DS;
        //取得栏目频道模板列表
        $this->categoryTemplate = str_replace($themePath . DS, '', glob($themePath . DS . 'category*'));
        //取得栏目列表模板列表
        $this->listTemplate = str_replace($themePath . DS, '', glob($themePath . DS . 'list*'));
        //取得内容页模板列表
        $this->showTemplate = str_replace($themePath . DS, '', glob($themePath . DS . 'show*'));
        //取得单页模板
        $this->pageTemplate = str_replace($themePath . DS, '', glob($themePath . DS . 'page*'));
    }

    //栏目列表
    public function index()
    {
        if ($this->request->isAjax()) {
            $models     = Models::where('status', 1)->column('name', 'id');
            $tree       = new \util\Tree();
            $tree->icon = ['&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ '];
            $tree->nbsp = '&nbsp;&nbsp;&nbsp;';
            $categorys  = [];
            $result     = CategoryModel::order('listorder DESC, id DESC')->select();
            foreach ($result as $k => $v) {
                if (isset($models[$v['modelid']])) {
                    $v['modelname'] = $models[$v['modelid']];
                } else {
                    $v['modelname'] = '/';
                }
                $v['url']            = buildCatUrl($v['id'], $v['url']);
                $categorys[$v['id']] = $v;
            }
            $tree->init($categorys);
            $_list  = $tree->getTreeList($tree->getTreeArray(0), 'catname');
            $total  = count($_list);
            $result = ["code" => 0, "count" => $total, "data" => $_list];
            return json($result);
        }
        return $this->fetch();
    }

    //新增栏目
    public function add()
    {
        if ($this->request->isPost()) {
            $data = $this->request->post('row/a');
            switch ($data['type']) {
                //单页
                case 1:
                    $scene = 'page';
                    break;
                //列表
                case 2:
                    $scene = 'list';
                    break;
                //外链
                case 3:
                    $scene = 'link';
                    break;
                default:
                    $this->error('栏目类型错误~');
            }
            if ($data['isbatch']) {
                unset($data['isbatch']);
                //需要批量添加的栏目
                $batch_add = explode(PHP_EOL, $data['batch_add']);
                if (empty($batch_add) || empty($data['batch_add'])) {
                    $this->error('请填写需要添加的栏目！');
                }
                foreach ($batch_add as $rs) {
                    if (trim($rs) == '') {
                        continue;
                    }
                    $cat             = explode('|', $rs, 2);
                    $data['catname'] = $cat[0];
                    $data['catdir']  = $cat[1] ?? '';
                    $data['catdir']  = $this->get_dirpinyin($data['catname'], $data['catdir']);

                    try {
                        $this->validate($data, 'app\admin\validate\cms\Category.' . $scene);
                        CategoryModel::create($data);
                    } catch (ValidateException $e) {
                        $this->error($e->getMessage());
                    } catch (Exception $e) {
                        $this->error($e->getMessage());
                    }
                }
                $this->success("添加成功！");
            } else {
                $data['catdir'] = $this->get_dirpinyin($data['catname'], $data['catdir']);

                try {
                    $this->validate($data, 'app\admin\validate\cms\Category.' . $scene);
                    $this->modelClass->save($data);
                } catch (ValidateException $e) {
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    $this->error($e->getMessage());
                }
                $this->success("添加成功！");
            }
        } else {
            $parentid = $this->request->param('parentid/d', 0);
            if (!empty($parentid)) {
                $Ca = getCategory($parentid);
                if (empty($Ca)) {
                    $this->error("父栏目不存在！");
                }
            }
            //输出可用模型
            $models = Models::where('status', 1)->where('module', 'cms')->select();
            //栏目列表 可以用缓存的方式
            $array = CategoryModel::order('listorder DESC, id DESC')->column('*', 'id');
            if (!empty($array) && is_array($array)) {
                $tree       = new \util\Tree();
                $tree->icon = ['&nbsp;&nbsp;│ ', '&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;└─ '];
                $tree->nbsp = '&nbsp;&nbsp;';
                $str        = "<option value=@id @selected @disabled>@spacer @catname</option>";
                $tree->init($array);
                $categorydata = $tree->getTree(0, $str, $parentid);
            } else {
                $categorydata = '';
            }
            $this->assign([
                'category'         => $categorydata,
                'models'           => $models,
                'tp_category'      => $this->categoryTemplate,
                'tp_list'          => $this->listTemplate,
                'tp_show'          => $this->showTemplate,
                'tp_page'          => $this->pageTemplate,
                'parentid_modelid' => $Ca['modelid'] ?? 0,
                "userGroup"        => UserGroup::column('name', 'id'),
                "cmsConfig"        => get_addon_config("cms"),
            ]);
            $this->assignconfig("parentid_modelid", $Ca['modelid'] ?? 0);
            return $this->fetch();
        }
    }

    //编辑栏目
    public function edit()
    {
        if ($this->request->isPost()) {
            $catid = $this->request->param('id/d', 0);
            $row   = $this->modelClass->find($catid);
            if (!$row) {
                $this->error('记录未找到');
            }
            $data = $this->request->post('row/a');
            //上级栏目不能是自身
            if ($data['parentid'] == $catid) {
                $this->error('上级栏目不能是自身！');
            }
            switch ($data['type']) {
                //单页
                case 1:
                    $data['modelid'] = 0;
                    $scene           = 'page';
                    break;
                //列表
                case 2:
                    $scene = 'list';
                    break;
                //列表
                case 3:
                    $data['modelid'] = 0;
                    $scene           = 'link';
                    break;
                default:
                    $this->error('栏目类型错误~');
            }
            $data['catdir'] = $this->get_dirpinyin($data['catname'], $data['catdir'], $catid);

            try {
                $this->validate($data, 'app\admin\validate\cms\Category.' . $scene);
                $row->save($data);
            } catch (ValidateException $e) {
                $this->error($e->getMessage());
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
            $this->success("修改成功！");
        } else {
            $catid = $this->request->param('id/d', 0);
            if (empty($catid)) {
                $this->error('请选择需要修改的栏目！');
            }
            $data = CategoryModel::find($catid);

            //输出可用模型
            $models = Models::where('status', 1)->where('module', 'cms')->select();
            //栏目列表 可以用缓存的方式
            $array = CategoryModel::order('listorder DESC, id DESC')->column('*', 'id');

            if (!empty($array) && is_array($array)) {
                $tree       = new \util\Tree();
                $tree->icon = ['&nbsp;&nbsp;│ ', '&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;└─ '];
                $tree->nbsp = '&nbsp;&nbsp;';
                $str        = "<option value=@id @selected @disabled>@spacer @catname</option>";
                $tree->init($array);
                $categorydata = $tree->getTree(0, $str, $data['parentid']);
            } else {
                $categorydata = '';
            }
            $this->assign([
                'data'        => $data,
                'setting'     => $data['setting'],
                'category'    => $categorydata,
                'models'      => $models,
                'tp_category' => $this->categoryTemplate,
                'tp_list'     => $this->listTemplate,
                'tp_show'     => $this->showTemplate,
                'tp_page'     => $this->pageTemplate,
                'privs'       => CategoryPrivModel::where('catid', $catid)->select(),
                "cmsConfig"   => get_addon_config("cms"),
                "userGroup"   => UserGroup::column('name', 'id'),
            ]);
            return $this->fetch();
        }
    }

    //栏目授权
    public function cat_priv()
    {
        $act = $this->request->param('act');
        $id  = $this->request->param('id');
        if ($act == 'authorization') {
            if (empty($id)) {
                $this->error('请指定需要授权的角色！');
            }
            if ($this->request->isAjax()) {
                $data = $this->request->post();
                $priv = [];
                if (isset($data['priv'])) {
                    foreach ($data['priv'] as $k => $v) {
                        foreach ($v as $e => $q) {
                            $priv[] = ["roleid" => $id, "catid" => $k, "action" => $q, "is_admin" => 1];
                        }
                    }
                    CategoryPrivModel::where("roleid", $id)->delete();
                    (new CategoryPrivModel)->saveAll($priv);
                    $this->success("栏目授权成功！");
                } else {
                    $this->error('请指定需要授权的栏目！');
                }
            } else {
                $tree          = new \util\Tree();
                $tree->icon    = ['&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ '];
                $tree->nbsp    = '&nbsp;&nbsp;&nbsp;';
                $category_priv = CategoryPrivModel::where("roleid", $id)->select()->toArray();
                $priv          = [];
                foreach ($category_priv as $k => $v) {
                    $priv[$v['catid']][$v['action']] = true;
                }
                $categorys = CategoryModel::order('listorder DESC, id DESC')->select()->toArray();
                foreach ($categorys as $k => $v) {
                    if ($v['type'] == 1 || $v['child']) {
                        $v['disabled']        = 'disabled';
                        $v['init_check']      = '';
                        $v['add_check']       = '';
                        $v['delete_check']    = '';
                        $v['listorder_check'] = '';
                        $v['move_check']      = '';
                        $v['edit_check']      = '';
                        $v['status_check']    = '';
                    } else {
                        $v['disabled']        = '';
                        $v['add_check']       = isset($priv[$v['id']]['add']) ? 'checked' : '';
                        $v['delete_check']    = isset($priv[$v['id']]['delete']) ? 'checked' : '';
                        $v['listorder_check'] = isset($priv[$v['id']]['listorder']) ? 'checked' : '';
                        $v['move_check']      = isset($priv[$v['id']]['remove']) ? 'checked' : '';
                        $v['edit_check']      = isset($priv[$v['id']]['edit']) ? 'checked' : '';
                        $v['status_check']    = isset($priv[$v['id']]['status']) ? 'checked' : '';
                    }
                    $v['init_check'] = isset($priv[$v['id']]['init']) ? 'checked' : '';
                    $categorys[$k]   = $v;
                }
                $str = "<tr>
    <td align='center'><input type='checkbox'  value='1' data-name='@id' lay-skin='primary'></td>
    <td>@spacer@catname</td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @init_check  lay-skin='primary' value='init' ></td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @disabled @add_check lay-skin='primary' value='add' ></td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @disabled @edit_check lay-skin='primary' value='edit' ></td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @disabled @delete_check  lay-skin='primary' value='delete' ></td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @disabled @listorder_check lay-skin='primary' value='listorder' ></td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @disabled @status_check lay-skin='primary' value='status' ></td>
    <td align='center'><input type='checkbox' name='priv[@id][]' @disabled @move_check lay-skin='primary' value='remove' ></td>
            </tr>";
                $tree->init($categorys);
                $categorydata = $tree->getTree(0, $str);
                $this->assign("categorys", $categorydata);
                return $this->fetch('authorization');
            }
        } elseif ($act == 'remove') {
            CategoryPrivModel::where('roleid', $id)->delete();
            $this->success('删除成功！');
        }
        if ($this->request->isAjax()) {
            $priv_num      = [];
            $category_priv = CategoryPrivModel::field("count(*) as num,roleid")->group("roleid")->select()->toArray();
            foreach ($category_priv as $k => $v) {
                $priv_num[$v['roleid']] = $v['num'];
            }
            $list = Db::name('AuthGroup')->where('status', 1)->order('id', 'desc')->field('id,title')->select()->toArray();
            foreach ($list as $k => $v) {
                $list[$k]['admin'] = $v['id'] == 1;
                $list[$k]['num']   = $priv_num[$v['id']] ?? 0;
            }
            $result = ["code" => 0, "data" => $list];
            return json($result);
        } else {
            $cmsConfig = get_addon_config("cms");
            $this->assign("cmsConfig", $cmsConfig);
            return $this->fetch();
        }
    }

    //更新栏目缓存并修复
    public function public_cache()
    {
        //取出需要处理的栏目数据
        $categorys = CategoryModel::order('listorder DESC, id DESC')->column('*', 'id');
        if (empty($categorys)) {
            return true;
        }
        try {
            if (is_array($categorys)) {
                foreach ($categorys as $catid => $cat) {
                    //获取父栏目ID列表
                    $arrparentid = CategoryModel::get_arrparentid($catid);
                    //获取子栏目ID列表
                    $arrchildid = CategoryModel::get_arrchildid($catid, true);
                    $child      = is_numeric($arrchildid) ? 0 : 1; //是否有子栏目
                    //检查所有父id 子栏目id 等相关数据是否正确，不正确更新
                    if ($cat['arrparentid'] != $arrparentid || $cat['arrchildid'] != $arrchildid || $cat['child'] != $child) {
                        CategoryModel::where('id', $catid)->update(['arrparentid' => $arrparentid, 'arrchildid' => $arrchildid, 'child' => $child]);
                    }
                    Cache::delete('getCategory_' . $catid);
                    //删除在非正常显示的不含信息或子栏目的栏目
                    if ($cat['parentid'] != 0 && !isset($categorys[$cat['parentid']])) {
                        CategoryModel::destroy($catid);
                    }
                }
            }
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
        cms_cache('Category', null);
        $this->success("更新缓存成功！");
    }

    //重新统计栏目信息数量
    public function count_items()
    {
        $result = CategoryModel::order('listorder DESC, id DESC')->select();
        $models = Models::column('tablename', 'id');
        foreach ($result as $r) {
            if ($r['type'] == 2 && isset($models[$r['modelid']])) {
                $number = Db::name(ucwords($models[$r['modelid']]))->where('catid', $r['id'])->count();
                CategoryModel::where('id', $r['id'])->update(['items' => $number]);
            } else {
                CategoryModel::where('id', $r['id'])->update(['items' => 0]);
            }
        }
        $this->success("栏目数量校正成功！");
    }

    public function multi()
    {
        $id = $this->request->param('id/d');
        cms_cache('Category', null);
        getCategory($id, '', true);
        return parent::multi();
    }

    //获取栏目的拼音
    private function get_dirpinyin($catname = '', $catdir = '', $id = 0)
    {
        $pinyin = new \Overtrue\Pinyin\Pinyin('Overtrue\Pinyin\MemoryFileDictLoader');
        if (empty($catdir)) {
            $catdir = $pinyin->permalink($catname, '');
        }
        if (strval(intval($catdir)) == strval($catdir)) {
            $catdir .= genRandomString(3);
        }
        $map = [
            ['catdir', '=', $catdir],
        ];
        if (intval($id) > 0) {
            $map[] = ['id', '<>', $id];
        }
        $result = CategoryModel::field('id')->where($map)->find();
        if (!empty($result)) {
            $nowDirname = $catdir . genRandomString(3);
            return $this->get_dirpinyin($catname, $nowDirname, $id);
        }
        return $catdir;
    }

    //动态根据模型ID加载栏目模板
    public function public_tpl_file_list()
    {
        $id   = $this->request->param('id/d');
        $data = Models::where('id', $id)->find();
        if ($data) {
            $this->success("", null, ['data' => $data['setting']]);
        }
    }

}
