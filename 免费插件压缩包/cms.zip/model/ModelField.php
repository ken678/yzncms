<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 字段模型
// +----------------------------------------------------------------------
namespace addons\cms\model;

use think\Model;

/**
 * 字段模型
 */
class ModelField extends Model
{
    protected $autoWriteTimestamp = true;

    public function getSettingAttr($value, $data)
    {
        return is_array($value) ? $value : (array) json_decode($data['setting'], true);
    }

    public function setSettingAttr($value)
    {
        return is_array($value) ? json_encode($value) : $value;
    }

    public function getExtendHtmlAttr($value, $data)
    {
        $result = preg_replace_callback("/\{([a-zA-Z]+)\}/", function ($matches) use ($data) {
            if (isset($data[$matches[1]])) {
                return $data[$matches[1]];
            }
        }, $data['extend']);
        return $result;
    }

    //生成模型字段缓存
    public function model_field_cache()
    {
        $cache     = [];
        $modelList = Models::where('module', 'cms')->select();
        foreach ($modelList as $v) {
            $data      = ModelField::where(["modelid" => $v['id'], "status" => 1])->order('listorder DESC, id DESC')->select()->toArray();
            $fieldList = [];

            foreach ($data as $rs) {
                if (!empty($rs['setting'])) {
                    $rs = array_merge($rs, $rs['setting']);
                }
                $fieldList[$rs['name']] = $rs;
            }

            $cache[$v['id']] = $fieldList;
        }
        cms_cache('ModelField', $cache);
        return $cache;
    }
}
