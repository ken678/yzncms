<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | CMS模型
// +----------------------------------------------------------------------
namespace addons\cms\model;

use addons\cms\library\Service;
use think\facade\Db;
use think\Model;

/**
 * 模型
 */
class Cms extends Model
{
    protected $autoWriteTimestamp = true;
    protected $ext_table          = '_data';
    protected $name               = 'model_field';

    protected static $config = [];
    protected static function init()
    {
        self::$config = get_addon_config('cms');
    }

    /**
     * 列表页
     * @param   $modeId  [模型ID]
     * @param   $where   [查询条件]
     * @param   $moreifo [是否含附表]
     * @param   $field   []
     * @param   $order   []
     * @param   $limit   [条数]
     * @param   $page    [是否有分页]
     * @param  int|bool  $simple   是否简洁模式或者总记录数
     * @param  array     $config   配置参数
     */
    public function getList($modeId, $where, $moreifo, $field = '*', $order = '', $limit = 10, $page = null, $simple = false, $config = [])
    {
        $url_mode            = self::$config['site_url_mode'];
        $config['query']     = isset($config['query']) ? array_merge($config['query'], request()->get()) : request()->get();
        $config['list_rows'] = $limit;

        $tableName = cms_cache("Model")[$modeId]['tablename'] ?? '';

        $result = [];
        if ($tableName) {
            if (2 == getModel($modeId, 'type') && $moreifo) {
                $extTable = $tableName . $this->ext_table;
                $cmsModel = Db::view($tableName, $field)->where($where)->view($extTable, '*', $tableName . '.id=' . $extTable . '.did', 'LEFT')->order($order);
            } else {
                $cmsModel = Db::name($tableName)->where($where)->order($order)->field($field);
            }
            if ($page) {
                $result = $cmsModel->paginate($config, $simple);
            } else {
                list($offset, $length) = strpos($limit, ',') !== false
                ? array_map('intval', explode(',', $limit))
                : [0, intval($limit)];
                $result = $cmsModel->limit($offset, $length)->select()->toArray();
            }
        }

        //数据格式化处理
        if (!empty($result)) {
            $ModelField = cms_cache('ModelField');
            $Category   = cms_cache('Category');
            foreach ($result as $key => $vo) {
                $vo           = Service::dealModelShowData($ModelField[$modeId], $vo);
                $cat          = $url_mode == 1 ? $vo['catid'] : ($Category[$vo['catid']]['catdir'] ?? getCategory($vo['catid'], 'catdir'));
                $vo['url']    = buildContentUrl($cat, $vo['id'], $vo['url']);
                $result[$key] = $vo;
            }
        }
        return $result;
    }

    /**
     * 详情页
     * @param  [type]  $modeId  [模型ID]
     * @param  [type]  $where   [查询条件]
     * @param  boolean $moreifo [是否含附表]
     * @param  string  $field   []
     * @param  string  $order   []
     */
    public function getContent($modeId, $where, $moreifo = false, $field = '*', $order = '', $cacheKey = false, $cacheExpire = null)
    {
        $url_mode = self::$config['site_url_mode'];

        $tableName = cms_cache("Model")[$modeId]['tablename'] ?? '';

        $dataInfo = [];
        if ($tableName) {
            if (2 == getModel($modeId, 'type') && $moreifo) {
                $extTable = $tableName . $this->ext_table;
                $dataInfo = Db::view($tableName, '*')->where($where)->cache($cacheKey, $cacheExpire, 'cms')->view($extTable, '*', $tableName . '.id=' . $extTable . '.did', 'LEFT')->find();
            } else {
                $dataInfo = Db::name($tableName)->field($field)->cache($cacheKey, $cacheExpire, 'cms')->where($where)->order($order)->find();
            }
        }
        if (!empty($dataInfo)) {
            $ModelField      = cms_cache('ModelField');
            $Category        = cms_cache('Category');
            $dataInfo        = Service::dealModelShowData($ModelField[$modeId], $dataInfo);
            $cat             = $url_mode == 1 ? $dataInfo['catid'] : ($Category[$dataInfo['catid']]['catdir'] ?? getCategory($dataInfo['catid'], 'catdir'));
            $dataInfo['url'] = buildContentUrl($cat, $dataInfo['id'], $dataInfo['url']);
        }
        return $dataInfo;
    }

}
