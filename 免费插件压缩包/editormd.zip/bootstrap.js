        require.config({
            paths: {
                'marked': "../addons/editormd/lib/marked.min",
                'prettify': "../addons/editormd/lib/prettify.min",
                'raphael': "../addons/editormd/lib/raphael.min",
                'underscore': "../addons/editormd/lib/underscore.min",
                'flowchart': "../addons/editormd/lib/flowchart.min",
                'jqueryflowchart': "../addons/editormd/lib/jquery.flowchart.min",
                'sequenceDiagram': "../addons/editormd/lib/sequence-diagram.min",
                'katex': "//cdnjs.cloudflare.com/ajax/libs/KaTeX/0.1.1/katex.min",
                'editormd': "../addons/editormd/editormd.amd"
            },
            // shim依赖配置
            shim: {
                'jqueryflowchart': ['flowchart'],
                'sequenceDiagram': ['raphael'],
                'editormd': [
                    'css!../addons/editormd/lib/codemirror/addon/fold/foldgutter.css',
                    'css!../addons/editormd/css/editormd.min',
                    'css!../addons/editormd/lib/codemirror/codemirror.min',
                ],
            },
        });

        var deps = [
            "editormd",
            //"../addons/editormd/languages/en",
            "../addons/editormd/plugins/link-dialog/link-dialog",
            "../addons/editormd/plugins/reference-link-dialog/reference-link-dialog",
            "../addons/editormd/plugins/image-dialog/image-dialog",
            "../addons/editormd/plugins/code-block-dialog/code-block-dialog",
            "../addons/editormd/plugins/table-dialog/table-dialog",
            "../addons/editormd/plugins/emoji-dialog/emoji-dialog",
            "../addons/editormd/plugins/goto-line-dialog/goto-line-dialog",
            "../addons/editormd/plugins/help-dialog/help-dialog",
            "../addons/editormd/plugins/html-entities-dialog/html-entities-dialog",
            "../addons/editormd/plugins/preformatted-text-dialog/preformatted-text-dialog"
        ];

        require(['form', 'upload'], function(Form, Upload) {
            var _bindevent = Form.events.bindevent;
            Form.events.bindevent = function(form) {
                _bindevent.apply(this, [form]);
                try {
                    if ($('.markdown', form).length > 0) {
                        require(deps, function(editormd) {
                            var editormds = {};
                            $('.markdown', form).each(function() {
                                var editormd_name = $(this).attr('id');
                                $(this).removeClass('layui-textarea');
                                $("<div>", { "id": editormd_name }).append($(this).clone()).replaceAll(this);
                                editormds[editormd_name] = editormd(editormd_name, {
                                    width: "100%",
                                    height: 640,
                                    path: Config.__CDN__ + "/assets/addons/editormd/lib/",
                                    //markdown: md,
                                    toolbarAutoFixed: false,
                                    codeFold: true,
                                    searchReplace: true,
                                    saveHTMLToTextarea: true, // 保存HTML到Textarea
                                    htmlDecode: "style,script,iframe|on*", // 开启HTML标签解析，为了安全性，默认不开启    
                                    taskList: true,
                                    tex: false, // 开启科学公式TeX语言支持，默认关闭
                                    tocm: true, // Using [TOCM]
                                    autoLoadModules: false,
                                    previewCodeHighlight: true,
                                    flowChart: false, // 开启流程图支持，默认关闭
                                    sequenceDiagram: false, // 开启时序/序列图支持，默认关闭,
                                    //dialogLockScreen : false,   // 设置弹出层对话框不锁屏，全局通用，默认为true
                                    //dialogShowMask : false,     // 设置弹出层对话框显示透明遮罩层，全局通用，默认为true
                                    //dialogDraggable : false,    // 设置弹出层对话框不可拖动，全局通用，默认为true
                                    //dialogMaskOpacity : 0.4,    // 设置透明遮罩层的透明度，全局通用，默认值为0.1
                                    //dialogMaskBgColor : "#000", // 设置透明遮罩层的背景颜色，全局通用，默认为#fff
                                    imageUpload: true,
                                    imageFormats: ["jpg", "jpeg", "gif", "png", "bmp", "webp"],
                                    imageUploadURL: Config.upload.uploadurl + '?dir=images&from=editormd',
                                    onload: function() {
                                        console.log('onload', this);
                                        //this.fullscreen();
                                        //this.unwatch();
                                        //this.watch().fullscreen();

                                        //this.setMarkdown("#PHP");
                                        //this.width("100%");
                                        //this.height(480);
                                        //this.resize("100%", 640);
                                    }
                                });
                            })

                        })
                    }

                } catch (e) {}
            }
        });