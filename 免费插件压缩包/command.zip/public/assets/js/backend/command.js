define(['jquery', 'backend', 'table', 'form', 'xm-select'], function($, Backend, Table, Form, xmSelect) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "command/add",
                delete_url: 'command/del',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh', 'add', 'delete'],
                url: 'command/index',
                search: false,
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'id', width: 60, title: 'ID' },
                        { field: 'type', width: 80, title: '类型' },
                        { field: 'type_text', width: 150, title: '类型' },
                        {
                            field: 'command',
                            title: '命令',
                            templet: function(d) {
                                return '<input type="text" class="layui-input" style="height:28px;" value="' + d.command + '">';
                            }
                        },
                        { field: 'execute_time', width: 160, title: '执行时间', search: 'range', templet: Table.formatter.datetime },
                        { field: 'create_time', width: 160, title: '创建时间', search: 'range', templet: Table.formatter.datetime },
                        { field: 'update_time', width: 160, title: '更新时间', search: 'range', templet: Table.formatter.datetime },
                        { field: 'status', width: 80, title: '状态', templet: Table.formatter.status, selectList: { 0: '失败', 1: '成功' }, search: false },
                        {
                            fixed: 'right',
                            width: 170,
                            title: '操作',
                            templet: Table.formatter.tool,
                            operat: [
                                [{
                                    class: 'layui-btn layui-btn-xs btn-execute',
                                    auth: 'execute',
                                    icon: 'iconfont icon-arrow-go-back-line',
                                    url: 'command/execute',
                                    title: '再次执行',
                                    text: '再次执行',
                                    extend: "",
                                }, {
                                    class: 'layui-btn layui-btn-xs layui-bg-blue btn-dialog',
                                    auth: 'detail',
                                    icon: 'iconfont icon-zoom-in-line',
                                    url: 'command/detail',
                                    title: '详情',
                                    extend: "",
                                }], 'delete'
                            ]
                        }
                    ]
                ],
                page: {}
            });

            $(document).on('click', '.btn-execute', function(e) {
                var url = $(this).attr("href");
                Yzn.api.ajax({
                    url: url
                }, function(data, res) {
                    Layer.alert("<textarea class='layui-textarea' cols='60' rows='5'>" + data.result + "</textarea>", {
                        title: "执行结果",
                        shadeClose: true
                    });
                    layui.table.reload(Table.init.table_render_id);
                })
                return false;
            })

            Table.api.bindevent();
        },
        add: function() {
            var form = layui.form;
            var laytpl = layui.laytpl;
            var maintable = [];
            var mainfields = [];
            var relationmode = ["belongsto", "hasone"];

            $("select[name=table] option").each(function() {
                maintable.push($(this).val());
            });

            var renderselect = function(select, data, name) {
                var newArr = [];
                $.each(data, function(i, j) {
                    var vote = {};
                    vote.value = j;
                    vote.name = j;
                    newArr.push(vote);
                })
                xmSelect.render({
                    el: select,
                    name: name,
                    data: newArr
                })
            };


            function buildOptions(select, data, render = true) {
                var html = [];
                for (var i = 0; i < data.length; i++) {
                    html.push("<option value='" + data[i] + "'>" + data[i] + "</option>");
                }
                $(select).html(html.join(""));
                render && form.render();
                select.siblings("div.layui-form-select").find("dd:first").click();
            };

            $(document).on('click', ".btn-removerelation", function() {
                $(this).closest(".layui-row").remove();
            });

            //主表关联
            form.on('select(table-filter)', function(data) {
                Yzn.api.ajax({
                    url: "command/get_field_list",
                    data: { table: data.value },
                }, function(data, ret) {
                    mainfields = data.fieldlist;
                    $("#relation-zone .relation-item").remove();
                    renderselect("#fields", mainfields, 'fields');
                    return false;
                });
                return false;
            });

            $("select[name='table']").siblings("div.layui-form-select").find("dd:first").click();

            //点击显示关联表
            form.on('checkbox(isrelation-filter)', function(data) {
                var elem = data.elem;
                $("#relation-zone").toggleClass("layui-hide", !elem.checked);
            });

            //点击动态追加关联表
            $(document).on('click', "a.btn-newrelation", function() {
                var that = this;
                var index = parseInt($(that).data("index")) + 1;
                var content = laytpl($("#relationtpl").html()).render({ index: index });
                content = $(content.replace(/\[index\]/, index));
                $(this).data("index", index);
                $(content).insertBefore($(that).closest(".layui-row"));

                var exists = [$("select[name='table']").val()];
                $("select.relationtable").each(function() {
                    exists.push($(this).val());
                });

                relationtable = [];
                $.each(maintable, function(i, j) {
                    if ($.inArray(j, exists) < 0) {
                        relationtable.push(j);
                    }
                });
                buildOptions($("select.relationtable", content), relationtable);
            });

            form.on('select(relationmode-filter)', function(data) {
                var table = $("select.relationtable", $(this).closest(".layui-row")).val();
                var that = this;
                var value = data.value;
                Yzn.api.ajax({
                    url: "command/get_field_list",
                    data: { table: table },
                }, function(data, ret) {
                    buildOptions($(that).closest(".layui-row").find("select.relationprimarykey"), value == 'belongsto' ? data.fieldlist : mainfields, false);
                    buildOptions($(that).closest(".layui-row").find("select.relationforeignkey"), value == 'hasone' ? data.fieldlist : mainfields, false);
                    form.render();
                    return false;
                });
                return false;
            });

            //关联表下拉追加字段
            form.on('select(relationtable-filter)', function(data) {
                var that = this;
                var index = $(data.elem).data('index');
                var fieldsObj = $(that).closest(".layui-row").find("div.relationfields");
                var name = fieldsObj.attr('name');

                Yzn.api.ajax({
                    url: "command/get_field_list",
                    data: { table: data.value },
                }, function(data, ret) {
                    buildOptions($(that).closest(".layui-row").find("select.relationmode"), relationmode);
                    renderselect('#relationfields' + index, data.fieldlist, name)
                    return false;
                });
                return false;
            });

            form.on('submit(btn-command)', function(data) {
                var field = data.field;
                var elemForm = data.form;
                var textarea = $("textarea[rel=command]", elemForm);
                textarea.val('');
                Yzn.api.ajax({
                    url: "command/command?action=command",
                    data: field,
                }, function(data, ret) {
                    textarea.val(data.command);
                    return false;
                });
                return false;
            });
            $(document).on('click', ".btn-execute", function() {
                var form = $(this).closest("form");
                var textarea = $("textarea[rel=result]", form);
                textarea.val('');
                Yzn.api.ajax({
                    url: "command/command?action=execute",
                    data: form.serialize(),
                }, function(data, ret) {
                    textarea.val(data.result);
                    window.parent.$('[data-table-refresh]').trigger('click');
                    return false;
                }, function(data, ret) {
                    window.parent.$('[data-table-refresh]').trigger('click');
                });
                return false;
            });

            Form.events.selectpage($("form.layui-form"));

        },
    };
    return Controller;
});