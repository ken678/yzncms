<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | Links模型
// +----------------------------------------------------------------------
namespace app\admin\model\links;

use think\Model;

/**
 * 模型
 */
class Links extends Model
{
    protected $autoWriteTimestamp = true;

    public static function onBeforeWrite($row)
    {
        if (isset($row['termsname']) && $row['termsname']) {
            $res = Terms::where(["name" => $row['termsname'], "module" => "links"])->find();
            if ($res > 0) {
                throw new \Exception("该分类已经存在！");
            }
            $term = Terms::create([
                "name"   => $row['termsname'],
                "module" => "links",
            ]);
            $row['terms_id'] = $term->id;
        }
    }
}
