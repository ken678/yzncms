<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 友情链接管理
// +----------------------------------------------------------------------
namespace app\admin\controller\links;

use app\admin\model\links\Terms as TermsModel;
use app\common\controller\Backend;

/**
 * 友情链接管理
 */
class Terms extends Backend
{
    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new TermsModel;
    }

    //分类管理
    public function index()
    {
        if ($this->request->isAjax()) {
            [$page, $limit, $where, $sort, $order] = $this->buildTableParames();

            $count = $this->modelClass
                ->where($where)
                ->where("module", "links")
                ->order($sort, $order)
                ->count();

            $data = $this->modelClass
                ->where($where)
                ->where("module", "links")
                ->order($sort, $order)
                ->page($page, $limit)
                ->select();

            $result = ["code" => 0, 'count' => $count, 'data' => $data];
            return json($result);
        }
        return $this->fetch();
    }
}
