<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | L插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 友情链接管理
// +----------------------------------------------------------------------
namespace app\admin\controller\links;

use app\admin\model\links\Links as LinksModel;
use app\common\controller\Backend;
use think\facade\Db;

/**
 * 友情链接管理
 */
class Admin extends Backend
{
    protected $modelValidate = true;

    protected function initialize()
    {
        parent::initialize();
        $this->modelClass = new LinksModel;
    }

    /**
     * 新增友情链接
     */
    public function add()
    {
        $Terms = Db::name('Terms')->where("module", "links")->select();
        $this->assign("Terms", $Terms);
        return parent::add();
    }

    /**
     * 编辑友情链接
     */
    public function edit()
    {
        $Terms = Db::name('Terms')->where("module", "links")->select();
        $this->assign("Terms", $Terms);
        return parent::edit();
    }
}
