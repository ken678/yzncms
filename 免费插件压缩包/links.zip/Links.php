<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | 插件禁止分享、复制、转售、传播等任何形式的二次分发
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 友情链接插件
// +----------------------------------------------------------------------
namespace addons\links;

use app\common\library\Menu;
use think\Addons;
use think\facade\Config;

class Links extends Addons
{
    /**
     * 应用初始化
     */
    public function appInit()
    {
        $taglib = Config::get('view.taglib_pre_load');
        Config::set(['taglib_pre_load' => ($taglib ? $taglib . ',' : '') . 'addons\\links\\taglib\\Links'], 'view');
    }

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                "name"    => "links",
                "title"   => "友情链接",
                "icon"    => "iconfont icon-link-m",
                "sublist" => [
                    [
                        "name"      => "links.admin",
                        "title"     => "友情链接",
                        "icon"      => "iconfont icon-link-m",
                        "listorder" => 9,
                        "sublist"   => [
                            ["name" => "links.admin/index", "title" => "查看"],
                            ["name" => "links.admin/add", "title" => "新增"],
                            ["name" => "links.admin/edit", "title" => "编辑"],
                            ["name" => "links.admin/del", "title" => "删除"],
                            ["name" => "links.admin/multi", "title" => "批量更新"],
                        ],
                    ],
                    [
                        "name"    => "links.terms",
                        "title"   => "分类管理",
                        "icon"    => "iconfont icon-list-unordered",
                        "sublist" => [
                            ["name" => "links.terms/index", "title" => "查看"],
                            ["name" => "links.terms/add", "title" => "新增"],
                            ["name" => "links.terms/edit", "title" => "编辑"],
                            ["name" => "links.terms/del", "title" => "删除"],
                        ],
                    ],
                ],
            ],

        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("links");
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable("links");
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable("links");
        return true;
    }

}
