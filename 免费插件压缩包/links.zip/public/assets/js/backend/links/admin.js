define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                add_url: "links.admin/add",
                edit_url: "links.admin/edit",
                delete_url: "links.admin/del",
                multi_url: "links.admin/multi",
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh','add', 'delete'
                ],
                url: "links.admin/index",
                cols: [
                    [
                        { type: 'checkbox', fixed: 'left' },
                        { field: 'listorder', width: 70, title: '排序', edit: 'text', search: false },
                        { field: 'id', width: 70, title: 'ID' },
                        { field: 'name', title: '网站名称', searchOp: 'like' },
                        { field: 'url', title: '网站网址' },
                        { field: 'image', width: 150, title: '网站LOGO', templet: '#image', selectList: { 0: '无', 1: '有' },search:false },
                        { field: 'link_type', width: 150, title: '链接类型', templet: '#type', selectList: { 0: '文字链接', 1: '图片链接' } },
                        { field: 'terms_id', width: 80, title: '分类ID' },
                        { field: 'create_time', width: 180, title: '添加时间', search: 'range' },
                        { field: 'status', width: 120, align: "center", title: '状态', unresize: true, selectList: { 0: '未通过', 1: '已通过' }, templet: Table.formatter.switch, tips: "已通过|未通过" },
                        { width: 90, title: '操作', templet: Table.formatter.tool, operat: ['edit', 'delete'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        add: function() {
            Controller.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});