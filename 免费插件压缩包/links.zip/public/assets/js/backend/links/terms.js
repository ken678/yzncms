define(['jquery', 'table', 'form'], function($, Table, Form) {

    var Controller = {
        index: function() {
            Table.init = {
                table_elem: '#currentTable',
                table_render_id: 'currentTable',
                edit_url: 'links.terms/edit',
                delete_url: 'links.terms/del',
            };

            Table.render({
                init: Table.init,
                toolbar: ['refresh'],
                url: 'links.terms/index',
                cols: [
                    [
                        { field: 'id', width: 70, title: 'ID' },
                        { field: 'name', align: "left", title: '分类名称' },
                        { width: 90, title: '操作', templet: Table.formatter.tool, operat: ['edit', 'delete'] }
                    ]
                ],
                page: {}
            });

            Table.api.bindevent();
        },
        edit: function() {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function() {
                Form.api.bindevent($("form.layui-form"));
            }
        }
    };
    return Controller;
});