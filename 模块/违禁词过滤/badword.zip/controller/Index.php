<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 敏感词过滤
// +----------------------------------------------------------------------
namespace app\badword\controller;

use app\badword\model\Badword as badword_model;
use app\common\controller\Adminbase;

class Index extends Adminbase
{
    protected function initialize()
    {
        parent::initialize();
        $this->badword_model = new badword_model;
    }

    /**
     * 首页
     */
    public function index()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page = $this->request->param('page/d', 1);
            $_list = $this->badword_model->order('id', 'desc')->page($page, $limit)->select();
            $total = $this->badword_model->count();
            $result = array("code" => 0, "count" => $total, "data" => $_list);
            return json($result);
        }
        return $this->fetch();
    }

    /**
     * 新增
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $data = $this->request->post();
            if ($this->badword_model->allowField(true)->save($data)) {
                $this->success("添加成功！", url("index"));
            } else {
                $this->error("添加失败！");
            }
        } else {
            return $this->fetch();
        }

    }

    /**
     * 新增
     */
    public function edit()
    {
        $id = $this->request->param('id/d', 0);
        empty($id) && $this->error('参数错误！');
        if ($this->request->isPost()) {
            $data = $this->request->post();
            if ($this->badword_model->allowField(true)->save($data, ['id' => $id])) {
                $this->success("编辑成功！", url("index"));
            } else {
                $this->error("编辑失败！");
            }
        } else {
            $info = $this->badword_model->find($id);
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    //导入
    public function import()
    {
        if ($this->request->isPost()) {
            $files = $this->request->file('file');
            if ($files == null) {
                $this->error("请选择上传文件！");
            }
            $file_name = $files->getInfo('tmp_name');
            if (strtolower(substr($files->getInfo('name'), -3, 3)) != 'txt') {
                $this->error("只支持上传TXT的格式！");
            }
            //读取文件
            $data = file_get_contents($file_name);
            $arr = array_unique(explode(PHP_EOL, $data));
            $sql_str = [];
            if (is_array($arr) || empty($arr)) {
                foreach ($arr as $key => $value) {
                    $attr = parse_attr($value);
                    $sql_str[$key]['badword'] = $attr[0];
                    $sql_str[$key]['replaceword'] = empty($attr[1]) ? '' : $attr[1];
                }
            }
            if ($this->badword_model->saveAll($sql_str)) {
                $this->success("批量导入成功！");
            } else {
                $this->error("批量导入失败！");
            }
        }
    }

    /**
     * 删除
     */
    public function del($ids)
    {
        empty($ids) && $this->error('参数错误！');
        if (!is_array($ids)) {
            $ids = array($ids);
        }
        if (false == $this->badword_model->where('id', 'in', $ids)->delete()) {
            $this->error('删除失败！');
        } else {
            $this->success('删除成功！');
        }
    }

}
