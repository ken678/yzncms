<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 友情链接管理
// +----------------------------------------------------------------------
namespace app\links\controller;

use app\common\controller\Adminbase;
use app\links\model\Links as Links_Model;

/**
 * 友情链接管理
 */
class Links extends Adminbase
{
    protected function initialize()
    {
        parent::initialize();
        $this->Links_Model = new Links_Model;
    }

    /**
     * [友情链接列表]
     */
    public function index()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page = $this->request->param('page/d', 1);
            $_list = $this->Links_Model->order('id', 'desc')->page($page, $limit)->select();
            $total = count($_list);
            $result = array("code" => 0, "count" => $total, "data" => $_list);
            return json($result);
        }
        return $this->fetch();
    }

    /**
     * [新增友情链接]
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $data = $this->request->post();
            //验证器
            $rule = [
                'name' => 'require',
                'url' => 'require|url',
            ];
            $msg = [
                'name.require' => '网站名称不得为空',
                'url.require' => '网站链接不得为空',
                'url.url' => '网站链接不是有效URL',
            ];
            $validate = new \think\Validate($rule, $msg);
            if (!$validate->check($data)) {
                $this->error($validate->getError());
            }
            $status = $this->Links_Model->allowField(true)->save($data);
            if ($status) {
                $this->success("添加成功！", url("links/index"));
            } else {
                $this->error("添加失败！");
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * [编辑友情链接]
     */
    public function edit()
    {
        if ($this->request->isPost()) {
            $data = $this->request->post();
            //验证器
            $rule = [
                'name' => 'require',
                'url' => 'require|url',
            ];
            $msg = [
                'name.require' => '网站名称不得为空',
                'url.require' => '网站链接不得为空',
                'url.url' => '网站链接不是有效URL',
            ];
            $validate = new \think\Validate($rule, $msg);
            if (!$validate->check($data)) {
                $this->error($validate->getError());
            }
            $status = $this->Links_Model->allowField(true)->save($data, ['id' => $data['id']]);
            if ($status) {
                $this->success("编辑成功！", url("links/index"));
            } else {
                $this->error("编辑失败！");
            }

        } else {
            $id = $this->request->param('id', 0);
            $data = $this->Links_Model->where(array("id" => $id))->find();
            if (!$data) {
                $this->error("该信息不存在！");
            }
            $this->assign("data", $data);
            return $this->fetch();
        }

    }

    /**
     * [删除友情链接]
     * @param  integer $ids [description]
     */
    public function delete($ids = 0)
    {
        empty($ids) && $this->error('参数错误！');
        if (!is_array($ids)) {
            $ids = array($ids);
        }
        $res = $this->Links_Model->where('id', 'in', $ids)->delete();
        if ($res !== false) {
            $this->success('删除成功！');
        } else {
            $this->error('删除失败！');
        }

    }

    /**
     * 友情链接状态
     */
    public function setstate()
    {
        $id = $this->request->param('id/d');
        empty($id) && $this->error('参数不能为空！');
        $status = $this->request->param('status/s') === 'true' ? 1 : 0;
        if ($this->Links_Model->where('id', $id)->setField(['status' => $status])) {
            $this->success("操作成功！");
        } else {
            $this->error('操作失败！');
        }
    }

    /**
     * [友情链接排序]
     */
    public function listorder()
    {
        $id = $this->request->param('id/d', 0);
        $listorder = $this->request->param('value/d', 0);
        $rs = $this->Links_Model->where(['id' => $id])->setField(['listorder' => $listorder]);
        if ($rs !== false) {
            $this->success("排序更新成功！");
        } else {
            $this->error("排序失败！");
        }
    }

}
