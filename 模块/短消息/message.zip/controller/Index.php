<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 短信息后台管理
// +----------------------------------------------------------------------
namespace app\message\controller;

use app\member\controller\MemberBase;
use app\member\model\Member as Member_Model;
use app\message\model\Message as Message_Model;
use app\message\model\MessageGroup as MessageGroup_Model;
use think\facade\Config;

class Index extends MemberBase
{
    //初始化
    protected function initialize()
    {
        parent::initialize();
        $this->groupCache = cache("Member_Group"); //会员模型
        $this->Message_Model = new Message_Model;
        $this->MessageGroup_Model = new MessageGroup_Model;
    }

    //发送消息
    public function send()
    {
        if ($this->request->isPost()) {
            //判断当前会员，是否可发，短消息．
            $this->messagecheck($this->userid);
            $data = $this->request->post('info/a');
            $data['send_from'] = $this->userinfo['username'];
            $result = $this->validate($data, 'message');
            if (true !== $result) {
                return $this->error($result);
            }
            if ($data['send_to'] == $this->userinfo['username']) {
                return $this->error('不能发给自己');
            }
            if (!Member_Model::getByUsername($data['send_to'])) {
                return $this->error('用户不存在');
            }
            if ($this->Message_Model->allowField(true)->save($data)) {
                $this->success('发送成功！');
            } else {
                $this->error('发送失败！');
            }
        } else {
            return $this->fetch('/send');
        }
    }

    //查看短消息
    public function read()
    {
        return $this->fetch('/read');

    }

    //查看自己发的短消息
    public function read_only()
    {
        return $this->fetch('/read_only');

    }

    //系统消息
    public function group()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page = $this->request->param('page/d', 1);
            $_list = $this->MessageGroup_Model->where('groupid', $this->userinfo['groupid'])->page($page, $limit)->select();
            $total = count($_list);
            $result = array("code" => 0, "count" => $total, "data" => $_list);
            return json($result);
        }
        return $this->fetch('/group');
    }

    //查看系统消息
    public function read_group()
    {
        return $this->fetch('/read_group');
    }

    //收件箱
    public function inbox()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page = $this->request->param('page/d', 1);
            $_list = $this->Message_Model->where('send_to', $this->userinfo['username'])->page($page, $limit)->select();
            $total = count($_list);
            $result = array("code" => 0, "count" => $total, "data" => $_list);
            return json($result);
        }
        return $this->fetch('/inbox');
    }

    //发件箱
    public function outbox()
    {
        if ($this->request->isAjax()) {
            $limit = $this->request->param('limit/d', 10);
            $page = $this->request->param('page/d', 1);
            $_list = $this->Message_Model->where('send_from', $this->userinfo['username'])->page($page, $limit)->select();
            $total = count($_list);
            $result = array("code" => 0, "count" => $total, "data" => $_list);
            return json($result);
        }
        return $this->fetch('/outbox');
    }

    /**
     *
     * 检查当前用户短消息相关权限
     * @param  $userid 用户ID
     */
    public function messagecheck($userid)
    {
        if ($this->groupCache[$this->userinfo['groupid']]['allowsendmessage'] == 0) {
            $this->error("对不起你没有权限发短消息！");
        } else {
            //判断是否到限定条数
            $num = $this->Message_Model->where('send_from', $this->userinfo['username'])->count();
            if ($num >= $this->groupCache[$this->userinfo['groupid']]['allowsendmessage']) {
                $this->error('你的短消息条数已达最大值!');
            }
        }
    }

    protected function fetch($template = '', $vars = [], $config = [])
    {
        $Theme = empty(Config::get('theme')) ? 'default' : Config::get('theme');
        $this->view->config('view_path', TEMPLATE_PATH . $Theme . DIRECTORY_SEPARATOR . 'message' . DIRECTORY_SEPARATOR);
        return $this->view->fetch($template, $vars, $config);
    }

}
