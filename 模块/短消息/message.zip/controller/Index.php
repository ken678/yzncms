<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 短信息后台管理
// +----------------------------------------------------------------------
namespace app\message\controller;

use app\member\controller\MemberBase;
use think\facade\Config;

class Index extends MemberBase
{

    protected function fetch($template = '', $vars = [], $config = [])
    {
        $Theme = empty(Config::get('theme')) ? 'default' : Config::get('theme');
        $this->view->config('view_path', TEMPLATE_PATH . $Theme . DIRECTORY_SEPARATOR . 'message' . DIRECTORY_SEPARATOR);
        return $this->view->fetch($template, $vars, $config);
    }

    //短消息
    public function message()
    {
        return $this->fetch('/message');
    }

    //收件箱
    public function inbox()
    {
        return $this->fetch('/inbox');
    }

    //发件箱
    public function outbox()
    {
        return $this->fetch('/outbox');
    }

}
