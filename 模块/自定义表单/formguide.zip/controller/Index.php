<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单前台管理
// +----------------------------------------------------------------------

namespace app\formguide\controller;

use app\cms\model\Cms as Cms_Model;
use app\common\controller\Homebase;

class Index extends HomeBase
{
    protected function initialize()
    {
        parent::initialize();
        $this->Cms_Model = new Cms_Model;
    }

    //显示表单
    public function index()
    {
        $modelid = $this->request->param('id/d', 0);
        $fieldList = $this->Cms_Model->getFieldList($modelid);
        $this->assign([
            'catid' => $catid,
            'fieldList' => $fieldList,
        ]);
        return $this->fetch('/index');
    }

    //表单提交
    public function post()
    {

    }

}
