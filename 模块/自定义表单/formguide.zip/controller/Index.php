<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单前台管理
// +----------------------------------------------------------------------

namespace app\formguide\controller;

use app\common\controller\Homebase;
use app\formguide\model\Formguide as Formguide_Model;

class Index extends HomeBase
{
    //当前表单ID
    public $formid;

    protected function initialize()
    {
        parent::initialize();
        $this->formid = $this->request->param('id/d', 0);
        $this->Formguide_Model = new Formguide_Model;
        $this->assign('id', $this->formid);
    }

    //显示表单
    public function index()
    {
        $modelid = $this->request->param('id/d', 0);
        $fieldList = $this->Formguide_Model->getFieldList($modelid);
        $this->assign([
            'fieldList' => $fieldList,
        ]);
        return $this->fetch('/index');
    }

    //表单提交
    public function post()
    {
        $data = $this->request->post();
        try {
            $this->Formguide_Model->addFormguideData($this->formid, $data['modelField']);
        } catch (\Exception $ex) {
            $this->error($ex->getMessage());
        }
        $this->success('操作成功！');
    }

}
