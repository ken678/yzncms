<?php
// +----------------------------------------------------------------------
// | Yzncms [ 御宅男工作室 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2018 http://yzncms.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 御宅男 <530765310@qq.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 表单模型
// +----------------------------------------------------------------------
namespace app\formguide\model;

use app\cms\model\Cms as Cms_Model;
use think\Db;

class Formguide extends Cms_Model
{
    protected $name = 'ModelField';
    protected $autoWriteTimestamp = false;

    //添加模型内容
    public function addFormguideData($formid, $data, $dataExt = [])
    {
        //完整表名获取
        $tablename = $this->getModelTableName($formid);
        if (!$this->table_exists($tablename)) {
            throw new \Exception('数据表不存在！');
        }
        /*if (!defined('IN_ADMIN') || (defined('IN_ADMIN') && IN_ADMIN == false)) {
        empty($data['uid']) ? \app\member\service\User::instance()->id : $data['uid'];
        empty($data['username']) ? \app\member\service\User::instance()->username : $data['username'];
        $data['sysadd'] = 0;
        } else {
        //添加用户名
        $data['uid'] = \app\admin\service\User::instance()->id;
        $data['username'] = \app\admin\service\User::instance()->username;
        $data['sysadd'] = 1;
        }*/
        //处理数据
        $dataAll = $this->dealModelPostData($formid, $data, $dataExt);
        list($data, $dataExt) = $dataAll;
        $data['inputtime'] = request()->time();
        try {
            //主表
            $id = Db::name($tablename)->insertGetId($data);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
        return $id;
    }

}
